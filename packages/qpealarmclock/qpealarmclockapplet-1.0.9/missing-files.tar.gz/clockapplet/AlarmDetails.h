/*
 * $Id: AlarmDetails.h,v 1.2 2002/10/06 22:26:20 dwalters Exp $
 *
 * Copyright (C) 2002 Dafydd Walters <dwalters@users.sourceforge.net>
 * Modified by Anton Maslovsky <my-zaurus@narod.ru> 2003/01/28
 * 
 * This program may be modified or redistributed under the terms of the GNU
 * General Public License (GPL), version 2 or later. A copy of the GNU GPL 
 * should have accompanied the source code of this program. If not, please 
 * write to the Free Software Foundation Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * This program is distributed without any warranty.
 */ 

#ifndef ALARMDETAILS_H
#define ALARMDETAILS_H

#include <qobject.h>
#include <qdatetime.h>

#include "sharp_char.h"

#define NUM_WEEKDAYS        7       // obviousely

class AlarmDetails : public QObject 
{
    Q_OBJECT

public:
    enum Frequency
    {
      once = 0,
      daily = 1,
      workdays = 2,
      weekends = 3,
      custom = 4
    };

    enum Notification
    {
      silent = 0,
      loud = 1
    };

    enum Weekdays
    {
       // weekdays flags
       WEEKDAYS_MONDAY    = 0x80,    // 1000 0000
       WEEKDAYS_TUESDAY   = 0x40,    // 0100 0000
       WEEKDAYS_WEDNSDAY  = 0x20,    // 0010 0000
       WEEKDAYS_THURSDAY  = 0x10,    // 0001 0000
       WEEKDAYS_FRIDAY    = 0x08,    // 0000 1000
       WEEKDAYS_SATURDAY  = 0x04,    // 0000 0100
       WEEKDAYS_SUNDAY    = 0x02,    // 0000 0010

       WEEKDAYS_NONE      = 0x00,
       WEEKDAYS_WORKDAYS  = (WEEKDAYS_MONDAY | WEEKDAYS_TUESDAY | WEEKDAYS_WEDNSDAY | 
                                    WEEKDAYS_THURSDAY | WEEKDAYS_FRIDAY),

       WEEKDAYS_WEEKEND   = (WEEKDAYS_SATURDAY | WEEKDAYS_SUNDAY),
       WEEKDAYS_ALL       = (WEEKDAYS_WORKDAYS | WEEKDAYS_WEEKEND),

       WEEKDAYS_IGNORE    = 0xFF    // do not change any days
    };
       
    static const Weekdays flags[] =
    {
      WEEKDAYS_MONDAY,
      WEEKDAYS_TUESDAY,
      WEEKDAYS_WEDNSDAY,
      WEEKDAYS_THURSDAY,
      WEEKDAYS_FRIDAY,
      WEEKDAYS_SATURDAY,
      WEEKDAYS_SUNDAY
    };

    static const Weekdays weekdaysGroups[] =
    {
      WEEKDAYS_NONE,
      WEEKDAYS_ALL,
      WEEKDAYS_WORKDAYS,
      WEEKDAYS_WEEKEND,
      WEEKDAYS_IGNORE
    };
  
    AlarmDetails(int alarmNumberInit);
    ~AlarmDetails();

    bool enabled() const { return alarmEnabled; }
    const QTime& time() const { return alarmTime; }
    const QDateTime& nextDateTime() const { return alarmNextDateTime; }
    Frequency frequency() const { return alarmFrequency; }
    Notification notification() const {return alarmNotification; }
    int led() const { return alarmLed; }
    QString sound() { return alarmSound;  }
    QString device() { return alarmDevice;  }
    const QString& message() const { return alarmMessage; }
    int snoozeInterval() const { return alarmSnoozeInterval; }
    Weekdays weekdaysFlags() const { return alarmWeekdaysFlags; }

    void setAlarm(bool enabled, QTime time, Frequency frequency,
      const QString& message = QString::null, Notification notification = loud,
      int led = LED_COLLIE_1_DEFAULT, const QString& sound = "", const QString& device = "",
      int snoozeInterval = 5,
      Weekdays weekdaysFlags = WEEKDAYS_NONE);

    static QString frequencyLabel(Frequency frequency);
    static QString notificationLabel(Notification notification);
    static QString ledLabel(int led);
    static QString weekdaysFlagsLabel(Weekdays weekdaysFlags);

    QString toString();

private:
    QDateTime alarmNextDateTime;
    bool alarmEnabled;
    QTime alarmTime;
    Frequency alarmFrequency;
    Notification alarmNotification;
    int alarmLed;
    QString alarmSound;
    QString alarmDevice;
    int alarmNumber;
    QString alarmMessage;
    int alarmSnoozeInterval;
    Weekdays alarmWeekdaysFlags;
    
    void saveAlarm();
    void loadAlarm();
    QDateTime setAlarmServer();
};

#endif
