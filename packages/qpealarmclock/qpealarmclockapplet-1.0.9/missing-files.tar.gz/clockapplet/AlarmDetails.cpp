/*
 * $Id: AlarmDetails.cpp,v 1.2 2002/10/06 22:26:20 dwalters Exp $
 *
 * Copyright (C) 2002 Dafydd Walters <dwalters@users.sourceforge.net>
 * Modified by Anton Maslovsky <my-zaurus@narod.ru> 2003/01/28
 * 
 * This program may be modified or redistributed under the terms of the GNU
 * General Public License (GPL), version 2 or later. A copy of the GNU GPL 
 * should have accompanied the source code of this program. If not, please 
 * write to the Free Software Foundation Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * This program is distributed without any warranty.
 */ 

#include "AlarmDetails.h"
#include <qpe/config.h>
#include <qpe/alarmserver.h>
#include <qpe/applnk.h>
#include <qpe/resource.h>

#include <qimage.h>
#include <qpixmap.h>

const AlarmDetails::Weekdays AlarmDetails::flags[];
const AlarmDetails::Weekdays AlarmDetails::weekdaysGroups[];

AlarmDetails::AlarmDetails(int alarmNumberInit) : alarmNumber(alarmNumberInit)
{
    loadAlarm();
}

AlarmDetails::~AlarmDetails()
{
}

void AlarmDetails::saveAlarm()
{
    Config config("qpealarmclock");
    config.setGroup("Alarm" + QString::number(alarmNumber));
    config.writeEntry("enabled", alarmEnabled);
    config.writeEntry("frequency", alarmFrequency);
    config.writeEntry("notification", alarmNotification);
    config.writeEntry("led", alarmLed);
    config.writeEntry("sound", alarmSound);
    config.writeEntry("device", alarmDevice);
    config.writeEntry("hour", alarmTime.hour());
    config.writeEntry("minute", alarmTime.minute());
    config.writeEntry("message", alarmMessage);
    config.writeEntry("snoozeInterval", alarmSnoozeInterval);
    config.writeEntry("weekdaysFlags", QString::number(alarmWeekdaysFlags));

    qDebug("Saved alarm: " + this->toString());
}

void AlarmDetails::loadAlarm()
{
    int hour, minute;

    Config config("qpealarmclock");
    config.setGroup("Alarm" + QString::number(alarmNumber));
    alarmEnabled = config.readBoolEntry("enabled", false);
    alarmFrequency = static_cast<Frequency>(config.readNumEntry("frequency", once));
    alarmNotification = static_cast<Notification>(config.readNumEntry("notification", loud));
    alarmLed = config.readNumEntry("led", LED_COLLIE_1_DEFAULT);
    alarmSound = config.readEntry("sound", "");
    alarmDevice = config.readEntry("device", "/dev/dsp");
    alarmMessage = config.readEntry("message", tr("Alarm"));
    alarmSnoozeInterval = config.readNumEntry("snoozeInterval", 5);
    alarmWeekdaysFlags = static_cast<Weekdays>(config.readNumEntry("weekdaysFlags",
      weekdaysGroups[alarmFrequency]));

    hour = config.readNumEntry("hour", QTime::currentTime().hour());
    minute = config.readNumEntry("minute", QTime::currentTime().minute() + 1);
    alarmTime = QTime(hour,minute);
    alarmNextDateTime = setAlarmServer();

    qDebug("Loaded alarm: " + this->toString());
}

void AlarmDetails::setAlarm(bool enabled, QTime time, Frequency frequency,
  const QString& message /* = QString::null */, Notification notification /* = loud */,
  int led /* = LED_COLLIE_1_DEFAULT */, const QString& sound /* = "" */,
  const QString& device /* = "" */, int snoozeInterval /* = 5 */,
  Weekdays weekdaysFlags /* = WEEKDAYS_NONE */)
{
    alarmEnabled = enabled;
    alarmTime = time;
    alarmFrequency = frequency;
    alarmNotification = notification;
    alarmLed = led;
    alarmSound = sound;
    alarmDevice = device;
    alarmMessage = message;
    alarmSnoozeInterval = snoozeInterval;
    alarmWeekdaysFlags = weekdaysFlags;

    qDebug("Setting alarm: " + this->toString());

    alarmNextDateTime = setAlarmServer();
    saveAlarm();
}

QDateTime AlarmDetails::setAlarmServer()
{
    QDateTime alarm_time;

    AlarmServer::deleteAlarm(QDateTime(), "QPE/Application/qpealarmclock",
                             "alarm(QDateTime,int)", alarmNumber);

    if (alarmEnabled)
    {
      QDateTime now = QDateTime::currentDateTime();
      alarm_time = alarmTime <= now.time() ?
                   QDateTime(now.date().addDays(1), alarmTime) :
                   QDateTime(now.date(), alarmTime);

      // calculate next alarm day based on weekdays flags
      if ((alarmFrequency != once) && (alarmWeekdaysFlags != WEEKDAYS_NONE))
      {
        while ((alarmWeekdaysFlags & flags[alarm_time.date().dayOfWeek() - 1]) == WEEKDAYS_NONE)
          alarm_time  = alarm_time.addDays(1);
      }

      AlarmServer::addAlarm(alarm_time, "QPE/Application/qpealarmclock",
                            "alarm(QDateTime,int)", alarmNumber);

      qDebug("Alarm set: " + this->toString());
    }

    return alarm_time;
}

QString AlarmDetails::toString()
{
  QString s("Alarm ");

  s.append(QString::number(alarmNumber)).append(" ");
  s.append(alarmEnabled ? "" : " (disabled) ");
  s.append(alarmMessage).append(" at ");
  s.append(alarmTime.toString()).append(" ");
  s.append(frequencyLabel(alarmFrequency)).append(" ");
  s.append(notificationLabel(alarmNotification)).append(" ");
  s.append(ledLabel(alarmLed)).append(" ");
  s.append(QString::number(alarmSnoozeInterval)).append(" ");
  s.append(QString::number(alarmWeekdaysFlags));

  return s;
}

QString AlarmDetails::frequencyLabel(Frequency frequency)
{
  static const char* labels[] =
  {
    QT_TR_NOOP("Once"),
    QT_TR_NOOP("Every day"),
    QT_TR_NOOP("Monday to Friday"),
    QT_TR_NOOP("Saturday & Sunday"),
    QT_TR_NOOP("Custom")
  };

  if (frequency >= once && frequency <= custom)
    return tr(labels[frequency]);

  return tr("Invalid Frequency");
}


QString AlarmDetails::notificationLabel(Notification notification)
{
  static const char* labels[] =
  {
    QT_TR_NOOP("Silent"),
    QT_TR_NOOP("Loud")
  };

  if (notification >= silent && notification <= loud)
    return tr(labels[notification]);

  return tr("Invalid Notification");
}

QString AlarmDetails::ledLabel(int led)
{
  static const char* labels[] =
  {
     QT_TR_NOOP("Default"),         /*   0   for LED_COLLIE_1_DEFAULT */
     QT_TR_NOOP("Led Off"),         /*   1   for LED_COLLIE_1_OFF */
     QT_TR_NOOP("Led On"),          /*   2   for LED_COLLIE_1_ON */
     QT_TR_NOOP("Flash On"),        /*   3   for LED_COLLIE_1_FLASHON */
     QT_TR_NOOP("Flash Off"),       /*   4   for LED_COLLIE_1_FLASHOFF */
     QT_TR_NOOP("Very Fast Blink"), /*   5   for LED_COLLIE_1_VFSTBLINK */
     QT_TR_NOOP("Fast Blink"),      /*   6   for LED_COLLIE_1_FASTBLINK */
     QT_TR_NOOP("Normal Blink"),    /*   7   for LED_COLLIE_1_NORMBLINK */
     QT_TR_NOOP("Slow Blink"),      /*   8   for LED_COLLIE_1_SLOWBLINK */
     QT_TR_NOOP("Soft Blink"),      /*   9   for LED_COLLIE_1_SOFTBLINK */
     QT_TR_NOOP("Soft Flash")       /*  10   for LED_COLLIE_1_SOFTFLASH */
  };

  if (led >= LED_COLLIE_1_DEFAULT && led <= LED_COLLIE_1_SOFTFLASH)
    return tr(labels[led]);

  return tr("Invalid Led");
}

QString AlarmDetails::weekdaysFlagsLabel(Weekdays weekdaysFlags)
{
  static const char* labels[] =
  {
    QT_TR_NOOP("Mon"),
    QT_TR_NOOP("Tue"),
    QT_TR_NOOP("Wed"),
    QT_TR_NOOP("Thu"),
    QT_TR_NOOP("Fri"),
    QT_TR_NOOP("Sat"),
    QT_TR_NOOP("Sun")
  };

  QString s;

  for (int i = 0; i < NUM_WEEKDAYS; i++)
  {
    if (weekdaysFlags & flags[i])
      s.append(tr(labels[i])).append(" ");
  }

  return s;
}

