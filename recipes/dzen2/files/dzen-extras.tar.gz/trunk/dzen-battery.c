/* dzen-battery.c - Takes input from /sys/class/power_supply files,
 * outputs battery percentage. Distributed under the MIT Licence.
 */

#include <stdio.h>

int main(int argc, char *argv[])
{
	FILE *now_file, *full_file;
	int now, full;

	if (argc != 3) {
		fprintf(stderr, "Usage: %s <current-charge-file> <full-charge-file>\n", argv[0]);
		return 128;
	}

	if ((now_file = fopen(argv[1], "r")) == NULL) {
		fprintf(stderr, "Error: Could not open file '%s'\n", argv[1]);
		fclose(now_file);
		return 255;
	}

	if ((full_file = fopen(argv[2], "r")) == NULL ) {
		fprintf(stderr, "Error: Could not open file '%s'\n", argv[2]);
		fclose(full_file);
		return 255;
	}

	fscanf(now_file, "%d", &now);
	fscanf(full_file, "%d", &full);

	return ((now * 100) / full);
}
