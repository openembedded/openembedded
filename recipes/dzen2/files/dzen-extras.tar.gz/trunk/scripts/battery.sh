#!/bin/sh
#
# Calculates remaining battery life by polling /sys, first for each
# device seperately and if no devices are matched, using a generic
# solution.
#
# Generic function for checking charging status.
batt_icon()
{
	grep "Charging" $SYS_BAT/status &>/dev/null
	if [ $? -eq 0 ]
	then
		BATT_ICON="$AC_ICON"
	else
		BATT_ICON="$NOAC_ICON"
	fi
}
# Generic machine function. Fallback for when no devices are matched.
generic()
{
	BATT=`dzen-battery $SYS_BAT/energy_now $SYS_BAT/energy_full`
	batt_icon
}
# Function for the HP h1940 device.
h1940()
{
	BATT=`dzen-battery $SYS_BAT/charge_now $SYS_BAT/charge_full`
	batt_icon
}
# Function for the HP rx1950 device.
rx1950()
{
	BATT=`dzen-battery $SYS_BAT/charge_now $SYS_BAT/charge_full`
	batt_icon
}
# Function for the Qi-Hardware Ben Nanonote
nanonote()
{
	BATT=`cat $SYS_BAT/capacity`
	batt_icon
}

$@
