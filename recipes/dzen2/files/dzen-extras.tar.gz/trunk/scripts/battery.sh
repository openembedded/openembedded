#!/bin/sh
#
# Calculates remaining battery life by polling /sys, first for each
# device seperately and if no devices are matched, using a generic
# solution.
#
# Generic machine function. Fallback for when no devices are matched.
generic()
{
	now=`cat $SYS_BAT/energy_now`
	full=`cat $SYS_BAT/energy_full`

	BATT=`expr $now \* 100 / $full`
}
# Function for the HP h1940 and rx1950 devices.
h1940()
{
	now=`cat $SYS_BAT/charge_now`
	full=`cat $SYS_BAT/charge_full`

	BATT=`expr $now \* 100 / $full`
}
# Function for the Qi-Hardware Ben Nanonote
nanonote()
{
	BATT=`cat $SYS_BAT/capacity`	
}
# Generic function for checking charging status.
batt_icon()
{
	grep "Charging" $SYS_BAT/status &>/dev/null
	if [ $? -eq 0 ]
	then
		BATT_ICON="$AC_ICON"
	else
		BATT_ICON="$NOAC_ICON"
	fi
}

# Machine: Ben Nanonote
if [ "`grep system /proc/cpuinfo | awk '{print $4}'`" = "JZ4740" ]
then
	SYS_BAT="/sys/class/power_supply/battery"
	nanonote
# Machine: HP iPAQ h1940
elif [ "`grep Hardware /proc/cpuinfo | awk '{print $3}'`" = "IPAQ-H1940" ]
then
	SYS_BAT="/sys/class/power_supply/main-battery"
	h1940
# Machine: HP iPAQ rx1950
elif [ "`grep Hardware /proc/cpuinfo | awk '{print $5}'`" = "RX1950" ]
then
	SYS_BAT="/sys/class/power_supply/main-battery"
	h1940
# Machine: Generic
else
	for i in `ls /sys/class/power_supply`
	do
		SYS_BAT=`grep -H Battery /sys/class/power_supply/$i/type | cut -d/ -f-5`
	done
	generic
fi

batt_icon
