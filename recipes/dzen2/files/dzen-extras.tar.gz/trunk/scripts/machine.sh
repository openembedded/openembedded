#!/bin/sh
#
# Machine detection. Add yours on the top.
#
# Machine: Ben Nanonote
if [ "`grep system /proc/cpuinfo | awk '{print $4}'`" = "JZ4740" ]
then
	export MACHINE="nanonote"
	export SYS_BAT="/sys/class/power_supply/battery"
# Machine: HP iPAQ h1940
elif [ "`grep Hardware /proc/cpuinfo | awk '{print $3}'`" = "IPAQ-H1940" ]
then
	export MACHINE="h1940"
	export SYS_BAT="/sys/class/power_supply/main-battery"
# Machine: HP iPAQ rx1950
elif [ "`grep Hardware /proc/cpuinfo | awk '{print $5}'`" = "RX1950" ]
then
	export MACHINE="rx1950"
	export SYS_BAT="/sys/class/power_supply/main-battery"
# Machine: Generic
else
	export MACHINE="generic"
	for i in `ls /sys/class/power_supply`
	do
		export SYS_BAT=`grep -H Battery /sys/class/power_supply/$i/type | cut -d/ -f-5`
	done
fi
