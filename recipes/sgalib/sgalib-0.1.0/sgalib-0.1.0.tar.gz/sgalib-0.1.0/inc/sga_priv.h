/******************************************************************************
 * � copyright STMicroelectronics, 2007. All rights reserved. For
 * information, STMicroelectronics reserves the right to license this
 * software concurrently under separate license conditions.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *****************************************************************************/
/******************************************************************************
 * Subsystem	: SGA Library
 * File			: sga_priv.h
 * Description	: This file contains the private headers for SGA
 *				library. This will be used to access SGA for
 *				accelerating graphics.
 * Created		: 15.04.2007
 * Version		: 1.5
 *
 *****************************************************************************/
#ifndef __SGALIB_PRIV_H__
#define __SGALIB_PRIV_H__

#ifdef __cplusplus
extern "C" {
#endif

///////////////////////////////////////////////////////////////////////////////
// include files
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <math.h>
#include <linux/fb.h>
#include "sga_p.h"
#include "sga_interface.h"	// SGA driver interface header

///////////////////////////////////////////////////////////////////////////////
// defines and macros
///////////////////////////////////////////////////////////////////////////////

//-----------------------------------------------------------------------------
// Start of user controllable defines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Set the FB_24BPP macro below to 1 in case the library is to be run on a
// 24bpp LCD panel. For 16bpp panels, set the macro to 0.
 #define FB_24BPP 1

//-----------------------------------------------------------------------------
// End of user controllable defines
//-----------------------------------------------------------------------------



#define SGA_RIS 4
#define SGA_ICR 7
#define SGA_SITR 12
#define BATCH_INT_MASK 0xffffff03
#define CACHE_CONFIG 0x7F1D0

#define BATCH_SIZE	1024 * 2
#define SGA_DEVICE 	"/dev/SGA"


#ifndef MIN
  #define MIN(a, b)  (((a) < (b)) ? (a) : (b))
#endif

#ifndef MAX
  #define MAX(a, b)  (((a) > (b)) ? (a) : (b))
#endif

#define SGA_WAIT_PIPE_EMPTY_COMPLETE_FW(pAddr) do { \
		*(pAddr) = WAIT_PIPE_EMPTY | SGA_WAIT_PIPE_EMP_COMPLETE; } while(0)

#define SGA_SETINT_FW(pAddr, int_id) do { \
		*(pAddr) = SEND_INTERRUPT | (int_id); } while(0)

#define SGA_RET_INST_FW(pAddr) do{ *(pAddr) = RETURN; } while(0)



#define SGA_Start_Task(batch_id) do {\
	clear_sga_irq_status((1 << pGD->IntPosition[batch_id]));\
	pGD->dev_addr[SGA_SITR] |= (1 << (batch_id));\
} while (0)


#define SGA_Wait_Batch(batch_id) do {\
	{\
	unsigned int irq_src;\
	do {\
		irq_src = get_sga_irq_status((1 << pGD->IntPosition[batch_id]));\
	} while(!irq_src);\
	}\
} while(0)

#define SGA_TASK_START(pTask) do {\
	t_uint32* pBatchFw = &(pTask)->pBatch_Fw[(pTask)->no_cmd];\
	SGA_WAIT_PIPE_EMPTY_COMPLETE_FW(pBatchFw);\
	pBatchFw += 1;\
	pBatchFw[0] = IN0_SET_PIXEL_TYPE ;\
	pBatchFw += 1;\
	SGA_SETINT_FW(pBatchFw, (pTask)->int_id);\
	pBatchFw += 1;\
	SGA_RET_INST_FW(pBatchFw);\
	SGA_Start_Task((pTask)->batch_id);\
	(pTask)->run_flag = 1;	\
} while(0)


#define SGA_DRAWRECT_FW(pTask, x0, x1, y0, y1) do {\
	 t_uint32    *pBatchFw = &pTask->pBatch_Fw[pTask->no_cmd];\
        pBatchFw[0] = SET_POINT0 | ((0x7FF & (x0)) << 12) | (0x7FF & (y0));\
        pBatchFw[1] = SET_POINT1 | ((0x7FF & (x1)) << 12) | (0x7FF & (y1));\
        pBatchFw[2] = DRAW_RECTANGLE;\
	 pTask->no_cmd += 3;\
} while(0)

#define SGA_DRAWLINE_FW(pTask, x0, x1, y0, y1) do {\
	 t_uint32    *pBatchFw = &pTask->pBatch_Fw[pTask->no_cmd];\
        pBatchFw[0] = SET_POINT0 | ((0x7FF & (x0)) << 12) | (0x7FF & (y0));\
        pBatchFw[1] = SET_POINT1 | ((0x7FF & (x1)) << 12) | (0x7FF & (y1));\
        pBatchFw[2] = DRAW_LINE;\
	 pTask->no_cmd += 3;\
} while(0)
#define SGA_BufCfgFw_In0_Activate_Generic(buf_addr, ln_jump, x_size, \
								y_size, x_shift, y_shift, pixel_format) do {\
	t_uint32    *pBatchFw = &pTask->pBatch_Fw[pTask->no_cmd];\
	pBatchFw[0] = IN0_BASE_ADD_MSB | (0xFF & ((buf_addr) >> 24));\
	pBatchFw[1] = IN0_BASE_ADD | (0xFFFFFF & (buf_addr));\
	pBatchFw[2] = IN0_SET_LINE_JUMP | (0x1FFF & (ln_jump));\
	pBatchFw[3] = IN0_SET_SIZE_XY | ((0x7FF & (x_size)) << 12) \
									| (0x7FF & (y_size));\
	pBatchFw[4] = IN0_SET_DELTA_XY | ((0xFFF & (x_shift)) << 12) \
									| (0xFFF & (y_shift));\
	pBatchFw[5] = IN0_SET_PIXEL_TYPE | (FB_24BPP << 14) |  (1 << 12) \
							| (1 << 8) | (1 << 4) | (0xF & (pixel_format));\
	pTask->no_cmd += 6;\
} while(0)

#define SGA_BufCfgFw_Out_Activate_Generic(pTask, buf_addr, ln_jump, x_size, \
				y_size, scissor_clip_x, scissor_clip_y, pixel_format) do {\
	t_uint32    *pBatchFw = &pTask->pBatch_Fw[pTask->no_cmd];\
	pBatchFw[0] = OUT_BASE_ADD_MSB | (0xFF & ((buf_addr) >> 24));\
	pBatchFw[1] = OUT_BASE_ADD | (0xFFFFFF & (buf_addr));\
	pBatchFw[2] = OUT_SET_LINE_JUMP | (ln_jump);\
	pBatchFw[3] = OUT_SET_SIZE_XY | ((x_size) << 12) | (y_size);\
	pBatchFw[4] = OUT_SET_BASE_XY | ((scissor_clip_x) << 12) \
								| (scissor_clip_y);\
	pBatchFw[5] = OUT_SET_PIXEL_TYPE | (FB_24BPP << 14) | (1 << 12) \
								| (1 << 8) | (1 << 4) | (pixel_format);\
	pTask->no_cmd += 6;\
} while(0)

/*Biju Modifications*/

#define SGA_TASK_START_COMP(pTask) do {\
	t_uint32* pBatchFw = &(pTask)->pBatch_Fw[(pTask)->no_cmd];\
	SGA_SETINT_FW(pBatchFw, (pTask)->int_id);\
	pBatchFw += 1;\
	SGA_RET_INST_FW(pBatchFw);\
	SGA_Start_Task((pTask)->batch_id);\
	(pTask)->run_flag = 1;	\
} while(0)


#define SGA_Out_Buf_Config_Activate(pTask, buf_addr, ln_jump, x_size, \
				y_size, scissor_clip_x, scissor_clip_y, pixel_format, is_depack_mode) do {\
	t_uint32    *pBatchFw = &pTask->pBatch_Fw[pTask->no_cmd];\
	*pBatchFw++ = OUT_BASE_ADD_MSB | (0xFF & ((buf_addr) >> 24));\
	*pBatchFw++ = OUT_BASE_ADD | (0xFFFFFF & (buf_addr));\
	*pBatchFw++ = OUT_SET_LINE_JUMP | (ln_jump);\
	*pBatchFw++ = OUT_SET_SIZE_XY | ((x_size) << 12) | (y_size);\
	*pBatchFw++ = OUT_SET_BASE_XY | ((scissor_clip_x) << 12) \
								| (scissor_clip_y);\
	*pBatchFw++ = OUT_SET_PIXEL_TYPE | (((is_depack_mode)&0x01)<< 14) \
								| (1 << 4) | (pixel_format);\
	pTask->no_cmd += 6;\
} while(0)


#define SGA_In0_Buf_Config_Activate(pBatchFw,buf_addr, ln_jump, x_size, \
								y_size, x_shift, y_shift, pixel_format, is_depack_mode,no_cmd) do {\
	*(pBatchFw)++ = IN0_BASE_ADD_MSB | (0xFF & ((buf_addr) >> 24));\
	*(pBatchFw)++ = IN0_BASE_ADD | (0xFFFFFF & (buf_addr));\
	*(pBatchFw)++ = IN0_SET_LINE_JUMP | (0x1FFF & (ln_jump));\
	*(pBatchFw)++ = IN0_SET_SIZE_XY | ((0x7FF & (x_size)) << 12) \
									| (0x7FF & (y_size));\
	*(pBatchFw)++ = IN0_SET_DELTA_XY | ((0xFFF & (x_shift)) << 12) \
									| (0xFFF & (y_shift));\
	*(pBatchFw)++ = IN0_SET_PIXEL_TYPE | (((is_depack_mode)&0x01)<< 14) |  (1 << 12) \
							| (1 << 8) | (1 << 4) | (0xF & (pixel_format));\
	(no_cmd) += 6;\
} while(0)

#define SGA_In1_Buf_Config_Activate(pBatchFw,buf_addr, ln_jump, x_size, \
								y_size, x_shift, y_shift, pixel_format, is_depack_mode,no_cmd) do {\
	*(pBatchFw)++ = IN1_BASE_ADD_MSB | (0xFF & ((buf_addr) >> 24));\
	*(pBatchFw)++ = IN1_BASE_ADD | (0xFFFFFF & (buf_addr));\
	*(pBatchFw)++ = IN1_SET_LINE_JUMP | (0x1FFF & (ln_jump));\
	*(pBatchFw)++ = IN1_SET_SIZE_XY | ((0x7FF & (x_size)) << 12) \
									| (0x7FF & (y_size));\
	*(pBatchFw)++ = IN1_SET_DELTA_XY | ((0xFFF & (x_shift)) << 12) \
									| (0xFFF & (y_shift));\
	*(pBatchFw)++ = IN1_SET_PIXEL_TYPE | (((is_depack_mode)&0x01)<< 14) |  (1 << 12) \
							| (1 << 8) | (1 << 4) | (0xF & (pixel_format));\
	(no_cmd) += 6;\
} while(0)


#define SGA_In2_Buf_Config_Activate(pBatchFw,buf_addr, ln_jump, x_size, \
								y_size, x_shift, y_shift, pixel_format, is_depack_mode,no_cmd) do {\
	*(pBatchFw)++ = IN2_BASE_ADD_MSB | (0xFF & ((buf_addr) >> 24));\
	*(pBatchFw)++ = IN2_BASE_ADD | (0xFFFFFF & (buf_addr));\
	*(pBatchFw)++ = IN2_SET_LINE_JUMP | (0x1FFF & (ln_jump));\
	*(pBatchFw)++ = IN2_SET_SIZE_XY | ((0x7FF & (x_size)) << 12) \
									| (0x7FF & (y_size));\
	*(pBatchFw)++ = IN2_SET_DELTA_XY | ((0xFFF & (x_shift)) << 12) \
									| (0xFFF & (y_shift));\
	*(pBatchFw)++ = IN2_SET_PIXEL_TYPE | (((is_depack_mode)&0x01)<< 14) |  (1 << 12) \
							| (1 << 8) | (1 << 4) | (0xF & (pixel_format));\
	(no_cmd) += 6;\
} while(0)


#define SGA_In0_Buf_Config_DeActivate(pBatchFw,no_cmd) do {\
	*(pBatchFw)++ = IN0_SET_PIXEL_TYPE ;\
	(no_cmd) += 1;\
} while(0)

#define SGA_In1_Buf_Config_DeActivate(pBatchFw,no_cmd) do {\
	*(pBatchFw)++ = IN1_SET_PIXEL_TYPE ;\
	(no_cmd) += 1;\
} while(0)

#define SGA_In2_Buf_Config_DeActivate(pBatchFw,no_cmd) do {\
	*(pBatchFw)++ = IN2_SET_PIXEL_TYPE ;\
	(no_cmd) += 1;\
} while(0)

#define SGA_Blend_DeActivate(pBatchFw,no_cmd) do {\
	*(pBatchFw)++ = SET_BLEND_ENV ;\
	(no_cmd) += 1;\
} while(0)


/*end*/



#define DBGPRINTERR printf

#ifdef __RELEASE
  int DBGPRINTF(const char *format, ...)
    {return NULL;}
#else // __RELEASE
  #define DBGPRINTF	printf
#endif // __RELEASE

///////////////////////////////////////////////////////////////////////////////
// private structs
///////////////////////////////////////////////////////////////////////////////

typedef struct
{
        t_uint8  			batch_id;
        t_uint8  			int_id;
        t_uint32 			*pBatch_Fw;
        t_uint32 			no_cmd;
        t_uint32			task_fw_size; // default fw size
        t_bool				run_flag; // fw offset for task_run
        t_bool				TaskChained;
        t_uint32            Component_Alpha;
        t_uint32            Component_ARGB;
		t_bool              Dst_PackMode;

}
GraphicsData,*PGraphicsData;

typedef struct
{
	UINT4 *batch_addr[MAX_BATCHES];
	GraphicsData Task[MAX_BATCHES];
	UINT4 *fb_addr, *dev_addr;
	UINT4 fb_phy;
	int fd_sga;
	UINT4 *fw_addr;

	unsigned int ScrnWidth, ScrnHeight, ScrnLineJump;
	unsigned int TotalFbMem, ScrnClipX, ScrnClipY, ScrnBpp;

        t_uint8 			cur_batch_no;
        t_uint8 			IntPosition[MAX_BATCHES];
        PSga_bitmap 		pSrcPixmap;
        PSga_bitmap 		pDstPixmap;
        PSga_bitmap 		pMaskPixmap;

        t_uint32			dst_addr;
        t_uint32			src_addr;
        t_uint32			mask_addr;

        t_uint32 			OpMode;
}
GData, *PGData;

/*Constant data declarations*/

static const t_sga_pixel_opmode_config OpMode_Conf=
{
	0,                         /*precision*/
	SGA_PIXEL_OPERATOR_ACTIVE, /*t_sga_pixel_op_mode*/
	FALSE,                     /*freeze_index_cnt*/
	TRUE,                      /*stop_concatenate*/
	FALSE,                     /*mask z bits  */
	FALSE,                     /*mask s1 bits  */
	FALSE,                     /*mask s0 bits  */
	FALSE,                     /*mask a bits  */
	FALSE,                     /*mask r bits  */
	FALSE,                     /*mask g bits  */
	FALSE,                     /*mask b bits  */
	SGA_DITHERING_RGB,         /*t_sga_dithering_mode*/
	SGA_FRAME_BLEND_ACTIVE,    /*t_sga_rop_blend*/
	0,                         /*rop_type*/
	FALSE,                     /* TRUE - Activates the scissor operator */
	TRUE                       /* TRUE - Activates the Tie Break */
};

static const t_sga_wait_config wait_config=
{
	SGA_WAIT_PIPE_EMPTY,  /*  Wait instruction to be used   */
	0,					  /* Wait period * 256 clock cycles for wait synchro instructions */
	0,					  /* Synchro port id     */
	SGA_WAIT_PIPE_EMP_COMPLETE /*t_sga_wait_pipe_emp_type*/
};

static const t_sga_blend_config  pictop_over_pass1_blend=
{
	0,                       /*argb_colour*/
	SGA_BLEND_OP_ADD, 		 /*blend_operations*/
	SGA_BLEND_SRC_COEF_0,	 /*RGB_Fragment*/
	SGA_BLEND_SRC_COEF_0,	 /*Alpha_Fragment*/
	SGA_BLEND_SRC_COEF_1_RGB_FRAGMENT,    /*RGB_Frame*/
	SGA_BLEND_SRC_COEF_1     /*Alpha_Frame*/
};

static const t_sga_blend_config  pictop_over_pass2_blend=
{
	0,                       /*argb_colour*/
	SGA_BLEND_OP_ADD, 		 /*blend_operations*/
	SGA_BLEND_SRC_COEF_1,	 /*RGB_Fragment*/
	SGA_BLEND_SRC_COEF_1,	 /*Alpha_Fragment*/
	SGA_BLEND_SRC_COEF_1,    /*RGB_Frame*/
	SGA_BLEND_SRC_COEF_1     /*Alpha_Frame*/
};

static const t_sga_blend_config  pictop_add_blend=
{
	0,                       /*argb_colour*/
	SGA_BLEND_OP_ADD, 		 /*blend_operations*/
	SGA_BLEND_SRC_COEF_1,	 /*RGB_Fragment*/
	SGA_BLEND_SRC_COEF_1,	 /*Alpha_Fragment*/
	SGA_BLEND_SRC_COEF_1,    /*RGB_Frame*/
	SGA_BLEND_SRC_COEF_1     /*Alpha_Frame*/
};

static t_sga_texture_config pictop_over_texture=
{
	SGA_TEX_SOURCE_0,              /*Textureid*/
	0,                             /*argb color*/
	SGA_TEX_ENV_MODULATE,          /*RGB function*/
	SGA_TEX_ENV_MODULATE,          /*Alpha function*/

	SGA_TEX_ENV_SOURCE_CST_COLOUR, /*source_0_rgb*/
	SGA_TEX_ENV_SOURCE_TEXTURE,    /*source_1_rgb*/
    SGA_TEX_ENV_SOURCE_TEXTURE,    /*source_2_rgb*/
    SGA_TEX_ENV_SOURCE_CST_COLOUR, /*source_0_a*/
    SGA_TEX_ENV_SOURCE_TEXTURE,    /*source_1_a*/
    SGA_TEX_ENV_SOURCE_TEXTURE,    /*source_2_a*/

    SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_0_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_1_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_2_rgb*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_0_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_1_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_2_a*/

	0xFF,                          /*rgb_scale*/
    0xFF                           /*a_scale*/

};

static t_sga_texture_config pictop_over_texture0[MAX_BATCHES];


static const t_sga_texture_config pictop_over_texture1=
{
	SGA_TEX_SOURCE_1,                /*Textureid*/
	0,                               /*argb color*/
	SGA_TEX_ENV_REPLACE,             /*RGB function*/
	SGA_TEX_ENV_REPLACE,             /*Alpha function*/

	SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_0_rgb*/
	SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_1_rgb*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_2_rgb*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_0_a*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_1_a*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_2_a*/

    SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_0_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_1_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_2_rgb*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_0_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_1_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_2_a*/

	0xFF,                          /*rgb_scale*/
    0xFF                           /*a_scale*/

};

static const t_sga_texture_config pictop_add_texture0=
{
	SGA_TEX_SOURCE_0,                /*Textureid*/
	0,                               /*argb color*/
	SGA_TEX_ENV_REPLACE,             /*RGB function*/
	SGA_TEX_ENV_REPLACE,             /*Alpha function*/

	SGA_TEX_ENV_SOURCE_TEXTURE, /*source_0_rgb*/
	SGA_TEX_ENV_SOURCE_TEXTURE, /*source_1_rgb*/
    SGA_TEX_ENV_SOURCE_TEXTURE, /*source_2_rgb*/
    SGA_TEX_ENV_SOURCE_TEXTURE, /*source_0_a*/
    SGA_TEX_ENV_SOURCE_TEXTURE, /*source_1_a*/
    SGA_TEX_ENV_SOURCE_TEXTURE, /*source_2_a*/

    SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_0_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_1_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_2_rgb*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_0_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_1_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_2_a*/

	0xFF,                          /*rgb_scale*/
    0xFF                           /*a_scale*/
};

static const t_sga_texture_config pictop_add_without_mask_texture1=
{
	SGA_TEX_SOURCE_1,                /*Textureid*/
	0,                               /*argb color*/
	SGA_TEX_ENV_REPLACE,             /*RGB function*/
	SGA_TEX_ENV_REPLACE,             /*Alpha function*/

	SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_0_rgb*/
	SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_1_rgb*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_2_rgb*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_0_a*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_1_a*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_2_a*/

    SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_0_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_1_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_2_rgb*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_0_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_1_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_2_a*/

	0xFF,                          /*rgb_scale*/
    0xFF                           /*a_scale*/

};

static const t_sga_texture_config pictop_add_texture1=
{
	SGA_TEX_SOURCE_1,                /*Textureid*/
	0,                               /*argb color*/
	SGA_TEX_ENV_MODULATE,             /*RGB function*/
	SGA_TEX_ENV_MODULATE,             /*Alpha function*/

	SGA_TEX_ENV_SOURCE_TEXTURE,      /*source_0_rgb*/
	SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_1_rgb*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_2_rgb*/
    SGA_TEX_ENV_SOURCE_TEXTURE     , /*source_0_a*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_1_a*/
    SGA_TEX_ENV_SOURCE_PREVIOUS_COL, /*source_2_a*/

    SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_0_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_1_rgb*/
	SGA_TEX_ENV_RGB_OPR_COLOUR,    /*operand_2_rgb*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_0_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_1_a*/
	SGA_TEX_ENV_A_OPR_ALPHA,       /*operand_2_a*/

	0xFF,                          /*rgb_scale*/
    0xFF                           /*a_scale*/
};




///////////////////////////////////////////////////////////////////////////////
// internal function declarations
///////////////////////////////////////////////////////////////////////////////

static t_sga_error sgalib_config(void);
static t_sga_error sgalib_create_task(PGraphicsData pTask);
static t_sga_error sgalib_delete_task(PGraphicsData pTask);
static t_sga_error sgalib_reset(void);
t_uint32 get_sga_irq_status(unsigned int irq_src_mask);
static t_sga_error sgalib_init_task(PGraphicsData pTask);
static int sgalib_get_a_task(void);
static int sgalib_get_next_task(int task_handle);

static int sgalib_composite_pictop_over(int task_handle, int srcX, int srcY,
					int maskX, int maskY,int dstX, int dstY,
					int width,int height);

static int sgalib_pictop_add(int task_handle, int srcX, int srcY,
					int maskX, int maskY,int dstX, int dstY,
					int width,int height);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __SGALIB_PRIV_H__
