/******************************************************************************
 * � copyright STMicroelectronics, 2007. All rights reserved. For
 * information, STMicroelectronics reserves the right to license this
 * software concurrently under separate license conditions.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *****************************************************************************/
/******************************************************************************
 * Subsystem	: SGA Library
 * File			: sga_lib.h
 * Description	: This file contains the API for SGA library. This
 *		will be used to access SGA for accelerating graphics.
 * Created		: 15.04.2007
 * Version		: 1.5
 *
 *****************************************************************************/

#ifndef __SGA_LIBRARY_H__
#define __SGA_LIBRARY_H__

#ifdef __cplusplus
extern "C" {
#endif

///////////////////////////////////////////////////////////////////////////////
// Enumerations
///////////////////////////////////////////////////////////////////////////////

typedef enum
{
        SGALIB_OPEN_ERR = -300,
        SGALIB_COORD_ERR,
        SGALIB_MEM_ALLOC_ERR,
        SGALIB_ARG_ERR,
        SGALIB_FORMAT_ERR,
        SGALIB_IOCTL_ERR,
        SGALIB_ERR,		// need to add other error codes
        SGALIB_SUCCESS = 0,
}t_sgalib_errs;

typedef enum
{
        SGALIB_MONO_1BPP,
        SGALIB_MONO_2BPP,
        SGALIB_MONO_4BPP,
        SGALIB_MONO_8BPP,
        SGALIB_RGB8,
        SGALIB_ARGB12,
        SGALIB_RGBA12,
        SGALIB_RGBA15,
        SGALIB_RGB16,		// currently only this is supported
        SGALIB_ARGB15,
        SGALIB_ARGB24,
        SGALIB_RGBA24,
        SGALIB_YUV422,
        SGALIB_LA16,
        SGALIB_ZARGB14,
        SGALIB_ZARGB16
}t_sgalib_pixel_format;


typedef enum
{
	SGA_PictOpClear=0,
	SGA_PictOpSrc,
	SGA_PictOpDst,
	SGA_PictOpOver,
	SGA_PictOpOverReverse,
	SGA_PictOpIn,
	SGA_PictOpInReverse,
	SGA_PictOpOut,
	SGA_PictOpOutReverse,
	SGA_PictOpAtop,
	SGA_PictOpAtopReverse,
	SGA_PictOpXor,
	SGA_PictOpAdd,//12
	SGA_PictOpSaturate,
	SGA_PictOpMaximum,
	SGA_PictOpMinimum
}sga_composit_op;


typedef int t_handle;

///////////////////////////////////////////////////////////////////////////////
// Structures
///////////////////////////////////////////////////////////////////////////////

typedef struct
{
    char 		bitspp; 			// bits per pixel
	unsigned char *addr;			// address of the bitmap data
    unsigned int width;				// width of bitmap
    unsigned int height;			// height of bitmap
    unsigned int line_jump;			// number of bytes between pixels which
									// are below one another
    t_sgalib_pixel_format format; 	// format of the pixels in this bitmap
}
Sga_bitmap, *PSga_bitmap;			// structure of a bitmap


///////////////////////////////////////////////////////////////////////////////
// APIs
///////////////////////////////////////////////////////////////////////////////


/******************************************************************************
*
*  SGALIB_Init
*  __________________________________________________________________________
*
*  DESCRIPTION:	This is the Initialization function of the SGA library.
*		It must be called before using any other functions of the
*		SGA library.
*
*  INPUTS:	fb_addr 	: address of framebuffer
*		fb_width 	: width of visible framebuffer
*		fb_height 	: height of visible framebuffer
*		fb_bpp		: fb - bits per pixel
*		fb_smem_len	: total length of fb
*		fb_smem_start : start of fb (physical address)
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*					from t_sgalib_errs
*
*  REMARKS:	This function will open the SGA driver, allocate required memory,
*		map device registers into user space, create and initialize static
*		batches for common usecases that the library supports. The SGA
*		library is non-reentrant and it is assumed that only one application
*		will be using it. It could be made reentrant in the future, but will
*		require some design changes.
*		The call is synchronous and returns only after Init is complete.
*
******************************************************************************/
int SGALIB_Init(unsigned int *fb_addr, unsigned int fb_width,
				unsigned int fb_height, unsigned int fb_bpp,
				unsigned int fb_smem_len, unsigned int fb_smem_start);


/******************************************************************************
*
*  SGALIB_DeInit
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is the De-initialization function of the SGA library.
*		It must be called to close the SGA library properly.
*
*  INPUTS:	None
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	This function will reset the SGA, delete static batches,
*		unmap memory, close SGA and free allocated memory.
*		The call is synchronous and returns only after De-init is complete.
*
******************************************************************************/
int SGALIB_DeInit();


/******************************************************************************
*
*  SGALIB_PrepareSolid
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to prepare task for a solid fill. The colour is
*		specified along with the pixmap details. The pixmap maps onto an area
*		in the framebuffer and the subsequent fill operations will be on this
*		pixmap only.
*
*  INPUTS:	pPixmap : Pixmap detailing the canvas to be used for filling
*			colour : colour to be used for filling rectangles in all
*					subsequent SGALIB_Solid() calls. The format of the colour
*					depends on the format of the pixmap.
*
*  OUTPUTS:	None
*
*  RETURNS:
*			t_handle: handle to the task, OR
*			t_sgalib_errs in case of errors
*
*  REMARKS:	A call to SGALIB_PrepareSolid should have a matching call to
*		SGALIB_DoneSolid. The address in pPixmap should be aligned to word
*		boundary. The returned handle should be used in subsequent SGALIB_Solid
*		and SGALIB_DoneSolid calls. This function stores the pPixmap and colour
*		information in the tasks' context to be used in subsequent SGALIB_Solid
*		and SGALIB_DoneSolid calls. The call is synchronous.
*
******************************************************************************/
t_handle SGALIB_PrepareSolid(	PSga_bitmap pPixmap,
								unsigned int colour);


/******************************************************************************
*
*  SGALIB_Solid
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to draw a rectangle with a solid colour.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareSolid call
*			x1 : x-coordinate of top left corner of rectangle in pPixmap
*			y1 : y-coordinate of top left corner of rectangle in pPixmap
*			x2 : x-coordinate of bottom right corner of rectangle in pPixmap
*			y2 : y-coordinate of bottom right corner of rectangle in pPixmap
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareSolid call
*		preceeding this call. The colour is the one set in the
*		SGALIB_PrepareSolid call. The operations are only done on the pPixmap
*		from the SGALIB_PrepareSolid call. The coordinates are offsets from
*		the base address of the pPixmap. The call is synchronous.
*
******************************************************************************/
int SGALIB_Solid(t_handle handle, int x1, int y1, int x2, int y2);


/******************************************************************************
*
*  SGALIB_DoneSolid
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function is the logical completion of the solid fills.
*		It is the conclusion of the SGALIB_PrepareSolid call and closes its
*		context. When this function completes, it also ensures that all the
*		rectangle fill operations requested prior to this call are completed.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareSolid call
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareSolid call
*		preceeding this call. In case of immediate rendering, this function is
*		called after every draw rectangle operation and it ensures that the
*		primitive is rendered before returning. The call is synchronous.
*
******************************************************************************/
int SGALIB_DoneSolid(t_handle handle);


/******************************************************************************
*
*  SGALIB_PrepareCopy
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to prepare task for copy operations. The pixmaps
*		maps onto an area in the framebuffer and the subsequent copy
*		operations will be on these	pixmap only. This function prepares the
*		system from copying a rectangle somewhere from pSrcPixmap to
*		some place in pDstPixmap.
*
*  INPUTS:	pSrcPixmap : Pixmap detailing the source canvas for copying
*		pDstPixmap : Pixmap detailing the destination canvas for copying
*
*  OUTPUTS:	None
*
*  RETURNS:	t_handle: handle to the task, OR
*			t_sgalib_errs in case of errors
*
*  REMARKS:	A call to SGALIB_PrepareCopy should have a matching call to
*		SGALIB_DoneCopy. The address in pSrcPixmap and pDstPixmap should be
*		aligned to word boundary. The returned handle should be used in
*		subsequent SGALIB_Copy and SGALIB_DoneCopy calls. This function stores
*		the pSrcPixmap and pDstPixmap information in the tasks' context to be
*		used in subsequent SGALIB_Copy and SGALIB_DoneCopy calls. It is
*		possible for the pSrcPixmap and pDstPixmap to point to the same pixmap
*		in the framebuffer. The call is synchronous.
*
******************************************************************************/
t_handle SGALIB_PrepareCopy(PSga_bitmap pSrcPixmap, PSga_bitmap pDstPixmap);


/******************************************************************************
*
*  SGALIB_Copy
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to copy a rectangle from a place in the pSrcPixmap
*		to another place in pDstPixmap.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*			srcX : x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			srcY : y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			dstX : x-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			dstY : y-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			width : width of the rectangle to be copied
*			height : height of the rectangle to be copied
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. The call is synchronous.
*
******************************************************************************/
int SGALIB_Copy(t_handle handle, int srcX, int srcY, int dstX,
				int dstY, int width, int height);


/******************************************************************************
*
*  SGALIB_DoneCopy
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function is the logical completion of the copy calls.
*		It is the conclusion of the SGALIB_PrepareCopy call and closes its
*		context. When this function completes, it also ensures that all the
*		rectangle copy operations requested prior to this call are completed.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. In case of immediate rendering, this function is
*		called after every draw rectangle operation and it ensures that the
*		primitive is rendered before returning. The call is synchronous.
*
******************************************************************************/
int SGALIB_DoneCopy(t_handle handle);

/******************************************************************************
*
*  SGALIB_PrepareComposite
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to prepare task for copy operations. The pixmaps
*		maps onto an area in the framebuffer and the subsequent copy
*		operations will be on these	pixmap only. This function prepares the
*		system from copying a rectangle somewhere from pSrcPixmap to
*		some place in pDstPixmap.
*
*  INPUTS:	pSrcPixmap : Pixmap detailing the source canvas for copying
*		pMaskBmp : Pixmap detailing the mask canvas for copying
*		pDstPixmap : Pixmap detailing the destination canvas for copying
*
*  OUTPUTS:	None
*
*  RETURNS:	t_handle: handle to the task, OR
*			t_sgalib_errs in case of errors
*
*  REMARKS:	A call to SGALIB_PrepareCopy should have a matching call to
*		SGALIB_DoneCopy. The address in pSrcPixmap and pDstPixmap should be
*		aligned to word boundary. The returned handle should be used in
*		subsequent SGALIB_Copy and SGALIB_DoneCopy calls. This function stores
*		the pSrcPixmap and pDstPixmap information in the tasks' context to be
*		used in subsequent SGALIB_Copy and SGALIB_DoneCopy calls. It is
*		possible for the pSrcPixmap and pDstPixmap to point to the same pixmap
*		in the framebuffer. The call is synchronous.
*
******************************************************************************/

t_handle SGALIB_PrepareComposite (int OpMode, PSga_bitmap pSrcBmp,
								PSga_bitmap pMaskBmp,PSga_bitmap pDstBmp);

/******************************************************************************
*
*  SGALIB_Composite
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to copy a rectangle from a place in the pSrcPixmap
*		to another place in pDstPixmap.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*			srcX : x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			srcY : y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			maskX : x-coordinate of top left corner of mask rectangle.
*					It is the offset from the base of the pMaskPixmap.
*			maskY : y-coordinate of top left corner of mask rectangle.
*					It is the offset from the base of the pMaskPixmap.
*			dstX : x-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			dstY : y-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			width : width of the rectangle to be copied
*			height : height of the rectangle to be copied
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. The call is synchronous.
*
******************************************************************************/

int SGALIB_Composite(int task_handle, int srcX, int srcY,
					int maskX, int maskY,int dstX, int dstY,
					int width,int height);

/******************************************************************************
*
*  SGALIB_DoneComposite
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function is the logical completion of the copy calls.
*		It is the conclusion of the SGALIB_PrepareCopy call and closes its
*		context. When this function completes, it also ensures that all the
*		rectangle copy operations requested prior to this call are completed.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. In case of immediate rendering, this function is
*		called after every draw rectangle operation and it ensures that the
*		primitive is rendered before returning. The call is synchronous.
*
******************************************************************************/

int SGALIB_DoneComposite(int task_handle);

/******************************************************************************
*
*  SGALIB_WaitMarker
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function is called to complete the asynchronous operations
*		of SGA. When this function returns, all the tasks of SGA are
*		assumed to be complete.
*
*  INPUTS:	None
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	None
*
******************************************************************************/
int SGALIB_WaitMarker();

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __SGA_LIBRARY_H__
