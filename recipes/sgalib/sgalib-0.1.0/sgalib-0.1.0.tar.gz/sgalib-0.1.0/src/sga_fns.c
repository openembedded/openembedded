/******************************************************************************
 * � copyright STMicroelectronics, 2007. All rights reserved. For
 * information, STMicroelectronics reserves the right to license this
 * software concurrently under separate license conditions.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *****************************************************************************/
/*
 * This module provides API routines for the NOMADIK SGA
 * Specification release related to this implementation:
 */

#include "sga.h"
#include "sga_p.h"
#include "sga_irqp.h"
#include "debug.h"

/*------------------------------------------------------------------------
 * Global Variables
 *----------------------------------------------------------------------*/
PRIVATE volatile t_sga_system_context   g_sga_system_context;

/*-----------------------------------------------------------------------------
 * DEBUG STUFF
 *---------------------------------------------------------------------------*/
#ifdef __DEBUG
#define MY_DEBUG_LEVEL_VAR_NAME myDebugLevel_SGA
#define MY_DEBUG_ID             myDebugID_SGA

t_dbg_level                             MY_DEBUG_LEVEL_VAR_NAME = DEBUG_LEVEL0;
t_dbg_id                                MY_DEBUG_ID = SGA_HCL_//DBG_ID;
#endif

/*---------------------------------------------------------------------------
*  Public Functions
*---------------------------------------------------------------------------*/


/****************************************************************************/
/* NAME			:	SGA_SetDbgLevel()										*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  : This routine enables to choose between different	  		*/
/*				  debug comment levels										*/
/* PARAMETERS	:                                                           */
/* 		IN  	:t_dbg_level sga_dbg_level:identify SGA debug level			*/
/*     InOut    :None                                                       */
/* 		OUT 	:None                                                	    */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if debug level exceed the certain   */
/*                                      level                               */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/

/****************************************************************************/
PUBLIC t_sga_error SGA_SetDbgLevel(IN t_dbg_level sga_dbg_level)
{
        t_sga_error error = SGA_OK;

        //DBGENTER1("Setting Debug Level to %d", sga_dbg_level);

#ifdef __DEBUG
        if (sga_dbg_level < 0xFFFFFFFF) /*Debug level should not exceed */
        {
                MY_DEBUG_LEVEL_VAR_NAME = sga_dbg_level;
                error = SGA_OK;
        } else {
                error = SGA_INVALID_PARAMETER;
        }
#endif
        //DBGEXIT0(error);
        return(error);
}

/****************************************************************************/
/* NAME			:	SGA_GetVersion() 	                	        		*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  : Return the version of the current SGA HCL API             */
/* PARAMETERS	:                                                           */
/* 		IN  	:None                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_version *p_version: contain the version of the HCL       */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_GetVersion(t_version *p_version)
{
        ////DBGENTER1("Get Version %lx", p_version);
        if (NULL == p_version) {
                return(SGA_INVALID_PARAMETER);
        }

        p_version->version = SGA_HCL_VERSION_ID;
        p_version->major = SGA_HCL_MAJOR_ID;
        p_version->minor = SGA_HCL_MINOR_ID;

        ////DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_GetBatchID() 	                	        		*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  : Get the Batch id resource of the SGA                      */
/* PARAMETERS	:                                                           */
/* 		IN  	:void                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint8* batch_id: contain SGA batch resource id           */
/*                                            (Range is  0-15)              */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_RESOURCE_NOT_AVIALABLE if requested resource is not    */
/*                                                         available        */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_GetBatchID(OUT t_uint8 *p_batch_id)
{
        t_uint8 i;

        ////DBGENTER1("Batch Id %lx", p_batch_id);
        if (NULL == p_batch_id) {
                return(SGA_INVALID_PARAMETER);
        }

        /*Check the available batch id  */
        for (i = 0; i < MAX_BATCHES; i++) {
                if (!((g_sga_system_context.batch_sem_id & (1 << i)) >> i)) {
                        g_sga_system_context.batch_sem_id |= (1 << i);
                        break;
                }
        }

        if (MAX_BATCHES == i) {
                ////DBGEXIT0(SGA_RESOURCE_NOT_AVIALABLE);
                return(SGA_RESOURCE_NOT_AVIALABLE);
        } else {
                *p_batch_id = i;
                ////DBGEXIT0(SGA_OK);
                return(SGA_OK);
        }
}

/****************************************************************************/
/* NAME			:	SGA_GetSemaphoreID() 	                	        	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  : Get the Semaphore id of the SGA                           */
/* PARAMETERS	:                                                           */
/* 		IN  	:void                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint8* p_sem_id:contain SGA semaphore resource id        */
/*                                            (Range is  0-15)              */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_RESOURCE_NOT_AVIALABLE if requested resource is not    */
/*                                                         available        */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_GetSemaphoreID(t_uint8 *p_sem_id)
{
        t_uint8 i;

        ////DBGENTER1("Sem Id %lx", p_sem_id);
        if (NULL == p_sem_id) {
                return(SGA_INVALID_PARAMETER);
        }

        /*Check the available Semaphore ids  */
    for (i = MAX_BATCHES; i < 32; i++)
    {
                if (!((g_sga_system_context.batch_sem_id & (1 << i)) >> i)) {
                        g_sga_system_context.batch_sem_id |= (1 << i);
                        break;
                }
        }

        if (32 == i) {
                ////DBGEXIT0(SGA_RESOURCE_NOT_AVIALABLE);
                return(SGA_RESOURCE_NOT_AVIALABLE);
        } else {
                *p_sem_id = i;

                ////DBGEXIT0(SGA_OK);
                return(SGA_OK);
        }
}

/****************************************************************************/
/* NAME			:	SGA_GetIntID() 	                        	        	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  : Get the interrupt  id of the  SGA                         */
/* PARAMETERS	:                                                           */
/* 		IN  	:None                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint8* p_ int_id:contain SGA semaphore interrupt  id     */
/*                                            (Range is  0-15)              */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_RESOURCE_NOT_AVIALABLE if requested resource is not    */
/*                                                         available        */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_GetIntID(OUT t_uint8 *p_int_id)
{
        t_uint8 i;
        ////DBGENTER1("Interrupt Id %lx", p_int_id);

        if (NULL == p_int_id) {
                return(SGA_INVALID_PARAMETER);
        }

        /*Check the available interrupts ids  */
        for (i = 0; i < 26; i++) {
                if (!((g_sga_system_context.interrupt_id & (1 << i)) >> i)) {
                        g_sga_system_context.interrupt_id |= (1 << i);
                        break;
                }
        }

        if (26 == i) {
                ////DBGEXIT0(SGA_RESOURCE_NOT_AVIALABLE);
                return(SGA_RESOURCE_NOT_AVIALABLE);
        } else {
                *p_int_id = i;

                ////DBGEXIT0(SGA_OK);
                return(SGA_OK);
        }
}

/****************************************************************************/
/* NAME			:	SGA_ReleaseBatchID() 	                   	        	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  : Release the SGA batch ID resource                         */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_uint8  batch_id: contain the batch id to be released     */
/*     InOut    :None                                                       */
/* 		OUT 	:None                                                       */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_ReleaseBatchID(IN t_uint8 batch_id)
{
        ////DBGENTER1("Relased Batch Id (%d)", batch_id);

    if (batch_id > MAX_BATCHES-1)
    {
                ////DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        /* Flag off the released batch id  */
        g_sga_system_context.batch_sem_id &= (~(t_uint32) (1 << batch_id));

        ////DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_ReleaseSemaphoreID() 	               	        	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  : Release the SGA batch  semaphore resource ID.             */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_uint32  sem_id:contain the semaphore id to be released   */
/*     InOut    :None                                                       */
/* 		OUT 	:None                                                       */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_ReleaseSemaphoreID(IN t_uint8 sem_id)
{
        ////DBGENTER1("Relased Sem Id (%d)", sem_id);
    if ((sem_id < MAX_BATCHES) || (sem_id > 31))
    {
                ////DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        /*Flag off the released semaphore id  */
        g_sga_system_context.batch_sem_id &= (~(t_uint32) (1 << sem_id));

        ////DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_ReleaseIntID() 	                       	        	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  : Release the SGA interrupt  resource ID.                   */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_uint8 int_id: contain the interrupt  id to be released   */
/*     InOut    :None                                                       */
/* 		OUT 	:None                                                       */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_ReleaseIntID(IN t_uint8 int_id)
{
        ////DBGENTER1("Relased Interrupt Id (%d)", int_id);
        if (int_id > 25) {
                ////DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        /* Flag off the Released interrupt id   */
        g_sga_system_context.interrupt_id &= (~(t_uint32) (1 << int_id));

        ////DBGEXIT0(SGA_OK);
        return(SGA_OK);
}


/****************************************************************************/
/* NAME			:	SGA_BuildStopInstrFirmware() 	               	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the stop instruction firmware*/
/* PARAMETERS	:                                                           */
/* 		IN  	:None                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildStopInstrFirmware(OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        ////DBGENTER0();

        if (NULL == p_instr_add || NULL == p_no_cmd) {
                ////DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = STOP;
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildReturnInstrFirmware() 	               	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the return  instruction      */
/*                                            firmware                      */
/* PARAMETERS	:                                                           */
/* 		IN  	:None                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildReturnInstrFirmware(OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = RETURN;
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildSendSynchroFirmware() 	               	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the SendSynchro  instruction */
/*                                            firmware                      */
/* PARAMETERS	:                                                           */
/* 		IN  	:None                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildSendSynchroFirmware(OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = SEND_SYNCHRO;

        /* number of commands inserted at the memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildSemaphoreConfigFirmware() 	           	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for semaphore   */
/*                                            configuration.                */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_uint8 sem_id:   Semaphore id                            */
/*               t_sga_semaphore_state sem_state:Semaphore state            */
/*                                           (set or reset )                */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildSemaphoreConfigFirmware
(
        IN t_uint8                  sem_id,
        IN t_sga_semaphore_state    sem_state,
        OUT t_uint32                *p_instr_add,
        OUT t_uint32                *p_no_cmd
)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (sem_id >= 32)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        switch (sem_state) {
        case SGA_SEMAPHORE_SET:
                *p_instr_add = SET_INSTR_TEST_REG | sem_id;
                break;

        case SGA_SEMAPHORE_RESET:
                *p_instr_add = CLR_INSTR_TEST_REG | sem_id;
                break;
        }

        /*number of commands inserted at the memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildTestSemaphoreFirmware() 	           	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*                               test Semaphore instruction.                */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_uint8 sem_id:   Semaphore id                            */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildTestSemaphoreFirmware(IN t_uint8 sem_id, OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (sem_id > 31)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = TST_INSTR_TEST_REG | sem_id;

        /* number of instructions inserted at memory location */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildSetIntFirmware() 	                 	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*                            set instruction.                              */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_uint32 int_id:    Interrupt  id(rage 0-25)               */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildSetIntFirmware(IN t_uint32 int_id, OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (int_id >= 26)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = SEND_INTERRUPT | int_id;

        /*number of commands inserted at the memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildWaitInstrFirmware() 	               	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for Wait        */
/*                                              instructions                */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_wait_config *p_wait:contain the wait instruction to  */
/*                                     be build and associated  parameters  */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildWaitInstrFirmware
(
        IN t_sga_wait_config    *p_wait,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        //DBGENTER0();
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_wait)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        switch (p_wait->wait) {
        case SGA_WAIT_SYNCHRO:
                *p_instr_add = WAIT_SYNCHRO | ((0xFFFFF & p_wait->wait_time) << 4) | (0x3 & p_wait->synchro_port);
                break;

        case SGA_WAIT_NEWSYNCHRO:
                *p_instr_add = WAIT_NEW_SYNCHRO | ((0xFFFFF & p_wait->wait_time) << 4) | (0x3 & p_wait->synchro_port);
                break;

        case SGA_WAIT_N_CYCLES:
                *p_instr_add = WAIT_N_CYCLES | (0xFFFFFF & p_wait->wait_time);
                break;

        case SGA_WAIT_PIPE_EMPTY:
                *p_instr_add = WAIT_PIPE_EMPTY | (0x1 & (t_uint32) p_wait->pipe_empty_type);
                break;

        default:
                break;
        }

        /*store the number of commands inserted at the memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildAhbInstrFirmware() 	               	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for AHB         */
/*                                              instruction                 */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_ahb_config* p_ahb:contain the Ahb instruction        */
/*                                      settings                            */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildAhbInstrFirmware
(
        IN t_sga_ahb_config *p_ahb,
        OUT t_uint32        *p_instr_add,
        OUT t_uint32        *p_no_cmd
)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_ahb)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = AHB | ((((t_uint32) p_ahb->active_autofetch) &0x1) << 8) | ((((t_uint32) p_ahb->hclk_lock) & 0x1) << 6) | ((0x3 & ((t_uint32) p_ahb->burst_type)) << 4) | (0xF & p_ahb->hprot);

        /*number of commands inserted at memory location */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildGotoInstrFirmware() 	               	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for Goto        */
/*                                              instruction                 */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_uint32 addr :contain goto (jump) address                 */
/*                (it must be quad word aligned, ie 3 lsb bits must be zero)*/
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildGotoInstrFirmware(IN t_uint32 addr, OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == addr) || (0x7 & ((t_uint32) addr))) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = GOTO | (((t_uint32) addr) >> 3);

        /*number of commands inserted at memory location */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildNoOpInstrFirmware() 	               	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for NoOp        */
/*                                              instruction                 */
/* PARAMETERS	:                                                           */
/* 		IN  	:None                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildNoOpInstrFirmware(OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();
        if ((NULL == p_instr_add) || (NULL == p_no_cmd)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = NO_OP;

        /*Number of commands inserted at memory location */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildGoSubInstrFirmware() 	               	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for GoSub       */
/*                                              instruction                 */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_uint32  addr :contain GoSub (jump) address               */
/*                (it must be quad word aligned, ie 3 lsb bits must be zero)*/
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildGoSubInstrFirmware(IN t_uint32 addr, OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == addr) || (0x7 & ((t_uint32) addr))) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = GOSUB | (((t_uint32) addr) >> 3);

        /*number of commands inserted at memory location */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildCacheControlFirmware() 	           	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for Cache       */
/*                                              instruction                 */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_cache_config* p_cache: contain the cache control     */
/*                                      settings                            */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildCacheControlFirmware
(
        IN t_sga_cache_config   *p_cache,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_cache)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        /*build the CacheControl command */
        *p_instr_add = CACHE_CTRL | ((((t_uint32) p_cache->bank_optm_disable ) &0x1) << 18) |
                       ((((t_uint32) p_cache->hardinit_text) & 0x1) << 17) | ((((t_uint32) p_cache->hardinit_out) &0x1) << 16) |
                       ((((t_uint32) p_cache->hardinit_in0) & 0x1) << 15) | ((((t_uint32) p_cache->autoinit_text) & 0x1) << 14) |
                       ((((t_uint32) p_cache->autoinit_out) & 0x1) << 13) | ((((t_uint32) p_cache->autoinit_in0) & 0x1) << 12) |
                       ((((t_uint32) p_cache->manualflush_text) & 0x1) << 11) | ((((t_uint32) p_cache->manualflush_out) &0x1) << 10) |
                       ((((t_uint32) p_cache->manualflush_in0) & 0x1) << 9) | ((((t_uint32) p_cache->autoflush_text) & 0x1) << 8) |
                       ((((t_uint32) p_cache->autoflush_out) & 0x1) << 7) | ((((t_uint32) p_cache->autoflush_in0) & 0x1) << 6) |
                       (
                               (((t_uint32) p_cache->mode) & 0x3) <<
                               4
                       ) |
                       ((((t_uint32) p_cache->cache_topo_out) & 0x1) << 3) |
                       ((((t_uint32) p_cache->cache_topo_in2) & 0x1) << 2) |
                       ((((t_uint32) p_cache->cache_topo_in1) & 0x1)<< 1) |
                       ((((t_uint32) p_cache->cache_topo_in0) & 0x1) << 0);

        /*Number of commands inserted at memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildBufferConfigFirmware() 	           	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               buffer(in0, in1,in2 and OUT) instructions                  */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_image_buffer buffer : specify the buffer             */
/*                                           ( in0/ in1/in2 /OUT)           */
/*               t_sga_buffer_config* p_buf_config: contain the buffer      */
/*                                                  configuration details   */
/*               t_sga_buffer_pixel_settings * p_pix_config:Contain the     */
/*                            pixel configuration details for the buffer    */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildBufferConfigFirmware
(
        IN t_sga_image_buffer           buffer,
        IN t_sga_buffer_config          *p_buf_config,
        IN t_sga_buffer_pixel_settings  *p_pix_config,
        OUT t_uint32                    *p_instr_add,
        OUT t_uint32                    *p_no_cmd
)
{
        t_uint32    i = 0, temp = 0;

        //DBGENTER0();
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_pix_config) || (NULL == p_buf_config)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }
        switch (buffer) {
        case SGA_IMAGE_BUFFER_IN0:
                p_instr_add[i++] = IN0_BASE_ADD_MSB | (0xFF & (p_buf_config->buffer_address >> 24));
                p_instr_add[i++] = IN0_BASE_ADD | (0xFFFFFF & (p_buf_config->buffer_address));
                p_instr_add[i++] = IN0_SET_LINE_JUMP | (0x1FFF & p_buf_config->line_jump);
                p_instr_add[i++] = IN0_SET_SIZE_XY | ((0x7FF & p_buf_config->x_size) << 12) | (0x7FF & p_buf_config->y_size);

                /*Buliding the firmware for in0 set delta XY   */
                temp = (((p_buf_config->x_shift) & 0xFFF) << 12) | ((p_buf_config->y_shift) & 0xFFF);

                p_instr_add[i++] = IN0_SET_DELTA_XY | temp;

                /*building the firmware for in0 set pixel type */
                temp = IN0_SET_PIXEL_TYPE | ((((t_uint32) p_pix_config->colour_to_zero) & 0x1) << 18) |
                       ((((t_uint32) p_pix_config->colour_conversion) & 0x1) << 17) | ((((t_uint32) p_pix_config->yuv_rgb) & 0x1) << 16) |
                       (
                               (((t_uint32) p_pix_config->truncate_to_16_235) & 0x1) <<
                               15
                       ) |
                       ((((t_uint32) p_pix_config->activate_depack) & 0x1) << 14) |
                       ((((t_uint32) p_pix_config->activate_flow) & 0x1) << 12) |
                       ((((t_uint32) p_pix_config->freeze_ahb_address) & 0x1) << 11) |
                       ((((t_uint32) p_pix_config->memory_bypass) & 0x1) << 10) |
                       ((((t_uint32) p_pix_config->dma_synchro) & 0x1) << 9) |
                       ((((t_uint32) p_pix_config->alpha_to_255)& 0x1) << 8) |
                       ((((t_uint32) p_pix_config->stencil_mode) & 0x3) << 6) |
                       ((((t_uint32) p_pix_config->exchange_red_blue) & 0x1) << 5) |
                       ((((t_uint32) p_pix_config->endian) & 0x1) << 4) |
                       (0xF & ((t_uint32) p_pix_config->pixel_format));

                /*            if (SGA_PIXEL_FORMAT_ARGB24 == p_pix_config->pixel_format)
                            {
                                temp |= (1 << 14);
                            }
                */
                p_instr_add[i++] = temp;

                break;

        case SGA_IMAGE_BUFFER_IN1:
                p_instr_add[i++] = IN1_BASE_ADD_MSB | (0xFF & (p_buf_config->buffer_address >> 24));
                p_instr_add[i++] = IN1_BASE_ADD | (0xFFFFFF & p_buf_config->buffer_address);
                p_instr_add[i++] = IN1_SET_LINE_JUMP | (0x1FFF & p_buf_config->line_jump);
                p_instr_add[i++] = IN1_SET_SIZE_XY | ((0x7FF & p_buf_config->x_size) << 12) | (0x7FF & p_buf_config->y_size);

                /*buliding the firmware for in1SetDeltaXY instruction  */
                temp = ((p_buf_config->x_shift & 0xFFF) << 12) | (p_buf_config->y_shift & 0xFFF);

                p_instr_add[i++] = IN1_SET_DELTA_XY | temp;

                /*building the firmware for in1 set pixel type */
                temp = IN1_SET_PIXEL_TYPE | ((((t_uint32) p_pix_config->colour_to_zero) & 0x1) << 18) |
                       ((((t_uint32) p_pix_config->colour_conversion) & 0x1) << 17) | ((((t_uint32) p_pix_config->yuv_rgb) & 0x1) << 16) |
                       ((((t_uint32) p_pix_config->truncate_to_16_235) & 0x1) << 15) | ((((t_uint32) p_pix_config->bilinear_mode) & 0x1) << 13) |
                       ((((t_uint32) p_pix_config->activate_depack) & 0x1) << 14) |
                       ((((t_uint32) p_pix_config->activate_flow) & 0x1) << 12) |
                       ((((t_uint32) p_pix_config->freeze_ahb_address) & 0x1) << 11) |
                       ((((t_uint32) p_pix_config->memory_bypass) & 0x1) << 10) |
                       ((((t_uint32) p_pix_config->dma_synchro) & 0x1) << 9) |
                       ((((t_uint32) p_pix_config->alpha_to_255) & 0x1) << 8) |
                       ((((t_uint32) p_pix_config->exchange_red_blue) & 0x1) << 5) |
                       ((((t_uint32) p_pix_config->endian) & 0x1) << 4) |
                       (0xF & ((t_uint32) p_pix_config->pixel_format));

                /*            if (SGA_PIXEL_FORMAT_ARGB24 == p_pix_config->pixel_format)
                            {
                                temp |= (1 << 14);
                            }
                */
                p_instr_add[i++] = temp;

                break;

        case SGA_IMAGE_BUFFER_IN2:
                p_instr_add[i++] = IN2_BASE_ADD_MSB | (0xFF & (p_buf_config->buffer_address >> 24));
                p_instr_add[i++] = IN2_BASE_ADD | (0xFFFFFF & p_buf_config->buffer_address);
                p_instr_add[i++] = IN2_SET_LINE_JUMP | (0x1FFF & p_buf_config->line_jump);
                p_instr_add[i++] = IN2_SET_SIZE_XY | ((0x7FF & p_buf_config->x_size) << 12) | (0x7FF & p_buf_config->y_size);

                /*buliding the firmware for in2 set delta XY   */
                temp = ((p_buf_config->x_shift & 0xFFF) << 12) | (p_buf_config->y_shift & 0xFFF);

                p_instr_add[i++] = IN2_SET_DELTA_XY | temp;

                /*building the firmware for in2 set pixel type */
                temp = IN2_SET_PIXEL_TYPE | ((((t_uint32) p_pix_config->colour_to_zero) & 0x1) << 18) |
                       ((((t_uint32) p_pix_config->colour_conversion) & 0x1) << 17) | ((((t_uint32) p_pix_config->yuv_rgb) & 0x1) << 16) |
                       ((((t_uint32) p_pix_config->truncate_to_16_235) & 0x1) << 15) | ((((t_uint32) p_pix_config->bilinear_mode) & 0x1) << 13) |
                       ((((t_uint32) p_pix_config->activate_depack) & 0x1) << 14) |
                       ((((t_uint32) p_pix_config->activate_flow) & 0x1) << 12) |
                       ((((t_uint32) p_pix_config->freeze_ahb_address) & 0x1) << 11) |
                       ((((t_uint32) p_pix_config->memory_bypass) & 0x1) << 10) |
                       ((((t_uint32) p_pix_config->dma_synchro) & 0x1) << 9) |
                       ((((t_uint32) p_pix_config->alpha_to_255) & 0x1) << 8) |
                       ((((t_uint32) p_pix_config->exchange_red_blue) & 0x1) << 5) |
                       ((((t_uint32) p_pix_config->endian) & 0x1) << 4) |
                       (0xF & ((t_uint32) p_pix_config->pixel_format));

                /*            if (SGA_PIXEL_FORMAT_ARGB24 == p_pix_config->pixel_format)
                            {
                                temp |= (1 << 14);
                            }
                */
                p_instr_add[i++] = temp;

                break;

        case SGA_IMAGE_BUFFER_OUT:
                p_instr_add[i++] = OUT_BASE_ADD_MSB | (0xFF & (p_buf_config->buffer_address >> 24));
                p_instr_add[i++] = OUT_BASE_ADD | (0xFFFFFF & p_buf_config->buffer_address);
                p_instr_add[i++] = OUT_SET_LINE_JUMP | (0x1FFF & p_buf_config->line_jump);
                p_instr_add[i++] = OUT_SET_SIZE_XY | ((0x7FF & p_buf_config->x_size) << 12) | (0x7FF & p_buf_config->y_size);
                p_instr_add[i++] = OUT_SET_BASE_XY | ((0x7FF & p_buf_config->scissor_clip_x) << 12) | (0x7FFF & p_buf_config->scissor_clip_y);

                /*building the firmware for OutSetPixel type instruction*/
                temp = OUT_SET_PIXEL_TYPE | ((((t_uint32) p_pix_config->activate_depack) & 0x1) << 14) | ((((t_uint32) p_pix_config->freeze_ahb_address) & 0x1) << 11) |
                       ((((t_uint32) p_pix_config->dma_synchro) & 0x1) << 9) | ((((t_uint32) p_pix_config->stencil_mode) & 0x3) << 6) |
                       ((((t_uint32) p_pix_config->exchange_red_blue) & 0x1) << 5) | ((((t_uint32) p_pix_config->endian) & 0x1) << 4) |
                       (0xF & ((t_uint32) p_pix_config->pixel_format));

                /*            if (SGA_PIXEL_FORMAT_ARGB24 == p_pix_config->pixel_format)
                            {
                                temp |= (1 << 14);
                            }
                */
                p_instr_add[i++] = temp;

                break;

        default:
                break;
        }

        /* number of commands inserted at memory location */
        *p_no_cmd = i;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildDrawPrimitiveFirmware() 	           	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for drawing     */
/*                primitives.                                               */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_graphic_command* p_command:contain drawing request   */
/*                and parameters for setting the drawing points and colours */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildDrawPrimitiveFirmware
(
        IN t_sga_graphic_command    *p_command,
        OUT t_uint32                *p_instr_add,
        OUT t_uint32                *p_no_cmd
)
{
        t_uint32    i = 0;

        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_no_cmd)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        switch (p_command->graphic_type) {
        case SGA_GRAPHIC_DRAWPOINT:
                if (TRUE == p_command->colour_set) {
                        /*Set the colour  */
                        p_instr_add[i++] = SET_COLOR | (0xFFFFFF & p_command->rgb_colour);
                } else {
                        /*Set the interpolation or decimation increment values  */
                        p_instr_add[i++] = SET_COLOR | ((0x7 & p_command->interpol_inc_x_int) << 21) |
                                           ((0x1FF & p_command->interpol_inc_x_dec) << 12) | ((0x7 & p_command->interpol_inc_y_int) << 9) |
                                           (0x1FF & p_command->interpol_inc_y_dec);
                }

                if (TRUE == p_command->set_bypass_zs) {
                        /*Set Z and S component of the colour used to draw when pixel operator is in   */
                        /*by pass mode  */
                        p_instr_add[i++] = SET_BYPASS_ZS | ((0xFFFF & p_command->z_colour) << 8) | (0xFF & p_command->s_colour);
                }

                /*Set the Draw Point command  */
                p_instr_add[i++] = DRAW_POINT | ((0x7FF & p_command->point_x0) << 12) | (0x7FF & p_command->point_y0);
                break;

        case SGA_GRAPHIC_DRAWLINE:
                p_instr_add[i++] = SET_POINT0 | ((0x7FF & p_command->point_x0) << 12) | (0x7FF & p_command->point_y0);
                p_instr_add[i++] = SET_POINT1 | ((0x7FF & p_command->point_x1) << 12) | (0x7FF & p_command->point_y1);

                if (TRUE == p_command->colour_set) {
                        /*Set the colour  */
                        p_instr_add[i++] = SET_COLOR | (0xFFFFFF & p_command->rgb_colour);
                } else {
                        /*Set the interpolation or decimation increment values  */
                        p_instr_add[i++] = SET_COLOR | ((0x7 & p_command->interpol_inc_x_int) << 21) |
                                           ((0x1FF & p_command->interpol_inc_x_dec) << 12) | ((0x7 & p_command->interpol_inc_y_int) << 9) |
                                           (0x1FF & p_command->interpol_inc_y_dec);
                }

                /*set the line stippling factor  */
                p_instr_add[i++] = LINE_STIPPLING | ((0xFF & p_command->stippling_factor) << 16) | (0xFFFF & p_command->stippling_mask);

                if (TRUE == p_command->set_bypass_zs) {
                        /*Set Z and S component of the colour used to draw when pixel operator is in   */
                        /*by pass mode  */
                        p_instr_add[i++] = SET_BYPASS_ZS | ((0xFFFF & p_command->z_colour) << 8) | (0xFF & p_command->s_colour);
                }

                /*set the Draw line command  */
                p_instr_add[i++] = DRAW_LINE;
                break;

        case SGA_GRAPHIC_DRAWTRIANGLE:
                p_instr_add[i++] = SET_POINT0 | ((0x7FF & p_command->point_x0) << 12) | (0x7FF & p_command->point_y0);
                p_instr_add[i++] = SET_POINT1 | ((0x7FF & p_command->point_x1) << 12) | (0x7FF & p_command->point_y1);
                p_instr_add[i++] = SET_POINT2 | ((0x7FF & p_command->point_x2) << 12) | (0x7FF & p_command->point_y2);

                if (TRUE == p_command->colour_set) {
                        /*Set the colour  */
                        p_instr_add[i++] = SET_COLOR | (0xFFFFFF & p_command->rgb_colour);
                } else {
                        /*Set the interpolation or decimation increment values  */
                        p_instr_add[i++] = SET_COLOR | ((0x7 & p_command->interpol_inc_x_int) << 21) |
                                           ((0x1FF & p_command->interpol_inc_x_dec) << 12) | ((0x7 & p_command->interpol_inc_y_int) << 9) |
                                           (0x1FF & p_command->interpol_inc_y_dec);
                }

                if (TRUE == p_command->set_bypass_zs) {
                        /*Set Z and S component of the colour used to draw when pixel operator is in   */
                        /*by pass mode  */
                        p_instr_add[i++] = SET_BYPASS_ZS | ((0xFFFF & p_command->z_colour) << 8) | (0xFF & p_command->s_colour);
                }

                /*set the Draw Triangle command  */
                p_instr_add[i++] = DRAW_TRIANGLE;
                break;

        case SGA_GRAPHIC_DRAWRECTANGLE:
                p_instr_add[i++] = SET_POINT0 | ((0x7FF & p_command->point_x0) << 12) | (0x7FF & p_command->point_y0);
                p_instr_add[i++] = SET_POINT1 | ((0x7FF & p_command->point_x1) << 12) | (0x7FF & p_command->point_y1);

                if (TRUE == p_command->colour_set) {
                        /*Set the colour  */
                        p_instr_add[i++] = SET_COLOR | (0xFFFFFF & p_command->rgb_colour);
                } else {
                        /*Set the interpolation or decimation increment values  */
                        p_instr_add[i++] = SET_COLOR | ((0x7 & p_command->interpol_inc_x_int) << 21) |
                                           ((0x1FF & p_command->interpol_inc_x_dec) << 12) | ((0x7 & p_command->interpol_inc_y_int) << 9) |
                                           (0x1FF & p_command->interpol_inc_y_dec);
                }

                if (TRUE == p_command->set_bypass_zs) {
                        /*Set Z and S component of the colour used to draw when pixel operator is in   */
                        /*by pass mode  */
                        p_instr_add[i++] = SET_BYPASS_ZS | ((0xFFFF & p_command->z_colour) << 8) | (0xFF & p_command->s_colour);
                }

                /*set the Draw Triangle command  */
                p_instr_add[i++] = DRAW_RECTANGLE;
                break;

        case SGA_GRAPHIC_LINE_SHIFT:
                if (TRUE == p_command->colour_set) {
                        /*Set the colour  */
                        p_instr_add[i++] = SET_COLOR | (0xFFFFFF & p_command->rgb_colour);
                } else {
                        /*Set the interpolation or decimation increment values  */
                        p_instr_add[i++] = SET_COLOR | ((0x7 & p_command->interpol_inc_x_int) << 21) |
                                           ((0x1FF & p_command->interpol_inc_x_dec) << 12) | ((0x7 & p_command->interpol_inc_y_int) << 9) |
                                           (0x1FF & p_command->interpol_inc_y_dec);
                }

                /*set the line stippling factor  */
                p_instr_add[i++] = LINE_STIPPLING | ((0xFF & p_command->stippling_factor) << 16) | (0xFFFF & p_command->stippling_mask);

                if (TRUE == p_command->set_bypass_zs) {
                        /*Set Z and S component of the colour used to draw when pixel operator is in   */
                        /*by pass mode  */
                        p_instr_add[i++] = SET_BYPASS_ZS | ((0xFFFF & p_command->z_colour) << 8) | (0xFF & p_command->s_colour);
                }

                /*Set the DrawLineShift command  */
                p_instr_add[i++] = DRAW_LINE_SHIFT | ((0x7FF & p_command->point_x0) << 12) | (0x7FF & p_command->point_y0);
                break;

        case SGA_GRAPHIC_TRIANGLE_SHIFT:
                if (TRUE == p_command->colour_set) {
                        /*Set the colour  */
                        p_instr_add[i++] = SET_COLOR | (0xFFFFFF & p_command->rgb_colour);
                } else {
                        /*Set the interpolation or decimation increment values  */
                        p_instr_add[i++] = SET_COLOR | ((0x7 & p_command->interpol_inc_x_int) << 21) |
                                           ((0x1FF & p_command->interpol_inc_x_dec) << 12) | ((0x7 & p_command->interpol_inc_y_int) << 9) |
                                           (0x1FF & p_command->interpol_inc_y_dec);
                }

                if (TRUE == p_command->set_bypass_zs) {
                        /*Set Z and S component of the colour used to draw when pixel operator is in   */
                        /*by pass mode  */
                        p_instr_add[i++] = SET_BYPASS_ZS | ((0xFFFF & p_command->z_colour) << 8) | (0xFF & p_command->s_colour);
                }

                /*Set the DrawLineShift command  */
                p_instr_add[i++] = DRAW_TRIANGLE_SHIFT | ((0x7FF & p_command->point_x0) << 12) | (0x7FF & p_command->point_y0);
                break;

        default:
                break;
        }

        /*Number of commands inserted at memory location  */
        *p_no_cmd = i;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildTransparencyFirmware() 	           	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for Transparency*/
/*               configuration instructions                                 */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_transp_config* p_transp:contain the transparency     */
/*                                            configuration.                */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildTransparencyFirmware
(
        IN t_sga_transp_config  *p_transp,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        t_uint32    i = 0;

        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_transp)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        p_instr_add[i++] = TRANSP_COLORMSB | ((0xFF & (p_transp->in_transp_colour >> 24)) << 8) | (0xFF & (p_transp->out_transp_colour >> 24));
        p_instr_add[i++] = TRANSP_IN_COLOR | (0xFFFFFF & p_transp->in_transp_colour);
        p_instr_add[i++] = TRANSP_OUT_COLOR | (0xFFFFFF & p_transp->out_transp_colour);

        /* transparency mode  */
#if  (__STN_8815 == 10)
        p_instr_add[i++] = TRANSP_MODE | ((((t_uint32) p_transp->video_mode) & 0x1) << 6) |
                           ((((t_uint32) p_transp->active_on_input) & 0x1) << 5) | ((0x3 & ((t_uint32) p_transp->transp_in_mode)) << 3) |
                           ((((t_uint32) p_transp->active_on_output) & 0x1) << 2) | (0x3 & ((t_uint32) p_transp->transp_out_mode));

#else /*8815 CutB0 chip  */
        p_instr_add[i++] = TRANSP_MODE | ((((t_uint32) p_transp->transp_active_in2) & 0x1) << 9) \
                           | ((((t_uint32) p_transp->transp_active_in1) & 0x1) << 8) \
                           | ((((t_uint32) p_transp->transp_active_in0) & 0x1) << 7) \
                           | ((((t_uint32) p_transp->video_mode) & 0x1) << 6)\
                           | ((((t_uint32) p_transp->active_on_input) & 0x1) << 5)\
                           | ((0x3 & ((t_uint32) p_transp->transp_in_mode)) << 3)\
                           | ((((t_uint32) p_transp->active_on_output) & 0x1) << 2)\
                           | (0x3 & ((t_uint32) p_transp->transp_out_mode));


#endif

        /*number of commands inserted at memory location  */
        *p_no_cmd = i;
        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildFlashFirmware() 	                	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for Flash       */
/*               configuration instructions                                 */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_flash_config* p_flash :contain the flash             */
/*                                            configuration.                */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildFlashFirmware
(
        IN t_sga_flash_config   *p_flash,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        t_uint32    i = 0;

        //DBGENTER0();

        /*check validity of input parameters */
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_flash)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        p_instr_add[i++] = FLASH_COLOR_MSB | ((0xFF & (p_flash->flash_id_colour >> 24)) << 8) | (0xFF & (p_flash->flash_new_colour >> 24));
        p_instr_add[i++] = FLASH_COLOR_ID | (0xFFFFFF & p_flash->flash_id_colour);
        p_instr_add[i++] = FLASH_COLOR_NEW | (0xFFFFFF & p_flash->flash_new_colour);

        /*set the Flash mode command  */
#if  (__STN_8815 == 10)
        p_instr_add[i++] = FLASH_MODE | ((((t_uint32) p_flash->flash_mode) & 0x1) << 1) | (((t_uint32) p_flash->flash_active) & 0x1);

#else  /*8815 CutB0 chip  */
        p_instr_add[i++] = FLASH_MODE | ((((t_uint32) p_flash->flash_active_in2) & 0x1) << 4)\
                           | ((((t_uint32) p_flash->flash_active_in1) & 0x1) << 3)\
                           | ((((t_uint32) p_flash->flash_active_in0) & 0x1) << 2)\
                           | ((((t_uint32) p_flash->flash_mode) & 0x1) << 1)\
                           | (((t_uint32) p_flash->flash_active) & 0x1);

#endif
        /*number of commands inserted at given memory location */
        *p_no_cmd = i;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildXYWCoeffFirmware() 	              	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               XYW cofficients instructions used in the resize and        */
/*               rotate operations.                                         */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_xyw_coefficient* p_xyw_coeff:contain the XYW         */
/*                                     coefficients configuration  details  */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildXYWCoeffFirmware
(
        IN t_sga_xyw_coefficient    *p_xyw_coeff,
        OUT t_uint32                *p_instr_add,
        OUT t_uint32                *p_no_cmd
)
{
        t_uint32    i = 0;

        //DBGENTER0();

        /* Check the validity of input parameters */
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_xyw_coeff)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        switch (p_xyw_coeff->dyn_coeff) {
        case SGA_XY_DYN_COEF_NORMAL:
                /*build the SetXxCoef command  */
                p_instr_add[i++] = SET_XX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) |((0x1F & p_xyw_coeff->xx_int_coef) << 12) | (0xFFE & p_xyw_coeff->xx_dec_coef);

                /*build the SetXycoef command */
                p_instr_add[i++] = SET_XY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1F & p_xyw_coeff->xy_int_coef) << 12) | (0xFFE & p_xyw_coeff->xy_dec_coef);

                /*build the SetYxCoef command */
                p_instr_add[i++] = SET_YX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1F & p_xyw_coeff->yx_int_coef) << 12) | (0xFFE & p_xyw_coeff->yx_dec_coef);

                /* build the SetYycoef command */
                p_instr_add[i++] = SET_YY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1F & p_xyw_coeff->yy_int_coef) << 12) | (0xFFE & p_xyw_coeff->yy_dec_coef);
                break;

        case SGA_XY_DYN_COEF_X_4:
                /*build the SetXxCoef command  */
                p_instr_add[i++] = SET_XX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7F & p_xyw_coeff->xx_int_coef) << 10) | (0x3FE & p_xyw_coeff->xx_dec_coef);

                /*build the SetXycoef command */
                p_instr_add[i++] = SET_XY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7F & p_xyw_coeff->xy_int_coef) << 10) | (0x3FE & p_xyw_coeff->xy_dec_coef);

                /*build the SetYxCoef command */
                p_instr_add[i++] = SET_YX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7F & p_xyw_coeff->yx_int_coef) << 10) | (0x3FE & p_xyw_coeff->yx_dec_coef);

                /* build the SetYycoef command */
                p_instr_add[i++] = SET_YY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7F & p_xyw_coeff->yy_int_coef) << 10) | (0x3FE & p_xyw_coeff->yy_dec_coef);
                break;

        case SGA_XY_DYN_COEF_X_16:
                /*build the SetXxCoef command  */
                p_instr_add[i++] = SET_XX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1FF & p_xyw_coeff->xx_int_coef) << 8) | (0xFE & p_xyw_coeff->xx_dec_coef);

                /*build the SetXycoef command */
                p_instr_add[i++] = SET_XY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1FF & p_xyw_coeff->xy_int_coef) << 8) | (0xFE & p_xyw_coeff->xy_dec_coef);

                /*build the SetYxCoef command */
                p_instr_add[i++] = SET_YX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1FF & p_xyw_coeff->yx_int_coef) << 8) | (0xFE & p_xyw_coeff->yx_dec_coef);

                /* build the SetYycoef command */
                p_instr_add[i++] = SET_YY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1FF & p_xyw_coeff->yy_int_coef) << 8) | (0xFE & p_xyw_coeff->yy_dec_coef);
                break;

        case SGA_XY_DYN_COEF_X_64:
                /*build the SetXxCoef command  */
                p_instr_add[i++] = SET_XX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7FF & p_xyw_coeff->xx_int_coef) << 6) | (0x3E & p_xyw_coeff->xx_dec_coef);

                /*build the SetXycoef command */
                p_instr_add[i++] = SET_XY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7FF & p_xyw_coeff->xy_int_coef) << 6) | (0x3E & p_xyw_coeff->xy_dec_coef);

                /*build the SetYxCoef command */
                p_instr_add[i++] = SET_YX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7FF & p_xyw_coeff->yx_int_coef) << 6) | (0x3E & p_xyw_coeff->yx_dec_coef);

                /* build the SetYycoef command */
                p_instr_add[i++] = SET_YY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7FF & p_xyw_coeff->yy_int_coef) << 6) | (0x3E & p_xyw_coeff->yy_dec_coef);
                break;

        default:
                break;
        }

        /*build SetXoffset command */
        p_instr_add[i++] = SET_X_OFFSET |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0xFFFF & p_xyw_coeff->x_int_offset) << 2) | (0x3 & p_xyw_coeff->x_dec_offset);

        /*build SetYoffset command  */
        p_instr_add[i++] = SET_Y_OFFSET |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0xFFFF & p_xyw_coeff->y_int_offset) << 2) | (0x3 & p_xyw_coeff->y_dec_offset);

        if (TRUE == p_xyw_coeff->active_corrected_mode) {
                switch (p_xyw_coeff->dyn_coeff) {
                case SGA_XY_DYN_COEF_NORMAL:
                        /*build the SetWxCoef command */
                        p_instr_add[i++] = SET_WX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1F & p_xyw_coeff->wx_int_coef) << 12) | (0xFFE & p_xyw_coeff->wx_dec_coef);

                        /* build the SetWyCoef command */
                        p_instr_add[i++] = SET_WY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1F & p_xyw_coeff->wy_int_coef) << 12) | (0xFFE & p_xyw_coeff->wy_dec_coef);
                        break;

                case SGA_XY_DYN_COEF_X_4:
                        /*build the SetWxCoef command */
                        p_instr_add[i++] = SET_WX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7F & p_xyw_coeff->wx_int_coef) << 10) | (0x3FE & p_xyw_coeff->wx_dec_coef);

                        /* build the SetWyCoef command */
                        p_instr_add[i++] = SET_WY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7F & p_xyw_coeff->wy_int_coef) << 10) | (0x3FE & p_xyw_coeff->wy_dec_coef);
                        break;

                case SGA_XY_DYN_COEF_X_16:
                        /*build the SetWxCoef command */
                        p_instr_add[i++] = SET_WX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1FF & p_xyw_coeff->wx_int_coef) << 8) | (0xFE & p_xyw_coeff->wx_dec_coef);

                        /* build the SetWyCoef command */
                        p_instr_add[i++] = SET_WY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x1FF & p_xyw_coeff->wy_int_coef) << 8) | (0xFE & p_xyw_coeff->wy_dec_coef);
                        break;

                case SGA_XY_DYN_COEF_X_64:
                        /*build the SetWxCoef command */
                        p_instr_add[i++] = SET_WX_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7FF & p_xyw_coeff->wx_int_coef) << 6) | (0x3E & p_xyw_coeff->wx_dec_coef);

                        /* build the SetWyCoef command */
                        p_instr_add[i++] = SET_WY_COEF |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0x7FF & p_xyw_coeff->wy_int_coef) << 6) | (0x3E & p_xyw_coeff->wy_dec_coef);
                        break;

                default:
                        break;
                }

                /*build SetWoffset command  */
                p_instr_add[i++] = SET_W_OFFSET |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | ((0xFFFF & p_xyw_coeff->w_int_offset) << 2) | (0x3 & p_xyw_coeff->w_dec_offset);
        }

        /*build XY Dyn command   */
        p_instr_add[i++] = SET_XY_DYN |((((t_uint32)p_xyw_coeff->source) & 0x1) << 23) | (0x3 & ((t_uint32) p_xyw_coeff->dyn_coeff));

        /*number of commands inserted at memory locations*/
        *p_no_cmd = i;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildXYModeFirmware() 	                	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*                XYMode(XY Rotation/Resize) configuration instruction      */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_rotate_resize_config* p_config:contain the           */
/*                                              XY rotation configuration   */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildXYModeFirmware
(
        IN t_sga_rotate_resize_config   *p_config,
        OUT t_uint32                    *p_instr_add,
        OUT t_uint32                    *p_no_cmd
)
{
        //DBGENTER0();

        /*Check the validity of the input parameters */
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_config)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        /*build the XYMode command  */
        *p_instr_add = SET_XY_MODE | ((((t_uint32) p_config->source) & 0x1) << 23) |
                       ((((t_uint32) p_config->active_corrected_mode) & 0x1) << 13) | ((0xF & ((t_uint32) p_config->x_modulo_size)) << 9) |
                       ((0x3 & ((t_uint32) p_config->x_clip)) << 7) | ((0xF & ((t_uint32) p_config->y_modulo_size)) << 3) |
                       ((0x3 & ((t_uint32) p_config->y_clip)) << 1) | (((t_uint32) p_config->active_rotate) & 0x1);

        /*number of commands inserted at given memory location */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildOpModeFirmware() 	                	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*                OpMode configuration instruction                          */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_pixel_opmode_config* p_config: contain the OpMode    */
/*                                              configuration               */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildOpModeFirmware
(
        IN t_sga_pixel_opmode_config    *p_config,
        OUT t_uint32                    *p_instr_add,
        OUT t_uint32                    *p_no_cmd
)
{
        //DBGENTER0();

        /*Check the validity of the input parameters */
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_config)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        /*build the OpMode Firmware */
#if  (__STN_8815 == 10)
        *p_instr_add = PIXEL_OP_MODE | ((((t_uint32) p_config->mode) & 0x1) << 18) | ((((t_uint32) p_config->freeze_index_cnt) & 0x1) << 17) |
                       ((((t_uint32) p_config->stop_concatenate) & 0x1) << 16) | ((((t_uint32) p_config->mask_z_bits) & 0x1) << 15) |
                       ((((t_uint32) p_config->mask_s1_bits) & 0x1) << 14) | ((((t_uint32) p_config->mask_s0_bits) & 0x1) << 13) |
                       ((((t_uint32) p_config->mask_a_bits) & 0x1) << 12) | ((((t_uint32) p_config->mask_r_bits) & 0x1) << 11) |
                       ((((t_uint32) p_config->mask_g_bits) & 0x1) << 10) | ((((t_uint32) p_config->mask_b_bits) & 0x1) << 9) |
                       ((((t_uint32) p_config->dithering_mode) & 0x3) << 7) | ((((t_uint32) p_config->rop_blend) & 0x1) << 6) |
                       ((0xF & ((t_uint32) p_config->rop_type)) << 2) |
                       ((((t_uint32) p_config->active_scissor) & 0x1) << 1) | (((t_uint32) p_config->active_tribreak) & 0x1);
#else
        *p_instr_add = PIXEL_OP_MODE | ((((t_uint32) p_config->precision) & 0x3) << 19) | ((((t_uint32) p_config->mode) & 0x1) << 18) | ((((t_uint32) p_config->freeze_index_cnt) & 0x1) << 17) |
                       ((((t_uint32) p_config->stop_concatenate) & 0x1) << 16) | ((((t_uint32) p_config->mask_z_bits) & 0x1) << 15) |
                       ((((t_uint32) p_config->mask_s1_bits) & 0x1) << 14) | ((((t_uint32) p_config->mask_s0_bits) & 0x1) << 13) |
                       ((((t_uint32) p_config->mask_a_bits) & 0x1) << 12) | ((((t_uint32) p_config->mask_r_bits) & 0x1) << 11) |
                       ((((t_uint32) p_config->mask_g_bits) & 0x1) << 10) | ((((t_uint32) p_config->mask_b_bits) & 0x1) << 9) |
                       ((((t_uint32) p_config->dithering_mode) & 0x3) << 7) | ((((t_uint32) p_config->rop_blend) & 0x1) << 6) |
                       ((0xF & ((t_uint32) p_config->rop_type)) << 2) |
                       ((((t_uint32) p_config->active_scissor) & 0x1) << 1) | (((t_uint32) p_config->active_tribreak) & 0x1);
#endif

        /*Number of commands inserted at memory location */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildDepthInstrFirmware() 	              	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*                Depth configuration instruction                           */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_z_coefficient* p_z_coef: contain the Depth           */
/*                                         configuration  details           */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildDepthInstrFirmware
(
        IN t_sga_z_coef_config  *p_z_coef,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        t_uint32    i = 0;
        //DBGENTER0();

        /*Check the validity of the input parameters */
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_z_coef)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        switch (p_z_coef->z_dyn) {
        case SGA_Z_DYN_COEF_NORMAL:
                /*Build the Zx Coefficient  */
                p_instr_add[i++] = SET_ZX_COEF | ((0xFF & p_z_coef->zx_int_coeff) << 12) | (0xFFE & p_z_coef->zx_dec_coeff);

                /*Build the Zy Coefficient  */
                p_instr_add[i++] = SET_ZY_COEF | ((0xFF & p_z_coef->zy_int_coeff) << 12) | (0xFFE & p_z_coef->zy_dec_coeff);
                break;

        case SGA_Z_DYN_COEF_X_8:
                /*Build the Zx Coefficient  */
                p_instr_add[i++] = SET_ZX_COEF | ((0x7FF & p_z_coef->zx_int_coeff) << 9) | (0x1FE & p_z_coef->zx_dec_coeff);

                /*Build the Zy Coefficient  */
                p_instr_add[i++] = SET_ZY_COEF | ((0x7FF & p_z_coef->zy_int_coeff) << 9) | (0x1FE & p_z_coef->zy_dec_coeff);
                break;

        case SGA_Z_DYN_COEF_X_64:
                /*Build the Zx Coefficient  */
                p_instr_add[i++] = SET_ZX_COEF | ((0x3FFF & p_z_coef->zx_int_coeff) << 6) | (0x3E & p_z_coef->zx_dec_coeff);

                /*Build the Zy Coefficient  */
                p_instr_add[i++] = SET_ZY_COEF | ((0x3FFF & p_z_coef->zy_int_coeff) << 6) | (0x3E & p_z_coef->zy_dec_coeff);
                break;

        case SGA_Z_DYN_COEF_X_512:
                /*Build the Zx Coefficient  */
                p_instr_add[i++] = SET_ZX_COEF | ((0x1FFFF & p_z_coef->zx_int_coeff) << 3) | (0x6 & p_z_coef->zx_dec_coeff);

                /*Build the Zy Coefficient  */
                p_instr_add[i++] = SET_ZY_COEF | ((0x1FFFF & p_z_coef->zy_int_coeff) << 3) | (0x6 & p_z_coef->zy_dec_coeff);
                break;

        default:
                break;
        }

        p_instr_add[i++] = SET_Z_OFFSET | (0x3FFFF & p_z_coef->z_offset);

        p_instr_add[i++] = SET_Z_DYN | (0x3 & ((t_uint32) p_z_coef->z_dyn));

        /*number of commands inserted at given memory location */
        *p_no_cmd = i;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildGouraudCoeffFirmware() 	          	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               Gouraud shading Cofficients  instruction                   */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_gourad_coeff_config* p_config : contain the Gouraud  */
/*                                         coefficients  details            */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location to write the build   */
/*                                     firmware                             */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildGouraudCoeffFirmware
(
        IN t_sga_gouraud_coeff_config   *p_config,
        OUT t_uint32                    *p_instr_add,
        OUT t_uint32                    *p_no_cmd
)
{
        t_uint32    i = 0;

        //DBGENTER0();

        /*Check the validity of the input parameters */
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_config)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        switch (p_config->dyn_coef) {
        case SGA_DYN_COEF_DIV_BY_256:
                /*build the firmware for SetCoeffAxAy command  */
                p_instr_add[i++] = SET_COEF_AXAY | ((0xF & p_config->ax_int_grad) << 20) |
                                   ((0xFF & p_config->ax_dec_grad) << 12) | ((0xF & p_config->ay_int_grad) << 8) |
                                   (0xFF & p_config->ay_dec_grad);

                /*build the firmware for SetCoefRxRy command */
                p_instr_add[i++] = SET_COEF_RXRY | ((0xF & p_config->rx_int_grad) << 20) |
                                   ((0xFF & p_config->rx_dec_grad) << 12) | ((0xF & p_config->ry_int_grad) << 8) |
                                   (0xFF & p_config->ry_dec_grad);

                /*build the firmware for SetCoefGxGy command */
                p_instr_add[i++] = SET_COEF_GXGY | ((0xF & p_config->gx_int_grad) << 20) |
                                   ((0xFF & p_config->gx_dec_grad) << 12) | ((0xF & p_config->gy_int_grad) << 8) |
                                   (0xFF & p_config->gy_dec_grad);

                /*build the firmware for SetCoefBxBy command */
                p_instr_add[i++] = SET_COEF_BXBY | ((0xF & p_config->bx_int_grad) << 20) |
                                   ((0xFF & p_config->bx_dec_grad) << 12) | ((0xF & p_config->by_int_grad) << 8) |
                                   (0xFF & p_config->by_dec_grad);
                break;

        case SGA_DYN_COEF_DIV_BY_64:
                /*build the firmware for SetCoeffAxAy command  */
                p_instr_add[i++] = SET_COEF_AXAY | ((0x3F & p_config->ax_int_grad) << 18) |
                                   ((0x3F & p_config->ax_dec_grad) << 12) | ((0x3F & p_config->ay_int_grad) << 6) |
                                   (0x3F & p_config->ay_dec_grad);

                /*build the firmware for SetCoefRxRy command */
                p_instr_add[i++] = SET_COEF_RXRY | ((0x3F & p_config->rx_int_grad) << 18) |
                                   ((0x3F & p_config->rx_dec_grad) << 12) | ((0x3F & p_config->ry_int_grad) << 6) |
                                   (0x3F & p_config->ry_dec_grad);

                /*build the firmware for SetCoefGxGy command */
                p_instr_add[i++] = SET_COEF_GXGY | ((0x3F & p_config->gx_int_grad) << 18) |
                                   ((0x3F & p_config->gx_dec_grad) << 12) | ((0x3F & p_config->gy_int_grad) << 6) |
                                   (0x3F & p_config->gy_dec_grad);

                /*build the firmware for SetCoefBxBy command */
                p_instr_add[i++] = SET_COEF_BXBY | ((0x3F & p_config->bx_int_grad) << 18) |
                                   ((0x3F & p_config->bx_dec_grad) << 12) | ((0x3F & p_config->by_int_grad) << 6) |
                                   (0x3F & p_config->by_dec_grad);
                break;

        case SGA_DYN_COEF_DIV_BY_16:
                /*build the firmware for SetCoeffAxAy command  */
                p_instr_add[i++] = SET_COEF_AXAY | ((0xFF & p_config->ax_int_grad) << 16) |
                                   ((0xF & p_config->ax_dec_grad) << 12) | ((0xFF & p_config->ay_int_grad) << 4) |
                                   (0xF & p_config->ay_dec_grad);

                /*build the firmware for SetCoefRxRy command */
                p_instr_add[i++] = SET_COEF_RXRY | ((0xFF & p_config->rx_int_grad) << 16) |
                                   ((0xF & p_config->rx_dec_grad) << 12) | ((0xFF & p_config->ry_int_grad) << 4) |
                                   (0xF & p_config->ry_dec_grad);

                /*build the firmware for SetCoefGxGy command */
                p_instr_add[i++] = SET_COEF_GXGY | ((0xFF & p_config->gx_int_grad) << 16) |
                                   ((0xF & p_config->gx_dec_grad) << 12) | ((0xFF & p_config->gy_int_grad) << 4) |
                                   (0xF & p_config->gy_dec_grad);

                /*build the firmware for SetCoefBxBy command */
                p_instr_add[i++] = SET_COEF_BXBY | ((0xFF & p_config->bx_int_grad) << 16) |
                                   ((0xF & p_config->bx_dec_grad) << 12) | ((0xFF & p_config->by_int_grad) << 4) |
                                   (0xF & p_config->by_dec_grad);
                break;

        case SGA_DYN_COEF_DIV_BY_4:
                /*build the firmware for SetCoeffAxAy command  */
                p_instr_add[i++] = SET_COEF_AXAY | ((0x3FF & p_config->ax_int_grad) << 14) |
                                   ((0x3 & p_config->ax_dec_grad) << 12) | ((0x3FF & p_config->ay_int_grad) << 2) |
                                   (0x3 & p_config->ay_dec_grad);

                /*build the firmware for SetCoefRxRy command */
                p_instr_add[i++] = SET_COEF_RXRY | ((0x3FF & p_config->rx_int_grad) << 14) |
                                   ((0x3 & p_config->rx_dec_grad) << 12) | ((0x3FF & p_config->ry_int_grad) << 2) |
                                   (0x3 & p_config->ry_dec_grad);

                /*build the firmware for SetCoefGxGy command */
                p_instr_add[i++] = SET_COEF_GXGY | ((0x3FF & p_config->gx_int_grad) << 14) |
                                   ((0x3 & p_config->gx_dec_grad) << 12) | ((0x3FF & p_config->gy_int_grad) << 2) |
                                   (0x3 & p_config->gy_dec_grad);

                /*build the firmware for SetCoefBxBy command */
                p_instr_add[i++] = SET_COEF_BXBY | ((0x3FF & p_config->bx_int_grad) << 14) |
                                   ((0x3 & p_config->bx_dec_grad) << 12) | ((0x3FF & p_config->by_int_grad) << 2) |
                                   (0x3 & p_config->by_dec_grad);
                break;

        default:
                break;
        }

        /* build the firmware for SetCoefAo command */
        p_instr_add[i++] = SET_COEF_A0 | (0xFFF & p_config->ao_offset);

        /* build the firmware for SetCoefRo command */
        p_instr_add[i++] = SET_COEF_R0 | (0xFFF & p_config->ro_offset);

        /* build the firmware for SetCoefGo command */
        p_instr_add[i++] = SET_COEF_G0 | (0xFFF & p_config->go_offset);

        /* build the firmware for SetCoefBo command */
        p_instr_add[i++] = SET_COEF_B0 | (0xFFF & p_config->bo_offset);

        /*build the firmware for the SetCoefdyn command  */
        p_instr_add[i++] = SET_COEF_DYN | (((t_uint32) p_config->dyn_coef) & 3);

        /* number of commands inserted at memory location */
        *p_no_cmd = i;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildTextureConfigFirmware() 	          	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               Texture configuration   instructions                       */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_texture_config* p_config : contain the texture       */
/*                                         cconfiguration                   */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildTextureConfigFirmware
(
        IN t_sga_texture_config *p_config,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        //DBGENTER0();

        /*Check the validity of the input parameters  */
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_config)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add++ = SET_TEX_COLORMSB | ((((t_uint32) p_config->tex_id) & 0x1) << 23) | (p_config->argb_colour >> 16);

        *p_instr_add++ = SET_TEX_COLORLSB | ((((t_uint32) p_config->tex_id) & 0x1) << 23) | (0xFFFF & p_config->argb_colour);

        *p_instr_add++ = SET_TEX_ENV_MSB | ((((t_uint32) p_config->tex_id) & 0x1) << 23) | ((((t_uint32) p_config->rgb_fct) & 0x7) << 15) |
                         ((((t_uint32) p_config->a_fct) & 0x7) << 12) | ((((t_uint32) p_config->source_0_rgb) & 0x3) << 10) |
                         ((((t_uint32) p_config->source_1_rgb) & 0x3) << 8) | ((((t_uint32) p_config->source_2_rgb) & 0x3) << 6) |
                         ((((t_uint32) p_config->source_0_a) & 0x3) << 4) | ((((t_uint32) p_config->source_1_a) & 0x3) << 2) |
                         (((t_uint32) p_config->source_2_a) & 0x3);

        *p_instr_add++ = SET_TEX_ENN_LSB | ((((t_uint32) p_config->tex_id) & 0x1) << 23) |
                         ((((t_uint32) p_config->operand_0_rgb) & 0x3) << 7) | ((((t_uint32) p_config->operand_1_rgb) & 0x3) << 5) |
                         ((((t_uint32) p_config->operand_2_rgb) & 0x3) << 3) | ((((t_uint32) p_config->operand_0_a) & 0x1) << 2) |
                         ((((t_uint32) p_config->operand_1_a) & 0x1) << 1) | (((t_uint32) p_config->operand_2_a) & 0x1);

        *p_instr_add++ = SET_TEX_SCALE | ((((t_uint32) p_config->tex_id) & 0x1) << 23) | (p_config->rgb_scale << 8) | (p_config->a_scale);

        /*number of commands inserted at given memory location  */
        *p_no_cmd = 5;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildFogConfigFirmware() 	              	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               Fog configuration   instructions                           */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_fog_config* p_fog:   contain the Fog configuration   */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildFogConfigFirmware
(
        IN t_sga_fog_config *p_fog,
        OUT t_uint32        *p_instr_add,
        OUT t_uint32        *p_no_cmd
)
{
        //DBGENTER0();

        /*Check the validity of the input parameter*/
        if ((NULL == p_fog) || (NULL == p_instr_add) || (NULL == p_no_cmd)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        switch (p_fog->coef_type) {
        case SGA_DYN_COEF_DIV_BY_256:
                *p_instr_add++ = SET_COEF_FXFY | ((0xF & p_fog->fx_grad_int) << 20) | ((0xFF & p_fog->fx_grad_dec) << 12) | ((0xF & p_fog->fy_grad_int) << 8) | (0xFF & p_fog->fy_grad_dec);

                break;

        case SGA_DYN_COEF_DIV_BY_64:
                *p_instr_add++ = SET_COEF_FXFY | ((0x3F & p_fog->fx_grad_int) << 18) | ((0x3F & p_fog->fx_grad_dec) << 12) | ((0x3F & p_fog->fy_grad_int) << 6) | (0x3F & p_fog->fy_grad_dec);

                break;

        case SGA_DYN_COEF_DIV_BY_16:
                *p_instr_add++ = SET_COEF_FXFY | ((0xFF & p_fog->fx_grad_int) << 16) | ((0xF & p_fog->fx_grad_dec) << 12) | ((0xFF & p_fog->fy_grad_int) << 4) | (0xF & p_fog->fy_grad_dec);

                break;

        case SGA_DYN_COEF_DIV_BY_4:
                *p_instr_add++ = SET_COEF_FXFY | ((0x3FF & p_fog->fx_grad_int) << 14) | ((0x3 & p_fog->fx_grad_dec) << 12) | ((0x3FF & p_fog->fy_grad_int) << 2) | (0x3 & p_fog->fy_grad_dec);

                break;

        default:
                break;
        }

        /*build the SetCoefFo command */
        *p_instr_add++ = SET_COEF_F0 | (0xFFF & p_fog->fo_offset);

        /*build the SetColorF command  */
        *p_instr_add++ = SET_COLOR_F0 | (0xFFFFFF & p_fog->rgb_fog);

        /*build the SetCoefDyn command */
        *p_instr_add++ = SET_COEF_DYN | (((t_uint32) p_fog->coef_type) & 0x3);

        /*number of commands inserted at memory location */
        *p_no_cmd = 4;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildFrameBlendFirmware() 	              	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               Frame blend configuration   instructions                   */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_blend_config* p_blend: contain the Frame blend       */
/*                                            configuration                 */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildFrameBlendFirmware
(
        IN t_sga_blend_config   *p_blend,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        //DBGENTER0();

        /*Check the validity of the input parameters */
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_blend)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        /*build the SetBlendColorMsb command */
        *p_instr_add++ = SET_BLEND_COLORMSB | (p_blend->argb_colour >> 24);

        /*build the SetColor command */
        *p_instr_add++ = SET_COLOR | (0xFFFFFF & p_blend->argb_colour);

        /*build the SetBlendEnv command */
        *p_instr_add++ = SET_BLEND_ENV | ((0x7 & ((t_uint32) p_blend->blend_op)) << 16) |
                         ((((t_uint32) p_blend->rgb_fragment) & 0xF) << 12) | ((((t_uint32) p_blend->a_fragment) & 0xF) << 8) |
                         ((((t_uint32) p_blend->rgb_frame)& 0xF) << 4) | (((t_uint32) p_blend->a_frame) & 0xF);

        /*number of instructions inseted at given memory location  */
        *p_no_cmd = 3;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildAlphaTestFirmware() 	              	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               Alpha test   instruction                                   */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_alphatest_config *p_alpha: contain the Alpha test    */
/*                                            configuration                 */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildAlphaTestFirmware
(
        IN t_sga_alphatest_config   *p_alpha,
        OUT t_uint32                *p_instr_add,
        OUT t_uint32                *p_no_cmd
)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_alpha)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = SET_ALPHA_TEST | ((((t_uint32) p_alpha->enable) & 0x1) << 23) | ((((t_uint32) p_alpha->func) & 0x7) << 20) | (p_alpha->reference);

        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildStencilTestFirmware() 	              	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               Stencil test   instruction                                 */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_stenciltest_config *p_stencil: contain the stencil   */
/*                                           test configuration             */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildStencilTestFirmware
(
        IN t_sga_stenciltest_config *p_stencil,
        OUT t_uint32                *p_instr_add,
        OUT t_uint32                *p_no_cmd
)
{
        //DBGENTER0();

        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (NULL == p_stencil)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = SET_STENCIL_TEST | ((((t_uint32) p_stencil->enable) & 0x1) << 23) | ((((t_uint32) p_stencil->func) & 0x7) << 20) |
                       ((((t_uint32) p_stencil->stencil_dpfail) & 0x7) << 14) | ((((t_uint32) p_stencil->stencil_dppass) & 0x7) << 11) |
                       (
                               (((t_uint32) p_stencil->stencil_sfail) & 0x7) <<
                               8
                       ) |
                       ((0xF & p_stencil->mask) << 4) |
                       (0xF & p_stencil->reference);

        /*Number of commands inserted at memory location   */
        *p_no_cmd = 1;
        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildDepthTestFirmware() 	              	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware for             */
/*               Depth test   instruction                                   */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_bool enable: Enable or disable the Depth test            */
/*               t_sga_test_function depth_func:specifies the depth test    */
/*                                              function                    */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildDepthTestFirmware
(
        IN t_bool               enable,
        IN t_sga_test_function  depth_func,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        //DBGENTER0();
        if ((NULL == p_instr_add) || (NULL == p_no_cmd)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = SET_DEPTH_TEST | ((((t_uint32) enable) & 0x1) << 23)  | ((((t_uint32) depth_func) & 0x3) << 20);

        /*number of commands inseted at memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildbufferDeActivateFirmware() 	       	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware to              */
/*               Deactivate the given input buffer                          */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_image_buffer buffer:Specify the Buffer to be         */
/*                                         DeActivated                      */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
t_sga_error SGA_BuildBufferDeActivateFirmware
(
        IN t_sga_image_buffer   buffer,
        OUT t_uint32            *p_instr_add,
        OUT t_uint32            *p_no_cmd
)
{
        //DBGENTER0();
        if ((NULL == p_instr_add) || (NULL == p_no_cmd) || (SGA_IMAGE_BUFFER_OUT == buffer)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        switch (buffer) {
        case SGA_IMAGE_BUFFER_IN0:
                *p_instr_add = IN0_SET_PIXEL_TYPE;
                break;

        case SGA_IMAGE_BUFFER_IN1:
                *p_instr_add = IN1_SET_PIXEL_TYPE;
                break;

        case SGA_IMAGE_BUFFER_IN2:
                *p_instr_add = IN2_SET_PIXEL_TYPE;
                break;

        default:
                break;
        }

        /*number of commands inseted at memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildFlashDeActivateFirmware () 	       	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware to              */
/*               Deactivate the Flash                                       */
/* PARAMETERS	:                                                           */
/* 		IN  	:None                                                       */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
t_sga_error SGA_BuildFlashDeActivateFirmware(OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();
        if ((NULL == p_instr_add) || (NULL == p_no_cmd)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = FLASH_MODE;

        /*number of commands inseted at memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

/****************************************************************************/
/* NAME			:	SGA_BuildTransparencyDeActivateFirmware() 	   	      	*/
/*--------------------------------------------------------------------------*/
/* DESCRIPTION  :This routine is used to build the firmware to              */
/*               Deactivate the Transparency                                */
/* PARAMETERS	:                                                           */
/* 		IN  	:t_sga_image_buffer buffer:Specify the Buffer to be         */
/*                                         DeActivated                      */
/*     InOut    :None                                                       */
/* 		OUT 	:t_uint32* p_no_cmd:contain the number of commands inserted */
/*                                   at the memory location                 */
/*               t_uint32* p_instr_add:Memory location address to write the */
/*                                    build firmware                        */
/* RETURN		:t_sga_error	: SGA error code						   	*/
/*               SGA_OK         : if it is ok                               */
/*               SGA_INVALID_PARAMETER  if input parameter is invalid       */
/*--------------------------------------------------------------------------*/
/* Type              :  PUBLIC                                              */
/* REENTRANCY 	     :	Non Re-entrant                                      */
/* REENTRANCY ISSUES :														*/
/****************************************************************************/
PUBLIC t_sga_error SGA_BuildTransparencyDeActivateFirmware(OUT t_uint32 *p_instr_add, OUT t_uint32 *p_no_cmd)
{
        //DBGENTER0();
        if ((NULL == p_instr_add) || (NULL == p_no_cmd)) {
                //DBGEXIT0(SGA_INVALID_PARAMETER);
                return(SGA_INVALID_PARAMETER);
        }

        *p_instr_add = TRANSP_MODE;

        /*number of commands inseted at memory location  */
        *p_no_cmd = 1;

        //DBGEXIT0(SGA_OK);
        return(SGA_OK);
}

