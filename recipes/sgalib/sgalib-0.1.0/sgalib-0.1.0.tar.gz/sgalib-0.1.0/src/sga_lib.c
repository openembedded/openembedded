/******************************************************************************
 * � copyright STMicroelectronics, 2007. All rights reserved. For
 * information, STMicroelectronics reserves the right to license this
 * software concurrently under separate license conditions.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *****************************************************************************/
/*
 * Subsystem	: SGA Library API
 * File			: sga_lib.c
 * Description	: This file contains the implementation of SGA
 *				library. This will be used to access SGA for
 *				accelerating graphics.
 * Created		: 15.04.2007
 * Version		: 1.5
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// Include files
///////////////////////////////////////////////////////////////////////////////
#include <pthread.h>
#include "sga_lib.h" 	// include the API for SGA lib
#include "sga_priv.h"	// include the private headers of SGA lib

///////////////////////////////////////////////////////////////////////////////
// Globals - definitions
///////////////////////////////////////////////////////////////////////////////
PGData pGD;		// pointer to Global Data for SGA lib

#define DEBUG_SGA (0)
///////////////////////////////////////////////////////////////////////////////
// Function implementations
///////////////////////////////////////////////////////////////////////////////
/******************************************************************************
*
*  SGALIB_Init
*  __________________________________________________________________________
*
*  DESCRIPTION:	This is the Initialization function of the SGA library.
*		It must be called before using any other functions of the
*		SGA library.
*
*  INPUTS:	fb_addr 	: address of framebuffer
*		fb_width 	: width of visible framebuffer
*		fb_height 	: height of visible framebuffer
*		fb_bpp		: fb - bits per pixel
*		fb_smem_len	: total length of fb
*		fb_smem_start : start of fb (physical address)
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*					from t_sgalib_errs
*
*  REMARKS:	This function will open the SGA driver, allocate required memory,
*		map device registers into user space, create and initialize static
*		batches for common usecases that the library supports. The SGA
*		library is non-reentrant and it is assumed that only one application
*		will be using it. It could be made reentrant in the future, but will
*		require some design changes.
*		The call is synchronous and returns only after Init is complete.
*
******************************************************************************/
int SGALIB_Init(unsigned int *fb_addr, unsigned int fb_width,
				unsigned int fb_height, unsigned int fb_bpp,
				unsigned int fb_smem_len, unsigned int fb_smem_start)
{
    int pg_size, i, f_sga, len;
    t_sga_error     sga_error;

    // Open Devices
    f_sga = open(SGA_DEVICE, O_RDWR);
    //DBGPRINTERR("sgaLib_init enter...\n");
    if ( -1 == f_sga) {
            DBGPRINTERR("sga open error...\n");
            return SGALIB_OPEN_ERR;
    }

    // Allocate and initialize memory for global structure
    pGD = (PGData)malloc(sizeof(GData));
    if (!pGD) {
            DBGPRINTERR("Mem allocation failed\n");
            close(f_sga);
            return SGALIB_MEM_ALLOC_ERR;
    }
    memset(pGD, 0, sizeof(GData));

    pGD->fd_sga = f_sga;
    pGD->fb_addr = (UINT4 *)fb_addr;
    pGD->fb_phy = fb_smem_start;

    pGD->TotalFbMem = fb_smem_len;
    pGD->ScrnWidth = fb_width;
    pGD->ScrnBpp = fb_bpp;
    pGD->ScrnHeight = fb_height;
    pGD->ScrnLineJump = pGD->ScrnWidth * (fb_bpp >> 3);

	DBGPRINTF("fb_addr 0x%x, smemlen = %d, scrnwid = %d, \
				scrnheight = %d, scrnLineJmp = %d\n",
    			pGD->fb_addr, pGD->TotalFbMem,
    			pGD->ScrnWidth, pGD->ScrnHeight, pGD->ScrnLineJump);

    // mmap start
    pg_size = getpagesize();

    len = NPAGES * pg_size;

    DBGPRINTF("fw mmap len = %d\n", len);
    pGD->fw_addr = mmap(0, len,
    	PROT_READ | PROT_WRITE, MAP_SHARED| MAP_LOCKED,
    	pGD->fd_sga, FW_MEMORY*pg_size);
    if (MAP_FAILED == pGD->fw_addr) {
            DBGPRINTERR("mmap() for fw memory failed\n");
            return SGALIB_ERR;
    } else {
            DBGPRINTF("pGD->fw_addr = %x\n", (t_uint32)pGD->fw_addr);
    }


	len = 1 * pg_size;
	DBGPRINTF("dev len to mmap %d\n", len);
	pGD->dev_addr = mmap(0, len,
		PROT_READ | PROT_WRITE, MAP_SHARED| MAP_LOCKED,
		pGD->fd_sga, DEV_MEMORY*pg_size);
	if (MAP_FAILED == pGD->dev_addr) {
		DBGPRINTERR("mmap() for dev memory failed\n");
		return SGALIB_ERR;
	} else {
		DBGPRINTF("pGD->dev_addr = %x\n", (t_uint32)pGD->dev_addr);
        }
        // mmap complete

        // Configure SGA
        sga_error = sgalib_config();
        if (sga_error != SGA_OK) {
                DBGPRINTERR("Could not configure the SGA\n");
                return SGALIB_ERR;
        }


	for(i=0;i<MAX_BATCHES;i++)
	{
		pictop_over_texture0[i] =pictop_over_texture;
	}

	pGD->IntPosition[0] = 0;
	pGD->IntPosition[1] = 1;
	for(i = 2; i < MAX_BATCHES; i++) {
		pGD->IntPosition[i] = i + 6;
	}

	// Create and setup default tasks (Fill, Copy and Blit)
#ifndef ONLY_2_TASKS
	for(i = 0; i < MAX_BATCHES; i++) {
#else
	for(i = 0; i < 2; i++) {
#endif
		sga_error = sgalib_create_task(&pGD->Task[i]);
		if (sga_error != SGA_OK) {
			DBGPRINTERR("Could not create Task[%d] - %d\n", i, sga_error);
			return SGALIB_ERR;
		}
		sga_error = sgalib_init_task(&pGD->Task[i]);
		if (sga_error != SGA_OK) {
			DBGPRINTERR("Could not setup Task[%d] - %d\n", i, sga_error);
			return SGALIB_ERR;
		}
	}

	pGD->cur_batch_no = MAX_BATCHES - 1;

	//DBGPRINTERR("sgaLib_init exit...\n");

        return NULL;
}

/******************************************************************************
*
*  SGALIB_DeInit
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is the De-initialization function of the SGA library.
*		It must be called to close the SGA library properly.
*
*  INPUTS:	None
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	This function will reset the SGA, delete static batches,
*		unmap memory, close SGA and free allocated memory.
*		The call is synchronous and returns only after De-init is complete.
*
******************************************************************************/
int SGALIB_DeInit()
{
	int ret = 0, i, len;
	t_sga_error     sga_error;
	SGA_TaskCounts_T *pShm;

	if (!pGD)
    	return SGALIB_SUCCESS;

    //DBGPRINTERR("sgaLib_Deinit enter...\n");

#if 0
	{
		volatile t_uint32 val =  pGD->dev_addr[19];
		printf("FB_CacheRefill: %d\n", val);
		val = pGD->dev_addr[15];
		printf("Num Primitives: %d\n", val);
	}
#endif

        // sga clear default contexts for 3 tasks, delete batches, reset, close
        sga_error = sgalib_reset();
        if (SGA_OK != sga_error) {
		DBGPRINTERR("Error in reset (%d)\n", sga_error);
		return SGALIB_ERR;
	}
#ifndef ONLY_2_TASKS
	for(i = 0; i < MAX_BATCHES; i++) {
#else
	for(i = 0; i < 2; i++) {
#endif
		sga_error = sgalib_delete_task(&pGD->Task[i]);
		if (SGA_OK != sga_error) {
			DBGPRINTERR("Error in deletetask (%d)\n", sga_error);
			return SGALIB_ERR;
		}
	}

    len = 1 * getpagesize();
    ret = munmap(pGD->dev_addr, len);
    if (ret) {
            DBGPRINTERR("munmap() for dev memory failed with %d\n", ret);
    }

    len = NPAGES * getpagesize();
    ret = munmap(pGD->fw_addr, len);
    if (ret) {
            DBGPRINTERR("munmap() for fw memory failed with %d\n", ret);
    }
    close(pGD->fd_sga);

    free(pGD);
	//DBGPRINTERR("sgaLib_Deinit exit...\n");
    return SGALIB_SUCCESS;
}

/******************************************************************************
*
*  SGALIB_PrepareSolid
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to prepare task for a solid fill. The colour is
*		specified along with the pixmap details. The pixmap maps onto an area
*		in the framebuffer and the subsequent fill operations will be on this
*		pixmap only.
*
*  INPUTS:	pPixmap : Pixmap detailing the canvas to be used for filling
*			colour : colour to be used for filling rectangles in all
*					subsequent SGALIB_Solid() calls. The format of the colour
*					depends on the format of the pixmap.
*
*  OUTPUTS:	None
*
*  RETURNS:
*			t_handle: handle to the task, OR
*			t_sgalib_errs in case of errors
*
*  REMARKS:	A call to SGALIB_PrepareSolid should have a matching call to
*		SGALIB_DoneSolid. The address in pPixmap should be aligned to word
*		boundary. The returned handle should be used in subsequent SGALIB_Solid
*		and SGALIB_DoneSolid calls. This function stores the pPixmap and colour
*		information in the tasks' context to be used in subsequent SGALIB_Solid
*		and SGALIB_DoneSolid calls. The call is synchronous.
*
******************************************************************************/
t_handle SGALIB_PrepareSolid(PSga_bitmap pPixmap, unsigned int colour)
{
        UINT4 size;
        t_sga_error     sga_error;
        int dst_odd, task_handle;
        PGraphicsData pTask;

	//fprintf(stderr, "PS+");
//DBGPRINTERR("SGALIB_PrepareSolid enter...\n");
 	task_handle = sgalib_get_a_task();
 	pTask = &pGD->Task[task_handle];

 	//pTask->pBatch_Fw[pTask->no_cmd++] = IN1_SET_PIXEL_TYPE;
	//pTask->pBatch_Fw[pTask->no_cmd++] = IN2_SET_PIXEL_TYPE;

	pTask->pBatch_Fw[pTask->no_cmd++] = PIXEL_OP_MODE  | (1 << 18) | (1 << 16) | (1 << 1);

	switch(pPixmap->bitspp)
	{
	    case 8:
		colour = ((colour & 0xff) << 16) 	| ((colour & 0xff) << 8)
							| (colour & 0xff);
		break;
	    case 16:
		colour = ((colour & 0x1f) << 3 ) 	| ((colour & 0x7e0) << 5)
							| ((colour & 0xf800) << 8);
		break;
	    case 24:
		break;
	    case 32:
		break;
	    default:
		return SGALIB_FORMAT_ERR;
	}
	//fprintf(stderr, "set_col(%x);\n", colour);

	SGA_BufCfgFw_Out_Activate_Generic (pTask,
					(unsigned int)pGD->fb_phy + ((unsigned int)pPixmap->addr
												- (unsigned int)pGD->fb_addr),
					pPixmap->line_jump,
					pPixmap->width,
					pPixmap->height,
					0,
					0,
					pPixmap->format);

	pTask->pBatch_Fw[pTask->no_cmd++] = IN0_SET_PIXEL_TYPE | (1 << 8) | (1 << 4) | SGA_PIXEL_FORMAT_ARGB24;
	pTask->pBatch_Fw[pTask->no_cmd++] = SET_COLOR | (0xFFFFFF & (colour));

//DBGPRINTERR("SGALIB_PrepareSolid exit...\n");
	//fprintf(stderr, "PS-");
        return task_handle;
}


/******************************************************************************
*
*  SGALIB_Solid
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to draw a rectangle with a solid colour.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareSolid call
*			x1 : x-coordinate of top left corner of rectangle in pPixmap
*			y1 : y-coordinate of top left corner of rectangle in pPixmap
*			x2 : x-coordinate of bottom right corner of rectangle in pPixmap
*			y2 : y-coordinate of bottom right corner of rectangle in pPixmap
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareSolid call
*		preceeding this call. The colour is the one set in the
*		SGALIB_PrepareSolid call. The operations are only done on the pPixmap
*		from the SGALIB_PrepareSolid call. The coordinates are offsets from
*		the base address of the pPixmap. The call is synchronous.
*
******************************************************************************/
int SGALIB_Solid(int task_handle, int x1, int y1, int x2, int y2)
{
	UINT4 size;
	t_sga_error     sga_error;
	PGraphicsData pTask;

	t_sga_wait_config wait_config;
	t_uint32    *pBatchFw;

	//DBGPRINTERR("SGALIB_Solid enter...\n");

	//fprintf(stderr, "S+");
	pTask = &pGD->Task[task_handle];

	while(pTask->TaskChained) {
		// go to next task
		task_handle = sgalib_get_next_task(task_handle);
		pTask = &pGD->Task[task_handle];
	}
	SGA_DRAWRECT_FW(pTask, x1, x2 - 1, y1, y2 - 1);
	//fprintf(stderr, "fill_rect(%d, %d, %d, %d);\n", x1, y1, x2, y2);

	if(pTask->no_cmd >= BATCH_SIZE - 20) {
		// almost at end of batch
		pTask->TaskChained = 1; // indicate that this task needs to be chained
		SGA_TASK_START(pTask); // start current task
		task_handle = sgalib_get_a_task();
		pTask = &pGD->Task[task_handle]; // change current task
	}


	//DBGPRINTERR("SGALIB_Solid exit...\n");

	//fprintf(stderr, "S-");
    return SGA_SUCCESS;
}

/******************************************************************************
*
*  SGALIB_DoneSolid
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function is the logical completion of the solid fills.
*		It is the conclusion of the SGALIB_PrepareSolid call and closes its
*		context. When this function completes, it also ensures that all the
*		rectangle fill operations requested prior to this call are completed.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareSolid call
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareSolid call
*		preceeding this call. In case of immediate rendering, this function is
*		called after every draw rectangle operation and it ensures that the
*		primitive is rendered before returning. The call is synchronous.
*
******************************************************************************/
int SGALIB_DoneSolid(int task_handle)
{
	//fprintf(stderr, "DS+");
	//DBGPRINTERR("SGALIB_DoneSolid enter...\n");
	SGA_TASK_START(&pGD->Task[task_handle]);
	//DBGPRINTERR("SGALIB_DoneSolid exit...\n");
	//fprintf(stderr, "DS-");
        return SGA_SUCCESS;
}

/******************************************************************************
*
*  SGALIB_PrepareCopy
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to prepare task for copy operations. The pixmaps
*		maps onto an area in the framebuffer and the subsequent copy
*		operations will be on these	pixmap only. This function prepares the
*		system from copying a rectangle somewhere from pSrcPixmap to
*		some place in pDstPixmap.
*
*  INPUTS:	pSrcPixmap : Pixmap detailing the source canvas for copying
*		pDstPixmap : Pixmap detailing the destination canvas for copying
*
*  OUTPUTS:	None
*
*  RETURNS:	t_handle: handle to the task, OR
*			t_sgalib_errs in case of errors
*
*  REMARKS:	A call to SGALIB_PrepareCopy should have a matching call to
*		SGALIB_DoneCopy. The address in pSrcPixmap and pDstPixmap should be
*		aligned to word boundary. The returned handle should be used in
*		subsequent SGALIB_Copy and SGALIB_DoneCopy calls. This function stores
*		the pSrcPixmap and pDstPixmap information in the tasks' context to be
*		used in subsequent SGALIB_Copy and SGALIB_DoneCopy calls. It is
*		possible for the pSrcPixmap and pDstPixmap to point to the same pixmap
*		in the framebuffer. The call is synchronous.
*
******************************************************************************/
t_handle SGALIB_PrepareCopy(PSga_bitmap pSrcPixmap, PSga_bitmap pDstPixmap)
{
        UINT4 size;
        t_sga_error     sga_error;
        int dst_odd, task_handle;
        PGraphicsData pTask;

	//fprintf(stderr, "PC+");
	//DBGPRINTERR("SGALIB_PrepareCopy enter...\n");
 	task_handle = sgalib_get_a_task();
 	pTask = &pGD->Task[task_handle];

 	pTask->pBatch_Fw[pTask->no_cmd++] = IN1_SET_PIXEL_TYPE;
	pTask->pBatch_Fw[pTask->no_cmd++] = IN2_SET_PIXEL_TYPE;

	pTask->pBatch_Fw[pTask->no_cmd++] = PIXEL_OP_MODE  | (1 << 18) | (1 << 16) | (1 << 1);

	pGD->pSrcPixmap = pSrcPixmap;
	pGD->dst_addr = (t_uint32)pGD->fb_phy + ((unsigned int)pDstPixmap->addr
											- (unsigned int)pGD->fb_addr);

	SGA_BufCfgFw_Out_Activate_Generic (pTask,
					pGD->dst_addr,
					pDstPixmap->line_jump,
					pDstPixmap->width,
					pDstPixmap->height,
					0,
					0,
					pDstPixmap->format);

	//DBGPRINTERR("SGALIB_PrepareCopy exit...\n");
	//fprintf(stderr, "PC-");
        return task_handle;
}

/******************************************************************************
*
*  SGALIB_Copy
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to copy a rectangle from a place in the pSrcPixmap
*		to another place in pDstPixmap.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*			srcX : x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			srcY : y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			dstX : x-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			dstY : y-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			width : width of the rectangle to be copied
*			height : height of the rectangle to be copied
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. The call is synchronous.
*
******************************************************************************/
int SGALIB_Copy(int task_handle, int srcX, int srcY,
				int dstX, int dstY, int width, int height)
{
	PGraphicsData pTask = &pGD->Task[task_handle];
	UINT4 size;
	t_sga_error     sga_error;
	unsigned int saddr;
	int y1, y2, x1, x2;

	//fprintf(stderr, "C+");
	//DBGPRINTERR("SGALIB_Copy enter...\n");
	//fprintf(stderr, "copy_rect(%d, %d, %d, %d, %d, %d);\n", srcX, srcY, dstX, dstY, width, height);

	while(pTask->TaskChained) {
		// go to next task

		//fprintf(stderr, "TC %d, ", __FUNCTION__, task_handle);
		task_handle = sgalib_get_next_task(task_handle);
		pTask = &pGD->Task[task_handle];

	}
	//fprintf(stderr, "\n ");

	pGD->src_addr = (t_uint32)pGD->fb_phy +
						((unsigned int)pGD->pSrcPixmap->addr
						- (unsigned int)pGD->fb_addr);

	SGA_BufCfgFw_In0_Activate_Generic((unsigned int)pGD->src_addr,
					pGD->pSrcPixmap->line_jump,
					pGD->pSrcPixmap->width,
					pGD->pSrcPixmap->height,
					srcX - dstX,
					srcY - dstY,
					pGD->pSrcPixmap->format);


	if((pGD->src_addr == pGD->dst_addr) && (dstY > srcY))
	{
		// possibly overlapping copies in down direction
		y1 = srcY + height;
		y2 = dstY + height;

		if (y2 > pGD->ScrnHeight) {
			y1 = pGD->ScrnHeight - (y2 - y1);
			y2 = pGD->ScrnHeight;
		}

		do {
			y1 = MAX(y1, dstY);

			SGA_DRAWRECT_FW(pTask, dstX, dstX + width - 1, y1, y2 - 1);
			if(pTask->no_cmd >= BATCH_SIZE - 20) {

				pTask->TaskChained = 1;
				SGA_TASK_START(pTask);
				task_handle = sgalib_get_a_task();
				pTask = &pGD->Task[task_handle];
			}

			y2 = y1;
			y1 += srcY - dstY;;

		} while (y2 != dstY);
	}
	else if ((dstY == srcY) && (dstX > srcX)) {
		// left to right copy .. can have caching problem
		// so split into multiple non-overlapping copies
		x1 = srcX + width;
		x2 = dstX + width;

		if (x2 > pGD->ScrnWidth) {
			x1 = pGD->ScrnWidth - (x2 - x1);
			x2 = pGD->ScrnWidth;
		}

		do {
			x1 = MAX(x1, dstX);

			SGA_DRAWRECT_FW(pTask, x1, x2 - 1, dstY,  dstY + height - 1);
			if(pTask->no_cmd >= BATCH_SIZE - 20) {

				pTask->TaskChained = 1;
				SGA_TASK_START(pTask);
				task_handle = sgalib_get_a_task();
				pTask = &pGD->Task[task_handle];
			}

			x2 = x1;
			x1 += srcX - dstX;;

		} while (x2 != dstX);

	}	else { // cases that dont cause a problem


		SGA_DRAWRECT_FW(pTask, dstX, dstX + width - 1,
								dstY, dstY + height - 1);
		if(pTask->no_cmd >= BATCH_SIZE - 20) {

			pTask->TaskChained = 1;
			SGA_TASK_START(pTask);
			task_handle = sgalib_get_a_task();
			pTask = &pGD->Task[task_handle];
		}

	}

	//DBGPRINTERR("SGALIB_Copy exit...\n");
	//fprintf(stderr, "C-");
	return SGA_SUCCESS;
}

/******************************************************************************
*
*  SGALIB_DoneCopy
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function is the logical completion of the copy calls.
*		It is the conclusion of the SGALIB_PrepareCopy call and closes its
*		context. When this function completes, it also ensures that all the
*		rectangle copy operations requested prior to this call are completed.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. In case of immediate rendering, this function is
*		called after every draw rectangle operation and it ensures that the
*		primitive is rendered before returning. The call is synchronous.
*
******************************************************************************/
int SGALIB_DoneCopy(int task_handle)
{
	//fprintf(stderr, "DC+");
	//DBGPRINTERR("SGALIB_DoneCopy enter...\n");
	SGA_TASK_START(&pGD->Task[task_handle]);
	//fprintf(stderr, "DC-");
	//DBGPRINTERR("SGALIB_DoneCopy exit...\n");
	return SGA_SUCCESS;
}

/******************************************************************************
*
*  SGALIB_PrepareComposite
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to prepare task for copy operations. The pixmaps
*		maps onto an area in the framebuffer and the subsequent copy
*		operations will be on these	pixmap only. This function prepares the
*		system from copying a rectangle somewhere from pSrcPixmap to
*		some place in pDstPixmap.
*
*  INPUTS:	pSrcPixmap : Pixmap detailing the source canvas for copying
*			pMaskBmp : Pixmap detailing the mask canvas for copying
*		pDstPixmap : Pixmap detailing the destination canvas for copying
*
*  OUTPUTS:	None
*
*  RETURNS:	t_handle: handle to the task, OR
*			t_sgalib_errs in case of errors
*
*  REMARKS:	A call to SGALIB_PrepareCopy should have a matching call to
*		SGALIB_DoneCopy. The address in pSrcPixmap and pDstPixmap should be
*		aligned to word boundary. The returned handle should be used in
*		subsequent SGALIB_Copy and SGALIB_DoneCopy calls. This function stores
*		the pSrcPixmap and pDstPixmap information in the tasks' context to be
*		used in subsequent SGALIB_Copy and SGALIB_DoneCopy calls. It is
*		possible for the pSrcPixmap and pDstPixmap to point to the same pixmap
*		in the framebuffer. The call is synchronous.
*
******************************************************************************/
t_handle SGALIB_PrepareComposite (int OpMode, PSga_bitmap pSrcBmp,
								PSga_bitmap pMaskBmp,PSga_bitmap pDstBmp)
{
	UINT4 size;
	t_sga_error     sga_error;
	int dst_odd, task_handle;
	PGraphicsData pTask;
	t_sga_buffer_config bufferconfig;
	t_sga_buffer_pixel_settings pixelsetting;
	t_uint32   *pColor,Color=0;
	char Alpha;
	t_uint32    *pBatchFw;
	unsigned char Is_Packmode;

    switch(OpMode)
    {
		case SGA_PictOpOver:
			if((pSrcBmp->width==1)&&(pSrcBmp->height==1))
			{
				#if 1
				task_handle = sgalib_get_a_task();

 				pTask = &pGD->Task[task_handle];
 				#else
 				task_handle=0;
 				pTask = &pGD->Task[task_handle];
 				#endif


				pColor=(t_uint32*)pSrcBmp->addr;
				Alpha= (*pColor &0xFF000000)>>24;
				Color=((Alpha<<24)|(Alpha<<16)|(Alpha<<8)|(Alpha));/*SrcA*/

				pTask->Component_Alpha = Color;
				pTask->Component_ARGB  = *pColor;

 				pGD->src_addr = (t_uint32)pGD->fb_phy +((unsigned int)pSrcBmp->addr
						                               - (unsigned int)pGD->fb_addr);

				pGD->mask_addr = (t_uint32)pGD->fb_phy +((unsigned int)pMaskBmp->addr
						                               - (unsigned int)pGD->fb_addr);

			    //DBGPRINTERR("task_handle %x \n",task_handle);
			}
			else
			{
				return 0;//NULL
			}
		break;

		case SGA_PictOpAdd:
		    task_handle = sgalib_get_a_task();

 			pTask = &pGD->Task[task_handle];

			pGD->src_addr = (t_uint32)pGD->fb_phy +((unsigned int)pSrcBmp->addr
									               - (unsigned int)pGD->fb_addr);

			if(pMaskBmp)
			pGD->mask_addr = (t_uint32)pGD->fb_phy +((unsigned int)pMaskBmp->addr
						                            - (unsigned int)pGD->fb_addr);
		break;

		default:
			return 0;//NULL
		break;

	}

    pGD->OpMode=OpMode;
	pGD->pSrcPixmap  = pSrcBmp;
	pGD->pMaskPixmap = pMaskBmp;
	pGD->pDstPixmap  = pDstBmp;
	pGD->dst_addr = (t_uint32)pGD->fb_phy + ((unsigned int)pDstBmp->addr
											- (unsigned int)pGD->fb_addr);

	/*Out Buffer Packed image */
	if((pDstBmp->width<<2) == pDstBmp->line_jump)
	{
		pTask->Dst_PackMode = FALSE;
	}
	else
	{
		pTask->Dst_PackMode = TRUE;
	}

	SGA_Out_Buf_Config_Activate(pTask,
							(unsigned int)pGD->dst_addr,
							pDstBmp->line_jump,
							pDstBmp->width,
							pDstBmp->height,
							0,
							0,
						    pDstBmp->format,
					        pTask->Dst_PackMode);

	//fprintf(stderr, "PC-");
     return task_handle;
}

/******************************************************************************
*
*  SGALIB_Composite
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to copy a rectangle from a place in the pSrcPixmap
*		to another place in pDstPixmap.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*			srcX : x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			srcY : y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			maskX: x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pMaskPixmap.
*			maskY: y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pMaskPixmap.
*			dstX : x-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			dstY : y-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			width : width of the rectangle to be copied
*			height : height of the rectangle to be copied
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. The call is synchronous.
*
******************************************************************************/

int SGALIB_Composite(int task_handle, int srcX, int srcY,
					int maskX, int maskY,int dstX, int dstY,
					int width,int height)
{
	int lStatus=SGA_SUCCESS;

	//fprintf(stderr, "C+");

	switch(pGD->OpMode)
	{
		case SGA_PictOpOver:
			 lStatus=sgalib_composite_pictop_over(task_handle,srcX,srcY,maskX,maskY,
		                         dstX,dstY,width,height);
		break;

		case SGA_PictOpAdd:
		    //DBGPRINTERR("SGA_PictOpAdd...\n");
			lStatus=sgalib_pictop_add(task_handle,srcX,srcY,maskX,maskY,
		                         dstX,dstY,width,height);
		break;

		default:
			return 0;//NULL
		break;

	}

	return lStatus;
}

/******************************************************************************
*
*  SGALIB_DoneComposite
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function is the logical completion of the copy calls.
*		It is the conclusion of the SGALIB_PrepareCopy call and closes its
*		context. When this function completes, it also ensures that all the
*		rectangle copy operations requested prior to this call are completed.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. In case of immediate rendering, this function is
*		called after every draw rectangle operation and it ensures that the
*		primitive is rendered before returning. The call is synchronous.
*
******************************************************************************/
int SGALIB_DoneComposite(int task_handle)
{
	#if DEBUG_SGA
	printBatch(&pGD->Task[task_handle]);
	#endif

	SGA_TASK_START_COMP(&pGD->Task[task_handle]);

	return SGA_SUCCESS;
}
/******************************************************************************
*
*  SGALIB_WaitMarker
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function is called to complete the asynchronous operations
*		of SGA. When this function returns, all the tasks of SGA are
*		assumed to be complete.
*
*  INPUTS:	None
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	None
*
******************************************************************************/
int SGALIB_WaitMarker()
{
	unsigned int irq_src;
	int batchno;

	//fprintf(stderr, "pGD->cur_batch_no %d, pGD->dev_addr[SGA_RIS] %x\n", pGD->cur_batch_no, pGD->dev_addr[SGA_RIS]);
	do {
		irq_src = get_sga_irq_status((1 << pGD->IntPosition[pGD->cur_batch_no]));
	} while(!irq_src);

}

///////////////////////////////////////////////////////////////////////////////
// SGA Library Internal Functions
///////////////////////////////////////////////////////////////////////////////


/******************************************************************************
*
*  sgalib_config
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function does initial setup of SGA and runs the main fw
*
*  INPUTS:	None
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sga_error
*
*  REMARKS:	This function is called during library initialization
*
******************************************************************************/
static t_sga_error sgalib_config(void)
{
    int i;
    DBGPRINTF("In SGA Config\n");

    DBGPRINTF("Setting batch fw addr\n");
#ifndef ONLY_2_TASKS
    for (i = 0; i < MAX_BATCHES; i++) {
#else
    for (i = 0; i < 2; i++) {
#endif
        pGD->batch_addr[i] = pGD->fw_addr + BATCH_SIZE * i ;
        DBGPRINTF("pGD->batch_addr[%d] = 0x%x\n", i,
        			(t_uint32)pGD->batch_addr[i]);
    }

    { // sga initialize
        SGA_NoParam_T	data;
        SGA_IOCTL_E cmd=SGA_INITIALIZE;

        data.result=0;
        if ((ioctl(pGD->fd_sga, cmd, (unsigned long)&data))<0) {
        	DBGPRINTERR( "FAIL ioctl err: cmd=0x%x\n", cmd);
        } else {
        	DBGPRINTF("run sga initialize ioctl passed %d\n", __LINE__);
        }
    }

    return SGA_OK;
}

/******************************************************************************
*
*  sgalib_create_task
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function allocates/creates a batch to run on SGA
*
*  INPUTS:	pTask	: Task context in which fields are to be updated after
*			allocation.
*
*  OUTPUTS:	pTask	: Task context in which fields are to be updated after
*			allocation.
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sga_error
*
*  REMARKS:	Updates the fields (batch_id) and (int_id)
*
******************************************************************************/

static t_sga_error sgalib_create_task(PGraphicsData pTask)
{
    t_sga_error     sga_error;

    /*Get the Batch resource  id */
    sga_error = SGA_GetBatchID(&pTask->batch_id);
    if (SGA_OK != sga_error) {
        if ( SGA_RESOURCE_NOT_AVIALABLE == sga_error) {
			DBGPRINTERR("No free batch resource available\n");
        } else {
            DBGPRINTERR("Error in getting batch resource id \
           		(err %d)\n", sga_error);
        }
        return(sga_error);
    }

    /*Get the interrupt resource id  */
    sga_error = SGA_GetIntID(&pTask->int_id);
    if (SGA_OK != sga_error) {
        DBGPRINTERR("Error in getting interrupt resource id \
        	(err %d)\n", sga_error);
        return(sga_error);
    }

    /*Setup the fwmemory to be used*/
    pTask->pBatch_Fw = pGD->batch_addr[pTask->batch_id];

    if(!pTask->pBatch_Fw)
    	return SGA_RESOURCE_NOT_AVIALABLE;

	{ // link batch
		SGA_Batch_T data;
		SGA_IOCTL_E cmd=SGA_LINKBATCH;
		data.result=0;
		data.batch_id = pTask->batch_id;
                data.batch_type = SGALIB_BATCH;
		data.batch_addr = (UINT4)pTask->pBatch_Fw;

		if ((ioctl(pGD->fd_sga, cmd, (unsigned long)&data))<0) {
			DBGPRINTERR( "FAIL ioctl err: cmd=0x%x\n", cmd);
		} else {
			DBGPRINTF("link batch ioctl passed %d\n",
							__LINE__);
		}

	}

	return SGA_OK;
}

/******************************************************************************
*
*  sgalib_delete_task
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function de-allocates/deletes a previously created batch
*
*
*  INPUTS:	pTask	: Task context in which fields are to be updated after
*			deallocation.
*
*  OUTPUTS:	pTask	: Task context in which fields are to be updated after
*			deallocation.
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sga_error
*
*  REMARKS:	Updates the fields (batch_id) and (int_id)
*
******************************************************************************/
static t_sga_error sgalib_delete_task(PGraphicsData pTask)
{
    t_sga_error     sga_error;

    // reset batch address
    pTask->pBatch_Fw = NULL;

    /*Release the interrupt resource id  */
    sga_error = SGA_ReleaseIntID(pTask->int_id);
    if (SGA_OK != sga_error) {
        DBGPRINTERR("Error in releasing int resource id \
        	(err %d)\n", sga_error);
        return SGALIB_ERR;
    }
    pTask->int_id = NULL;

    /*Release the Batch resource  id */
    sga_error = SGA_ReleaseBatchID(pTask->batch_id);
    if (SGA_OK != sga_error) {
        DBGPRINTERR("Error in releasing batch resource id \
        	(err %d)\n", sga_error);
        return(sga_error);
    }
    pTask->batch_id = NULL;

    return SGA_OK;
}

/******************************************************************************
*
*  sgalib_reset
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function calls the ioctl to reset SGA device
*
*
*  INPUTS:	None
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sga_error
*
*  REMARKS:	None
*
******************************************************************************/
static t_sga_error sgalib_reset(void)
{
    SGA_NoParam_T data;
    SGA_IOCTL_E cmd=SGA_RESET;
    data.result=0;
    if ((ioctl(pGD->fd_sga, cmd, (unsigned long)&data))<0) {
        return data.result;
    } else {
        return SGA_OK;
    }
}

/******************************************************************************
*
*  get_sga_irq_status
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function gets the irq status of all batches by checking
*			the SGA raw interrupt status register.
*
*  INPUTS:	None
*
*  OUTPUTS:	None
*
*  RETURNS:	Value of the SGA_RIS register indicating the status of the batches.
*
*  REMARKS:	Uses mapped device registers to trigger batch execution and keeps
*			checking for completion status.
*
******************************************************************************/
t_uint32 get_sga_irq_status(unsigned int irq_src_mask)
{
	volatile t_uint32 *pIrqSrc =  &pGD->dev_addr[SGA_RIS];

	return (*pIrqSrc & irq_src_mask);
}

/******************************************************************************
*
*  clear_sga_irq_status
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function clears the irq status of the batches in SGA
*
*  INPUTS:	irq_src : bits in the SGA_ICR corresponding to the batches for
*				which irq's have to be cleared in the SGA_RIS.
*
*  OUTPUTS:	None
*
*  RETURNS:	Nothing
*
*  REMARKS:	Uses mapped device registers to trigger batch execution and keeps
*			checking for completion status.
*
******************************************************************************/
void inline clear_sga_irq_status(t_uint32 irq_src)
{
	volatile t_uint32 *pIrqClr =  &pGD->dev_addr[SGA_ICR];
	*pIrqClr = irq_src;
}


/******************************************************************************
*
*  sgalib_init_task
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This function sets up the default batch fw for a task
*
*  INPUTS:	pTask	: Task context
*
*  OUTPUTS:	pTask	: Task context
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sga_error
*
*  REMARKS:	Sets the config to 2D by default. There are some one time hw
*		configurations in this which are assumed not to change for
*		all subsequent SGA operations. If this assumption changes, this
*		function needs to be modified.
*
******************************************************************************/
static t_sga_error sgalib_init_task(PGraphicsData pTask)
{
	t_uint32 size=0;
	t_sga_error     sga_error;

	pTask->no_cmd=0;

	sga_error = SGA_BuildSemaphoreConfigFirmware(pTask->batch_id,
					 SGA_SEMAPHORE_RESET,
					 &pTask->pBatch_Fw[pTask->no_cmd],
					 &size);
	if (sga_error != SGA_OK) {
		DBGPRINTERR("Could not build SGA fw\n");
		return SGALIB_ERR;
	}
	pTask->no_cmd += size;

//	pTask->task_fw_size = pTask->no_cmd;
	/* The above line marks the end of common Fw.
	   If required, move this line below to include more
	   code in the default Fw.
	*/

	pTask->pBatch_Fw[pTask->no_cmd++] = CACHE_CTRL | CACHE_CONFIG;
#if 0
	pTask->pBatch_Fw[pTask->no_cmd++] = IN1_SET_PIXEL_TYPE;
	pTask->pBatch_Fw[pTask->no_cmd++] = IN2_SET_PIXEL_TYPE;

	pTask->pBatch_Fw[pTask->no_cmd++] = PIXEL_OP_MODE  | (1 << 18) | (1 << 16) | (1 << 1);
#endif
	pTask->task_fw_size = pTask->no_cmd;

	SGA_TASK_START(pTask); // Run this task with the default Fw.

	return SGA_OK;
}

static int sgalib_get_next_task(int task_handle)
{
	task_handle++;
	task_handle %= MAX_BATCHES;
	//fprintf(stderr, "%s++, task_handle:%d", __FUNCTION__, task_handle);
	return task_handle;
}

static int sgalib_get_a_task(void)
{
	if((pGD->Task[pGD->cur_batch_no]).run_flag == 1) {
		pGD->cur_batch_no++;
		pGD->cur_batch_no %= MAX_BATCHES;
		SGA_Wait_Batch(pGD->cur_batch_no); // waits for irq status of this batch to become 1
	}
	// reset params in this batch
	pGD->Task[pGD->cur_batch_no].run_flag = 0;
	pGD->Task[pGD->cur_batch_no].TaskChained = NULL;
	pGD->Task[pGD->cur_batch_no].no_cmd = pGD->Task[pGD->cur_batch_no].task_fw_size;


	return pGD->cur_batch_no;

}

/******************************************************************************
*
*  sgalib_pictop_composite
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to copy a rectangle from a place in the pSrcPixmap
*		to another place in pDstPixmap.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*			srcX : x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			srcY : y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			maskX: x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pMaskPixmap.
*			maskY: y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pMaskPixmap.
*			dstX : x-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			dstY : y-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			width : width of the rectangle to be copied
*			height : height of the rectangle to be copied
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. The call is synchronous.
*
******************************************************************************/

static int sgalib_composite_pictop_over(int task_handle, int srcX, int srcY,
					int maskX, int maskY,int dstX, int dstY,
					int width,int height)
{
	UINT4 size;
	t_sga_error     sga_error;
	unsigned int saddr;
	int y1, y2, x1, x2;

	PSga_bitmap pSrcBmp,pMaskBmp,pDstBmp;
	t_sga_graphic_command  graphic_command;
	t_uint32    *pBatchFw;
	PGraphicsData pTask;
	t_sga_texture_config  *pPictop_over_texture0 =&pictop_over_texture0[task_handle];


	pTask = &pGD->Task[task_handle];
	pBatchFw = &pTask->pBatch_Fw[pTask->no_cmd];

	pMaskBmp= pGD->pMaskPixmap;
	pDstBmp = pGD->pDstPixmap;
	pSrcBmp = pGD->pSrcPixmap;


        /*in0 buffer pixel settings  */
	SGA_In0_Buf_Config_Activate(pBatchFw,
								(unsigned int)pGD->dst_addr,
								pDstBmp->line_jump,
								width,
								height,
								0,
								0,
								pDstBmp->format,
								TRUE,
								pTask->no_cmd);

	/*in1 pixel settings */
	SGA_In1_Buf_Config_Activate(pBatchFw,(unsigned int)pGD->mask_addr,
									pMaskBmp->line_jump,
									width,
									height,
									0,
									0,
									pMaskBmp->format,
									FALSE,
									pTask->no_cmd);

	 /*OpMode Settings   */
	sga_error = SGA_BuildOpModeFirmware(&OpMode_Conf,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	/*Texture configuration*/
	pPictop_over_texture0->argb_colour     = pTask->Component_Alpha;//Color;/*SRC A*/
	sga_error = SGA_BuildTextureConfigFirmware(pPictop_over_texture0,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	sga_error = SGA_BuildTextureConfigFirmware(&pictop_over_texture1,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	/*Blend Configuration*/
	/* dstX = 0+(1- (SrcA * MaskX))*dstX */
	sga_error =SGA_BuildFrameBlendFirmware(&pictop_over_pass1_blend,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

			/*Draw Rectangle   */
	graphic_command.graphic_type = SGA_GRAPHIC_DRAWRECTANGLE;
	graphic_command.point_x0     = dstX;
	graphic_command.point_y0     = dstY;
	graphic_command.point_x1     = dstX+width-1;
	graphic_command.point_y1     = dstY+height-1;
	graphic_command.colour_set   = TRUE;
	graphic_command.rgb_colour   = 0xFF0000;
	graphic_command.set_bypass_zs= FALSE;

	sga_error = SGA_BuildDrawPrimitiveFirmware(&graphic_command,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	/*wait_config*/
	sga_error = SGA_BuildWaitInstrFirmware(&wait_config,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	/* SrcX * MaskX*/
	pPictop_over_texture0->argb_colour    = pTask->Component_ARGB;/*SrcX*/
	sga_error = SGA_BuildTextureConfigFirmware(pPictop_over_texture0,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	sga_error = SGA_BuildTextureConfigFirmware(&pictop_over_texture1,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	/* dstX= SrcX * MaskX + dstX*/
	/*Blend configurations*/
	sga_error =SGA_BuildFrameBlendFirmware(&pictop_over_pass2_blend,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

		 /*OpMode Settings   */
	sga_error = SGA_BuildOpModeFirmware(&OpMode_Conf,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

			/*Draw Rectangle   */
	graphic_command.graphic_type = SGA_GRAPHIC_DRAWRECTANGLE;
	graphic_command.point_x0     = dstX;
	graphic_command.point_y0     = dstY;
	graphic_command.point_x1     = (dstX+width-1);
	graphic_command.point_y1     = dstY+height-1;
	graphic_command.colour_set   = TRUE;
	graphic_command.rgb_colour   = 0xFF0000;
	graphic_command.set_bypass_zs= FALSE;

	sga_error = SGA_BuildDrawPrimitiveFirmware(&graphic_command,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	/*wait_config*/
	sga_error = SGA_BuildWaitInstrFirmware(&wait_config,pBatchFw,&size);
	pBatchFw+=size;
	pTask->no_cmd+= size;

	SGA_In0_Buf_Config_DeActivate(pBatchFw,pTask->no_cmd);
	SGA_In1_Buf_Config_DeActivate(pBatchFw,pTask->no_cmd);

	if(pTask->no_cmd >= BATCH_SIZE - 20)
	{
		pTask->TaskChained = 1;
		SGA_TASK_START_COMP(pTask);
		task_handle = sgalib_get_a_task();
		pTask = &pGD->Task[task_handle];
	}

	return SGA_SUCCESS;

}

/******************************************************************************
*
*  sgalib_pictop_add
*  ___________________________________________________________________________
*
*  DESCRIPTION:	This is used to copy a rectangle from a place in the pSrcPixmap
*		to another place in pDstPixmap.
*
*  INPUTS:	handle : task handle obtained from the SGALIB_PrepareCopy call
*			srcX : x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			srcY : y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			maskX: x-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pMaskPixmap.
*			maskY: y-coordinate of top left corner of source rectangle.
*					It is the offset from the base of the pMaskPixmap.
*			dstX : x-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			dstY : y-coordinate of top left corner of destination rectangle.
*					It is the offset from the base of the pSrcPixmap.
*			width : width of the rectangle to be copied
*			height : height of the rectangle to be copied
*
*  OUTPUTS:	None
*
*  RETURNS:	SGALIB_SUCCESS if it passes, else one of the error codes
*		from t_sgalib_errs
*
*  REMARKS:	It is mandatory that a valid handle is used in the handle
*		parameter. For this there should be a valid SGALIB_PrepareCopy call
*		preceeding this call. The call is synchronous.
*
******************************************************************************/


static int sgalib_pictop_add(int task_handle, int srcX, int srcY,
					int maskX, int maskY,int dstX, int dstY,
					int width,int height)
{

		UINT4 size;
		t_sga_error     sga_error;
		unsigned int saddr;
		int y1, y2, x1, x2;
		PSga_bitmap pSrcBmp,pMaskBmp,pDstBmp;
		t_sga_graphic_command  graphic_command;
		t_uint32    *pBatchFw;

		PGraphicsData pTask = &pGD->Task[task_handle];
		pBatchFw = &pTask->pBatch_Fw[pTask->no_cmd];

		pMaskBmp= pGD->pMaskPixmap;
		pDstBmp = pGD->pDstPixmap;
		pSrcBmp = pGD->pSrcPixmap;


		/*in0 buffer pixel settings  */

		SGA_In0_Buf_Config_Activate(pBatchFw,
									(unsigned int)pGD->dst_addr,
									pDstBmp->line_jump,
									width,
									height,
									0,
									0,
									pDstBmp->format,
									pTask->Dst_PackMode,
									pTask->no_cmd);

		/*in1 pixel settings */
		SGA_In1_Buf_Config_Activate(pBatchFw,
									(unsigned int)(pGD->src_addr-pSrcBmp->line_jump),
									pSrcBmp->line_jump,
									width,
									height,
									0,
									0,
									pSrcBmp->format,
									FALSE,
									pTask->no_cmd);
		if(pMaskBmp)
		{
			/*in2 pixel settings */
			SGA_In2_Buf_Config_Activate(pBatchFw,
										(unsigned int) pGD->mask_addr,
										pMaskBmp->line_jump,
										width,
										height,
										0,
										0,
										pMaskBmp->format,
										FALSE,
										pTask->no_cmd);
		}


		/*Texture configuration*/

		/*SrcX * MaskX*/
		sga_error = SGA_BuildTextureConfigFirmware(&pictop_add_texture0,pBatchFw,&size);
		pBatchFw+=size;
		pTask->no_cmd+= size;

		if(pMaskBmp)
		{
			sga_error = SGA_BuildTextureConfigFirmware(&pictop_add_texture1,pBatchFw,&size);
			pBatchFw+=size;
			pTask->no_cmd+= size;
		}
		else
		{
			sga_error = SGA_BuildTextureConfigFirmware(&pictop_add_without_mask_texture1,pBatchFw,&size);
			pBatchFw+=size;
			pTask->no_cmd+= size;

		}

		/*Blend Configuration*/
		/* dstX = SRCX * MaskX+dstX */
		sga_error =SGA_BuildFrameBlendFirmware(&pictop_add_blend,pBatchFw,&size);
		pBatchFw+=size;
		pTask->no_cmd+= size;

		/*OpMode Settings   */
		sga_error = SGA_BuildOpModeFirmware(&OpMode_Conf,pBatchFw,&size);
		pBatchFw+=size;
		pTask->no_cmd+= size;

				/*Draw Rectangle   */
		graphic_command.graphic_type = SGA_GRAPHIC_DRAWRECTANGLE;
		graphic_command.point_x0     = dstX;
		graphic_command.point_y0     = dstY;
		graphic_command.point_x1     = dstX+width-1;
		graphic_command.point_y1     = dstY+height-1;
		graphic_command.colour_set   = TRUE;
		graphic_command.rgb_colour   = 0xFF0000;
		graphic_command.set_bypass_zs= FALSE;

		sga_error = SGA_BuildDrawPrimitiveFirmware(&graphic_command,pBatchFw,&size);
		pBatchFw+=size;
		pTask->no_cmd+= size;

		/*Wait Configurations*/
		sga_error = SGA_BuildWaitInstrFirmware(&wait_config,pBatchFw,&size);
		pBatchFw+=size;
		pTask->no_cmd+= size;

		SGA_In0_Buf_Config_DeActivate(pBatchFw,pTask->no_cmd);
		SGA_In1_Buf_Config_DeActivate(pBatchFw,pTask->no_cmd);

		if(pMaskBmp)
		{
			SGA_In2_Buf_Config_DeActivate(pBatchFw,pTask->no_cmd);
		}

		SGA_Blend_DeActivate(pBatchFw,pTask->no_cmd);

		if(pTask->no_cmd >= BATCH_SIZE - 20)
		{
			pTask->TaskChained = 1;
			SGA_TASK_START_COMP(pTask);
			task_handle = sgalib_get_a_task();
			pTask = &pGD->Task[task_handle];
		}
		return SGA_SUCCESS;


}

int SGA_LIB_Draw_Line(PSga_bitmap pPixmap, unsigned int colour,int x1,int y1,int x2,int y2)
{
   UINT4 size;
   t_sga_error     sga_error;
	int dst_odd, task_handle;
	PGraphicsData pTask;

		//fprintf(stderr, "PS+");
	//DBGPRINTERR("SGALIB_PrepareSolid enter...\n");
	 	task_handle = 1;
	 	pTask = &pGD->Task[1];

		pTask->pBatch_Fw[pTask->no_cmd++] = PIXEL_OP_MODE  | (1 << 18) | (1 << 16) | (1 << 1);

		switch(pPixmap->bitspp)
		{
		    case 8:
			colour = ((colour & 0xff) << 16) 	| ((colour & 0xff) << 8)
								| (colour & 0xff);
			break;
		    case 16:
			colour = ((colour & 0x1f) << 3 ) 	| ((colour & 0x7e0) << 5)
								| ((colour & 0xf800) << 8);
			break;
		    case 24:
			break;
		    case 32:
			break;
		    default:
			return SGALIB_FORMAT_ERR;
		}
		//fprintf(stderr, "set_col(%x);\n", colour);

		SGA_BufCfgFw_Out_Activate_Generic (pTask,
						(unsigned int)pGD->fb_phy + ((unsigned int)pPixmap->addr
													- (unsigned int)pGD->fb_addr),
						pPixmap->line_jump,
						pPixmap->width,
						pPixmap->height,
						0,
						0,
						pPixmap->format);

		pTask->pBatch_Fw[pTask->no_cmd++] = IN0_SET_PIXEL_TYPE | (1 << 8) | (1 << 4) | SGA_PIXEL_FORMAT_ARGB24;
		pTask->pBatch_Fw[pTask->no_cmd++] = SET_COLOR | (0xFFFFFF & (colour));

	    SGA_DRAWLINE_FW(pTask, x1, x2 - 1, y1, y2 - 1);

	    SGA_TASK_START(pTask);

}

int OGL_SGALIB_Init(unsigned long batch0Addr,
				    unsigned long batch1Addr,
				    unsigned long* sga_dev_addr)
{
    int pg_size, i, f_sga, len;
    t_sga_error     sga_error;

    PGraphicsData pTask;

    // Open Devices
    f_sga = open(SGA_DEVICE, O_RDWR);
    //DBGPRINTERR("sgaLib_init enter...\n");
    if ( -1 == f_sga) {
            DBGPRINTERR("sga open error...\n");
            return SGALIB_OPEN_ERR;
    }

    // Allocate and initialize memory for global structure
    pGD = (PGData)malloc(sizeof(GData));
    if (!pGD) {
            DBGPRINTERR("Mem allocation failed\n");
            close(f_sga);
            return SGALIB_MEM_ALLOC_ERR;
    }
    memset(pGD, 0, sizeof(GData));

    pGD->fd_sga = f_sga;
    
    // mmap start
    pg_size = getpagesize();

    len = NPAGES * pg_size;

    DBGPRINTF("fw mmap len = %d\n", len);
    pGD->fw_addr = mmap(0, len,
    	PROT_READ | PROT_WRITE, MAP_SHARED| MAP_LOCKED,
    	pGD->fd_sga, FW_MEMORY*pg_size);
    if (MAP_FAILED == pGD->fw_addr) {
            DBGPRINTERR("mmap() for fw memory failed\n");
            return SGALIB_ERR;
    } else {
            DBGPRINTF("pGD->fw_addr = %x\n", (t_uint32)pGD->fw_addr);
    }


	len = 1 * pg_size;
	DBGPRINTF("dev len to mmap %d\n", len);
	pGD->dev_addr = mmap(0, len,
		PROT_READ | PROT_WRITE, MAP_SHARED| MAP_LOCKED,
		pGD->fd_sga, DEV_MEMORY*pg_size);
	if (MAP_FAILED == pGD->dev_addr) {
		DBGPRINTERR("mmap() for dev memory failed\n");
		return SGALIB_ERR;
	} else {
		DBGPRINTF("pGD->dev_addr = %x\n", (t_uint32)pGD->dev_addr);
        }
        // mmap complete
	*sga_dev_addr = pGD->dev_addr;
   //  pGD->batch_addr[0] = pGD->fw_addr + BATCH_SIZE ;
  	pGD->batch_addr[0] = batch0Addr;
  	pGD->batch_addr[1] = batch1Addr;
     { // sga initialize
	         SGA_NoParam_T	data;
	         SGA_IOCTL_E cmd=SGA_INITIALIZE;

	         data.result=0;
	         if ((ioctl(pGD->fd_sga, cmd, (unsigned long)&data))<0) {
	         	DBGPRINTERR( "FAIL ioctl err: cmd=0x%x\n", cmd);
	         } else {
	         	DBGPRINTF("run sga initialize ioctl passed %d\n", __LINE__);
	         }
    }
for(i=0;i<2;i++)
{
    pTask = &pGD->Task[i];

    sga_error = SGA_GetBatchID(&pTask->batch_id);
	    if (SGA_OK != sga_error) {
	        if ( SGA_RESOURCE_NOT_AVIALABLE == sga_error) {
				DBGPRINTERR("No free batch resource available\n");
	        } else {
	            DBGPRINTERR("Error in getting batch resource id \
	           		(err %d)\n", sga_error);
	        }
	        return(sga_error);
	    }
	    /*Get the interrupt resource id  */
	    sga_error = SGA_GetIntID(&pTask->int_id);
	    if (SGA_OK != sga_error) {
	        DBGPRINTERR("Error in getting interrupt resource id \
	        	(err %d)\n", sga_error);
	        return(sga_error);
	    }

	   
		{ // link batch
			SGA_Batch_T data;
			SGA_IOCTL_E cmd=SGA_LINKBATCH;
			data.result=0;
			data.batch_id = pTask->batch_id;
                        data.batch_type = OGLLIB_BATCH;
			data.batch_addr = (UINT4)pGD->batch_addr[i];

			if ((ioctl(pGD->fd_sga, cmd, (unsigned long)&data))<0) {
				DBGPRINTERR( "FAIL ioctl err: cmd=0x%x\n", cmd);
			} else {
				DBGPRINTF("link batch ioctl passed %d\n",
								__LINE__);
			}

			DBGPRINTF("Batch Linked %d, %x\n", pTask->batch_id,
							pTask->pBatch_Fw);
		}

}
		pGD->IntPosition[0] = 0;
		pGD->IntPosition[1] = 1;
		for(i = 2; i < MAX_BATCHES; i++) {
			pGD->IntPosition[i] = i + 6;
		}


    return NULL;
}

int OGL_SGALIB_DeInit()
{
	int ret = 0, i, len;
	t_sga_error     sga_error;
	SGA_TaskCounts_T *pShm;
	PGraphicsData pTask;

	// sga clear default contexts for 3 tasks, delete batches, reset, close
	sga_error = sgalib_reset();
	if (SGA_OK != sga_error)
	{
		DBGPRINTERR("Error in reset (%d)\n", sga_error);
		return SGALIB_ERR;
	}

	for (i=0;i<2;i++)
	{
		pTask = &pGD->Task[i];

		sga_error = SGA_ReleaseBatchID(pTask->batch_id);
			if (SGA_OK != sga_error)
			{
					DBGPRINTERR("Error in getting batch resource id \
						(err %d  test %d )\n", sga_error,i);
				return(sga_error);
			}
			/*Get the interrupt resource id  */
			sga_error = SGA_ReleaseIntID(pTask->int_id);
			if (SGA_OK != sga_error)
			{
				DBGPRINTERR("Error in getting interrupt resource id \
					(err %d)\n", sga_error);
				return(sga_error);
			}
	}




    len = 1 * getpagesize();
    ret = munmap(pGD->dev_addr, len);
    if (ret) {
            DBGPRINTERR("munmap() for dev memory failed with %d\n", ret);
    }

    len = NPAGES * getpagesize();
    ret = munmap(pGD->fw_addr, len);
    if (ret) {
            DBGPRINTERR("munmap() for fw memory failed with %d\n", ret);
    }
    close(pGD->fd_sga);

    free(pGD);

    return SGALIB_SUCCESS;
}


#if DEBUG_SGA
void printBatch(PGraphicsData pTask)
{
	int i = 0;
	unsigned int * pBatchFw = &pTask->pBatch_Fw[0];

	for(i = 0; i < pTask->no_cmd; i++) {
		printf("%x\n", *pBatchFw++);
	}
}
#endif
