/******************************************************************************
 * � copyright STMicroelectronics, 2007. All rights reserved. For
 * information, STMicroelectronics reserves the right to license this
 * software concurrently under separate license conditions.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *****************************************************************************/
/******************************************************************************
 * Subsystem	: SGA Library API Test
 * File			: sgalib_test.c
 * Description	: This file contains the usage of SGA library. This
 *			  	will be used to test SGA Library
 * Created		: 15.04.2007
 * Version		: 1.5
 *
 *****************************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <linux/fb.h>
#include <sys/time.h>
#include "sga_lib.h"

// defines
#define ITER1	1
#define ITER2	1
#define ITER_PERF 5

#if 0
  #define SLEEP(x) sleep(x)
  #define USLP(x) usleep(x)
#else
  #define SLEEP(x) do {} while(0)
  #define USLP(x) do {} while(0)
#endif

#define FB_DEVICE 	"/dev/fb0"

// globals

typedef struct
{
        int x0;			// x-coordinate of top left corner
        int y0;			// y-coordinate of top left corner
        unsigned int width;	// width of rectangle
        unsigned int height;	// height of rectangle
}
Rect;				// structure of a rectangle


typedef struct
{
        int x;			// x-coordinate of a point
        int y;			// y-coordinate of a point
}
Point;				// structure of a point


// test functions


void draw_rect_borders(Rect rect, unsigned int colour);
void test_rect_fill(void);
void random_cursor_test(void);
void test_simlutaneous_stuff(void);

unsigned char *fb_addr;
struct fb_var_screeninfo fb_var;
struct fb_fix_screeninfo fb_fix;
unsigned int col;
unsigned char *fb_offscreen_addr, ans;
int imode;
    int fail;
int main(int argc, char *argv[])
{
    int i, j, ret;
    int fd_fb;
    struct timeval t_start, t_finish;
    double elapsed;
    int pixel_per_sec, performance;


    imode = 0;

    if(argc > 1) {
		printf("SGALib Test\n");
	    imode = 1;
	    i = 0;
	    while(i <= argc) {
		    printf("arg%d : %s\n", i, argv[i]);
		    i++;
	    }
    }

    // Open fb
    fd_fb = open(FB_DEVICE, O_RDWR);
    if ( -1 == fd_fb) {
        printf("fb open error...\n");
        return -1;
    }

    // Get fb screeninfo
    if ((ioctl(fd_fb, FBIOGET_FSCREENINFO,
               (unsigned long)&fb_fix))<0) {
        printf( "FAIL fb ioctl err\n");
        return -1;
    }

    // Get fb screeninfo
    if ((ioctl(fd_fb, FBIOGET_VSCREENINFO,
               (unsigned long)&fb_var))<0) {
        printf( "FAIL fb ioctl err\n");
        return -1;
    }
    printf("fb_var.xres:%d, fb_var.yres:%d, fb_var.bits_per_pixel:%d, \
    		fb_fix.smem_len:%d, fb_fix.smem_start:%d\n",fb_var.xres,
    			fb_var.yres, fb_var.bits_per_pixel, fb_fix.smem_start);


    fb_addr = mmap(0, fb_fix.smem_len, PROT_READ | PROT_WRITE,
    					MAP_SHARED| MAP_LOCKED, fd_fb, 0);
    if (MAP_FAILED == fb_addr) {
        printf("mmap() for fb memory failed\n");
        perror("mmap failed");
        return -1;
    } else {
        printf("fb_addr = %x\n", (unsigned int)fb_addr);
    }

    fb_offscreen_addr = fb_addr + \
    				(fb_var.xres * fb_var.yres * fb_var.bits_per_pixel / 3);

    i = ITER1;
    gettimeofday(&t_start, NULL);
    while (i--) {
        SGALIB_Init(fb_addr, fb_var.xres, fb_var.yres, fb_var.bits_per_pixel,
        								fb_fix.smem_len, fb_fix.smem_start);
        j = ITER2;
        while (j--) {

            printf("Iteration no: %d, %d\n", i, j);
            test_rect_fill(); // test rect fill
            SLEEP(1);

            test_bitmap_copy(); // copy fb to fb
            SLEEP(1);

            test_simlutaneous_stuff(); // copy fb to fb
            SLEEP(1);
			random_cursor_test();

        }
    gettimeofday(&t_finish, NULL);

    elapsed = t_finish.tv_sec - t_start.tv_sec +
    			(t_finish.tv_usec - t_start.tv_usec) / 1.e6;
    printf("Time, %.9f\n", elapsed);
	SGALIB_WaitMarker();

        SGALIB_DeInit();

    }


    ret = munmap(fb_addr, fb_fix.smem_len);
    if (ret) {
        printf("munmap() for fb memory failed with %d\n", ret);
    }
    close(fd_fb);

    printf("End All\n");
    return 0;
}


unsigned int c_adj(unsigned int col)
{
    unsigned int new_col;
    new_col = col;

    if (fb_var.bits_per_pixel == 16) {
        new_col = ((col & 0xf80000) >> 8) | ((col & 0xfc00) >> 5) \
        								| ((col & 0xf8) >> 3);
    }

    return new_col;
}

void clear_screen()
{
    int task_handle;
    Sga_bitmap BMap;
    int i, j, k = 0, red, green, blue;
    unsigned int color;
    unsigned char *fbptr = fb_addr;

    SGALIB_WaitMarker();

	for(i = 0; i < fb_var.yres; i++) {
		for(j = 0; j < fb_var.xres; j++) {
			red = 255 - (255 * i / fb_var.yres);
			green = 255 - (255 * j / fb_var.xres);
			blue = ((255 * j / fb_var.xres) + (255 * i / fb_var.yres))/2;
			color = ((red & 0xff) << 16) | ((green & 0xff) << 8) \
										| (blue & 0xff);
			color = c_adj(color);
			memcpy(fbptr, &color, (fb_var.bits_per_pixel >> 3));
		  fbptr +=  (fb_var.bits_per_pixel >> 3);
		}
	}

    USLP(900);
}

void test_simlutaneous_stuff(void)
{
    unsigned int colour;
    int i, j, k, count, x0, y0;
    Sga_bitmap BMap;
    unsigned char *fbptr = fb_addr;
    int task_handle, xoff, yoff1, yoff2;
        Rect rect;
        Point pt;


    BMap.addr = fbptr;
    BMap.line_jump = fb_var.xres * (fb_var.bits_per_pixel >> 3);
    BMap.width = fb_var.xres;
    BMap.height = fb_var.yres;
    BMap.bitspp = fb_var.bits_per_pixel;
    if (16 == fb_var.bits_per_pixel) {
        BMap.format = SGALIB_RGB16;
    } else if (24 == fb_var.bits_per_pixel) {
        BMap.format = SGALIB_ARGB24;
    } else {
        printf("Unsupported format !\n");
    }


    colour = 0x000000; // black
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, 0, 0, fb_var.xres, fb_var.yres);
    SGALIB_DoneSolid(task_handle);


    colour = 0x808080; // grey
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, fb_var.xres - 30, 20, fb_var.xres, fb_var.yres - 20);
    SGALIB_DoneSolid(task_handle);


	for(i = 0; i < 100; i++) {
	    colour = 0x80ff80; // green
	    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
	    SGALIB_Solid(task_handle, fb_var.xres - 28, 20 + 50 + i, fb_var.xres - 1, 20 + 50 + i);
	    SGALIB_DoneSolid(task_handle);
	}

    colour = 0xffffff; // white
    xoff = 10;
    yoff1 = fb_var.yres - 70 - 10;
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, xoff, yoff1, xoff + 70, yoff1 + 70);
    SGALIB_DoneSolid(task_handle);

    colour = 0xff0000; // red
    xoff += 90;
    yoff2 = 10;
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, xoff, yoff2, xoff + 70, yoff2 + 70);
    SGALIB_DoneSolid(task_handle);

    colour = 0x00ff00; // green
    xoff += 90;
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, xoff, yoff1, xoff + 70, yoff1 + 70);
    SGALIB_DoneSolid(task_handle);

    colour = 0x0000ff; // blue
    xoff += 90;
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, xoff, yoff2, xoff + 70, yoff2 + 70);
    SGALIB_DoneSolid(task_handle);

    colour = 0xffffff; // white
    xoff += 90;
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, xoff, yoff1, xoff + 70, yoff1 + 70);
    SGALIB_DoneSolid(task_handle);

    colour = 0xff0000; // red
    xoff += 90;
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, xoff, yoff2, xoff + 70, yoff2 + 70);
    SGALIB_DoneSolid(task_handle);

    colour = 0x00ff00; // green
    xoff += 90;
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, xoff, yoff1, xoff + 70, yoff1 + 70);
    SGALIB_DoneSolid(task_handle);

    colour = 0x0000ff; // blue
    xoff += 90;
    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
    SGALIB_Solid(task_handle, xoff, yoff2, xoff + 70, yoff2 + 70);
    SGALIB_DoneSolid(task_handle);


    for(i = 0; i < 5; i++) {
        rect.x0 = 10;
        rect.y0 = yoff1;
        rect.width = 70;
        rect.height = 70;

        pt.y = rect.y0 - rect.height - 10;

        for(j = 0; j < 4; j++) {
        pt.x = rect.x0;
        USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        rect.x0 += 90 * 2;
	}


	rect.x0 = 10 + 90;
        rect.y0 = yoff2;
        pt.y = rect.y0 + rect.height + 10;

        for(j = 0; j < 4; j++) {
        pt.x = rect.x0;
        USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        rect.x0 += 90 * 2;
	}

	colour = 0x0000; // black
	xoff = 10;
	for(j = 0; j < 4; j++) {
	    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
	    SGALIB_Solid(task_handle, xoff, yoff1, xoff + 70, yoff1 + 70);
	    SGALIB_DoneSolid(task_handle);
	    xoff += 90 * 2;
        }
        yoff1 -= 80;


	xoff = 10 + 90;
	for(j = 0; j < 4; j++) {
	    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
	    SGALIB_Solid(task_handle, xoff, yoff2, xoff + 70, yoff2 + 70);
	    SGALIB_DoneSolid(task_handle);
	    xoff += 90 * 2;
        }
        yoff2 += 80;

    }
    SGALIB_WaitMarker();
	if(imode) {
		SGALIB_WaitMarker();
		printf("Are rectangles copied properly without artefacts?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}
}

void test_rect_fill()
{
    unsigned int colour;
    int i, j, k, count, x0, y0;
    Sga_bitmap BMap;
    unsigned char *fbptr = fb_addr;
    int task_handle;


    BMap.addr = fbptr;
    BMap.line_jump = fb_var.xres * (fb_var.bits_per_pixel >> 3);
    BMap.width = fb_var.xres;
    BMap.height = fb_var.yres;
    BMap.bitspp = fb_var.bits_per_pixel;
    if (16 == fb_var.bits_per_pixel) {
        BMap.format = SGALIB_RGB16;
    } else if (24 == fb_var.bits_per_pixel) {
        BMap.format = SGALIB_ARGB24;
    } else {
        printf("Unsupported format !\n");
    }
	clear_screen();

	{ // case: draw 2 simple rects
		colour = 0xff0000; // red
		task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
		SGALIB_Solid(task_handle, 10, 20, 110, 120);
		SGALIB_DoneSolid(task_handle);

		if(imode) {
			SGALIB_WaitMarker();
			printf("Is red square drawn?(y/n): %c\n"); ans = tolower(getchar()); printf("\n");
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}

		colour = 0xff00; // green
		task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
		SGALIB_Solid(task_handle, 210, 20, 310, 120);
		SGALIB_DoneSolid(task_handle);

		if(imode) {
			SGALIB_WaitMarker();
			printf("Is green square drawn?(y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}

	} // case: draw 2 simple rects


	    clear_screen();

		{ // case: fill full screen with lines of 1 pixel width
	    // draw black lines
	    colour = 0x00;
	    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
	    for (i = 0; i < fb_var.xres/2; i++) {
	        SGALIB_Solid(task_handle, i * 2, 0, i * 2 + 1, fb_var.yres);
	        USLP(900);
	    }
	    SGALIB_DoneSolid(task_handle);

		if(imode) {
			SGALIB_WaitMarker();
			printf("Are alternate black lines drawn?(y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}

			// draw white lines
	    colour = 0xffffff;
	    task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
	    for (i = 0; i < fb_var.xres/2; i++) {
	        SGALIB_Solid(task_handle, i * 2 + 1, 0, i * 2 + 2, fb_var.yres);
	        USLP(900);
	    }
	    SGALIB_DoneSolid(task_handle);

		if(imode) {
			SGALIB_WaitMarker();
			printf("Are alternate white lines drawn?(y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}


		} // case: fill full screen with lines of 1 pixel width

    	clear_screen();

		{ // case: draw rectangles increasing / decreasing width
		  // and height of diff colors
	    colour = 0xff0000;
	    x0 = 0;
	    y0 = 0;
	    while (1) {
	        task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
	        for (i = 1; i < 200; i++) {
	            SGALIB_Solid(task_handle, x0, y0, x0 + i, y0 + i);
	            USLP(900);
	        }
	        SGALIB_DoneSolid(task_handle);

	        x0 += 210;
	        if (x0 > (fb_var.xres - 200)) {
	            x0 = 0;
	            y0 += 210;
	        }
	        if (!colour)
	            colour = 0xffffffff;
	        if (colour == 0xffffff)
	            break;

	        colour >>= 8;
	        USLP(90000);
	    }

	    colour = 0xff0000;
	    x0 = 0;
	    y0 = 0;
	    while (1) {
	        task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
	        for (i = 200; i > 0; i--) {
	            SGALIB_Solid(task_handle, x0, y0, x0 + i, y0 + i);
	            USLP(900);
	        }
	        SGALIB_DoneSolid(task_handle);

	        x0 += 210;
	        if (x0 > (fb_var.xres - 200)) {
	            x0 = 0;
	            y0 += 210;
	        }
	        if (!colour)
	            colour = 0xffffffff;
	        if (colour == 0xffffff)
	            break;

	        colour >>= 8;
	        USLP(90000);
	    }

		if(imode) {
			SGALIB_WaitMarker();
			printf("Are 5 filled rectangles drawn?(y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}
	}
	// case: draw rectangles increasing / decreasing width
	//  and height of diff colors

	{
		x0 = 0;
		y0 = 0;
		colour = 0x00;

		for (i = fb_var.yres; i > 0; i--) {
			task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
			SGALIB_Solid(task_handle, x0, y0, x0 + i, y0 + i);
			SGALIB_DoneSolid(task_handle);
			if (colour)
				colour = 0;
			else
				colour = 0xffffff;
			USLP(9000);
		}
		USLP(90000);
		if(imode) {
			SGALIB_WaitMarker();
			printf("Did squares of black and white alternate fill screen?\n The squares start from bottom right to top left,\n reducing in size by 1 pixel each (y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}
	}
    // try with diff colors
	{
		x0 = 0;
		y0 = 0;
		colour = 0x00ff0000;

		for (i = fb_var.yres; i > 0; i--) {
			task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
			SGALIB_Solid(task_handle, x0, y0, x0 + i, y0 + i);
			SGALIB_DoneSolid(task_handle);
			if (colour == 0xff00)
				colour = 0xff0000;
			else
				colour = 0xff00;
			USLP(9000);
		}
		USLP(90000);
		if(imode) {
			SGALIB_WaitMarker();
			printf("Did squares of red and green alternate fill screen?\n The squares start from bottom right to top left,\n reducing in size by 1 pixel each (y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}
	}
	{
		x0 = 0;
		y0 = 0;
		colour = 0x00;


		for (i = fb_var.yres; i > 0; i-=2) {
			task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
			SGALIB_Solid(task_handle, x0, y0, x0 + i, y0 + i);
			SGALIB_DoneSolid(task_handle);
			x0++;
			y0++;
			if (colour)
				colour = 0;
			else
				colour = 0xffffff;
			USLP(9000);
		}
		USLP(90000);
		if(imode) {
			SGALIB_WaitMarker();
			printf("Did squares of black and white alternate fill screen?\n The squares are drawn in centre of previous square,\n reducing in size by 2 pixel each (y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}
	}
	{
		// try with diff colors
		x0 = 0;
		y0 = 0;
		colour = 0xff00;


		for (i = fb_var.yres; i > 0; i-=2) {
			task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
			SGALIB_Solid(task_handle, x0, y0, x0 + i, y0 + i);
			SGALIB_DoneSolid(task_handle);
			x0++;
			y0++;
			if (colour == 0xff00)
				colour = 0xff0000;
			else
				colour = 0xff00;
			USLP(9000);
		}
		USLP(90000);
		if(imode) {
			SGALIB_WaitMarker();
			printf("Did squares of red and green alternate fill screen?\n The squares are drawn in centre of previous square,\n reducing in size by 2 pixel each (y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}
	}
	{
		colour = 0xff0000;
		for (i = 0; i < fb_var.yres; i+=16) {
			for (j = 0; j < fb_var.xres; j+=16) {
				x0 = j;
				y0 = i;
				task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
				SGALIB_Solid(task_handle, x0, y0, x0 + 16, y0 + 16);
				SGALIB_DoneSolid(task_handle);
				if (!colour)
					colour = 0xff000000;
				colour >>= 8;
			}
		}
		if(imode) {
			SGALIB_WaitMarker();
			printf("Did squares of different colours and of constant size fill the screen?(y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}
	}


	{
		USLP(90000);
		count = 0;
		x0 = 0;
		y0 = 0;
		colour = 0xff0000;
		for (k = 1; k < fb_var.yres/2; k++) {
			for (i = 0; i < fb_var.yres - k; i+=k) {
				for (j = 0; j < fb_var.xres - k; j+=k) {
					count ++;

					task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
					SGALIB_Solid(task_handle, x0 + j, y0 + i,
												x0 + j + k, y0 + i + k);
					SGALIB_DoneSolid(task_handle);

					colour = 0;
					if (count & 1) colour |= 0xff;
					if (count & 2) colour |= 0xff00;
					if (count & 4) colour |= 0xff0000;
					count %= 8;
				}
			}
		}
		if(imode) {
			SGALIB_WaitMarker();
			printf("Did squares of different colours and of increasing sizes fill the screen?(y/n): %c\n"); ans = tolower(getchar());
			if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
		}
	}

}


/*
This fuction is to Draw the rectangle borders
*/
void draw_rect_borders(Rect rect, unsigned int colour)
{
    unsigned char *fbptr;
    int i, x0, x1, y0, y1;
    unsigned int col;

	SGALIB_WaitMarker();

    col = c_adj(colour);
    x0 = rect.x0;
    x1 = x0 + rect.width;
    y0 = rect.y0;
    y1 = y0 + rect.height;

    // use memcopy
    fbptr = fb_addr;
    fbptr += (x0 + y0 * fb_var.xres) * (fb_var.bits_per_pixel >> 3);

    for (i = 0; i < (x1 - x0); i++) {
        memcpy(&fbptr[i * (fb_var.bits_per_pixel >> 3)], &col,
        							(fb_var.bits_per_pixel >> 3));
    }

    for (i = 0; i < (y1 - y0) - 2; i++) {
        fbptr += fb_var.xres * (fb_var.bits_per_pixel >> 3);
        memcpy(&fbptr[0], &col, (fb_var.bits_per_pixel >> 3));
        memcpy(&fbptr[(x1 - x0 - 1) * (fb_var.bits_per_pixel >> 3)],
        							&col, (fb_var.bits_per_pixel >> 3));
    }
    fbptr = fb_addr;
    fbptr += (x0 + (y1 - 1) * fb_var.xres) * (fb_var.bits_per_pixel >> 3);
    for (i = 0; i < (x1 - x0); i++) {
        memcpy(&fbptr[i * (fb_var.bits_per_pixel >> 3)], &col,
        									(fb_var.bits_per_pixel >> 3));
    }
    SLEEP(1);
}

void SGALIBTEST_Copy(Rect rect, Point pt)
{
    Sga_bitmap sBMap, dBMap;
    unsigned char *fbptr = fb_addr;
    int task_handle, val;

    if(pt.x < 0) {
    	val = -pt.x;
    	rect.x0 += val;
    	rect.width -= val;
    	pt.x = 0;
    }

    if(pt.y < 0) {
    	val = -pt.y;
    	rect.y0 += val;
    	rect.height -= val;
    	pt.y = 0;
    }

    if(pt.x + rect.width > fb_var.xres) {
    	val = pt.x + rect.width - fb_var.xres;
    	rect.width -= val;
    }

    if(pt.y + rect.height > fb_var.yres) {
    	val = pt.y + rect.height - fb_var.yres;
    	rect.height -= val;
    }

    sBMap.addr = fbptr;
    sBMap.line_jump = fb_var.xres * (fb_var.bits_per_pixel >> 3);
    sBMap.width = fb_var.xres;
    sBMap.height = fb_var.yres;
    if (16 == fb_var.bits_per_pixel) {
        sBMap.format = SGALIB_RGB16;
    } else if (24 == fb_var.bits_per_pixel) {
        sBMap.format = SGALIB_ARGB24;
    } else {
        printf("Unsupported format !\n");
    }
    sBMap.bitspp = fb_var.bits_per_pixel;

    dBMap.addr = fbptr;
    dBMap.line_jump = fb_var.xres * (fb_var.bits_per_pixel >> 3);
    dBMap.width = fb_var.xres;
    dBMap.height = fb_var.yres;
    if (16 == fb_var.bits_per_pixel) {
        dBMap.format = SGALIB_RGB16;
    } else if (24 == fb_var.bits_per_pixel) {
        dBMap.format = SGALIB_ARGB24;
    } else {
        printf("Unsupported format !\n");
    }
    dBMap.bitspp = fb_var.bits_per_pixel;

    task_handle = SGALIB_PrepareCopy(&sBMap, &dBMap);
    SGALIB_Copy(task_handle, rect.x0, rect.y0, pt.x, pt.y,
    									rect.width, rect.height);
    SGALIB_DoneCopy(task_handle);
}

void test_bitmap_copy()
{
    Rect rect;
    int i;
    Point pt;

    clear_screen();

#if 1

    rect.x0 = 150;
    rect.y0 = 100;
    rect.width = 500;
    rect.height = 50;

    draw_rect_borders(rect, 0);

    // up - no overlap
    pt.y = rect.y0 - rect.height - 10;
    pt.x = rect.x0;
    USLP(90000);
    SGALIBTEST_Copy(rect, pt);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied up without overlap?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    // down - no overlap
    pt.y = rect.y0 + rect.height + 10;
    pt.x = rect.x0;
    USLP(90000);
    SGALIBTEST_Copy(rect, pt);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied down without overlap?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}


    // left - no overlap
    pt.y = rect.y0;
    pt.x = rect.x0 - rect.width - 10;
    USLP(90000);
    SGALIBTEST_Copy(rect, pt);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied to left without overlap (portion outside screen clipped)?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}



    // right - no overlap
    pt.y = rect.y0;
    pt.x = rect.x0 + rect.width + 10;
    USLP(90000);
    SGALIBTEST_Copy(rect, pt);


	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied to right without overlap (portion outside screen clipped)?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}


    rect.x0 = 20;
    rect.y0 = 380;
    rect.width = 50;
    rect.height = 50;

    draw_rect_borders(rect, 0);

    // up - overlap
    pt.y = rect.y0 - rect.height + 20;
    pt.x = rect.x0;
    USLP(90000);
    SGALIBTEST_Copy(rect, pt);


	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied up with overlap ?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}


    rect.x0 = 80;
    rect.y0 = 380;
    rect.width = 50;
    rect.height = 50;

    draw_rect_borders(rect, 0);

    // down - overlap
    pt.y = rect.y0 + rect.height - 10;
    pt.x = rect.x0;
    USLP(90000);
    SGALIBTEST_Copy(rect, pt);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied down with overlap ?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    rect.x0 = 180;
    draw_rect_borders(rect, 0);

    // left - overlap
    pt.y = rect.y0;
    pt.x = rect.x0 - 20;
    USLP(90000);
    SGALIBTEST_Copy(rect, pt);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied left with overlap ?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    rect.x0 = 310;
    draw_rect_borders(rect, 0);

    // right - overlap
    pt.y = rect.y0;
    pt.x = rect.x0 + rect.width - 10;
    USLP(90000);
    SGALIBTEST_Copy(rect, pt);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied right with overlap ?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    // draw a rectangle, move it towards left 2 pixels at a time,
    // then 3 pix at a time and so on ...
    rect.x0 = fb_var.xres - 155;
    rect.y0 = 230;
    rect.width = 150;
    rect.height = 50;
    draw_rect_borders(rect, 0);

    pt.y = rect.y0 ;
    for (i = 1; ; i++) {
        pt.x = rect.x0 - i;
        USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.x0 = pt.x;
        if (pt.x < 0)
            break;
    }

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied left with decreasing overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}


    // draw a rectangle, move it towards right 2 pixels at a time,
    //  then 3 pix at a time and so on ...
    rect.x0 = 5;
    rect.y0 = 285;
    rect.width = 150;
    rect.height = 50;
    draw_rect_borders(rect, 0);

    pt.y = rect.y0 ;
    for (i = 1; ; i++) {
        pt.x = rect.x0 + i;
        USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.x0 = pt.x;
        if (pt.x > fb_var.xres)
            break;
    }

    USLP(90000);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied right with decreasing overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    clear_screen();


    // draw a big rectangle, move it towards left 2 pixels at a time,
    //  then 3 pix at a time and so on ...
    rect.y0 = 5;
    rect.width = 50;
    rect.x0 = fb_var.xres - rect.width - 10;
    rect.height = 220;
    draw_rect_borders(rect, 0);

    pt.y = rect.y0 ;
    for (i = 1; ; i++) {
        pt.x = rect.x0 - i;
        USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.x0 = pt.x;
        if (pt.x < 0)
            break;
    }
	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied left with decreasing overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}


    // draw a big rectangle, move it towards right 2 pixels at a time,
    //  then 3 pix at a time and so on ...
    rect.x0 = 5;
    rect.y0 = 255;
    rect.width = 50;
    rect.height = 220;
    draw_rect_borders(rect, 0);

    pt.y = rect.y0 ;
    for (i = 1; ; i++) {
        pt.x = rect.x0 + i;
        USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.x0 = pt.x;
        if (pt.x > fb_var.xres)
            break;
    }
	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied left with decreasing overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    USLP(90000);

    clear_screen();

    // draw a small rectangle, move it towards left and up 2 pixels at a time,
    //  then 3 pix at a time and so on ...
    rect.x0 = fb_var.xres - 100;
    rect.y0 = 420;
    rect.width = 60;
    rect.height = 50;
    draw_rect_borders(rect, 0);

    for (i = 1; ; i++) {
        pt.x = rect.x0 - i;
        pt.y = rect.y0 - i;
        USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.x0 = pt.x;
        rect.y0 = pt.y;
        if (pt.x < 0)
            break;
        if (pt.y < 0)
            break;
    }
	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied left and up with overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    USLP(90000);

    clear_screen();

    // draw a small rectangle, move it towards right and up 2 pixels at a time,
    //  then 3 pix at a time and so on ...
    rect.x0 = 5;
    rect.y0 = 420;
    rect.width = 60;
    rect.height = 50;
    draw_rect_borders(rect, 0);


    for (i = 1; ; i++) {
        pt.x = rect.x0 + i;
        pt.y = rect.y0 - i;
        USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.x0 = pt.x;
        rect.y0 = pt.y;
        if (pt.x > fb_var.xres)
            break;
        if (pt.y < 0)
            break;
    }

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied right and up with overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}


    USLP(90000);

    clear_screen();

    // draw a big rectangle, move it down 2 pixels at a time,
    rect.x0 = 5;
    rect.y0 = 5;
    rect.width = fb_var.xres - 10;;
    rect.height = fb_var.yres - 30;
    draw_rect_borders(rect, 0);

    pt.x = rect.x0;
    while (1) {
        pt.y = rect.y0 + 2;
//		USLP(90000);
        SGALIBTEST_Copy(rect, pt);

        USLP(90000);
        rect.y0 = pt.y;
        if (pt.y > 480)
            break;
    }

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied down with overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    USLP(90000);


    clear_screen();

    // draw a smaller rectangle, move it down 2 pixels at a time,
    //  then 3 pix at a time and so on ...
    rect.x0 = 5;
    rect.y0 = 5;
    rect.width = fb_var.xres - 10;
    rect.height = 50;
    draw_rect_borders(rect, 0);

    pt.x = rect.x0;
    for (i = 1; ; i++) {
        pt.y = rect.y0 + i;
//		USLP(90000);
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.y0 = pt.y;
        if (pt.y > fb_var.yres)
            break;
    }

    USLP(90000);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied down with decreasing overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    clear_screen();

    // draw a small rectangle, move it towards right and up
    //  2 pixels at a time, then 3 pix at a time and so on ...
    rect.x0 = 5;
    rect.y0 = 5;
    rect.width = 160;
    rect.height = 50;
    draw_rect_borders(rect, 0);


    for (i = 4; ; i++) {
        pt.y = rect.y0 + i;
        pt.x = rect.x0 + i;
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.y0 = pt.y;
        rect.x0 = pt.x;
        if (pt.y > fb_var.yres)
            break;
        if (pt.x > fb_var.xres)
            break;

    }

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied right and down with decreasing overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}
    USLP(90000);
#endif
#if 1
    clear_screen();

    // draw a small rectangle, move it towards left and down
    // 2 pixels at a time, then 3 pix at a time and so on ...

    rect.x0 = 475;
    rect.y0 = 5;
    rect.width = 160;
    rect.height = 50;
    draw_rect_borders(rect, 0);


    for (i = 4; ; i++) {
        pt.y = rect.y0 + (i/2);
        pt.x = rect.x0 - (i/2);
        SGALIBTEST_Copy(rect, pt);
        USLP(90000);
        rect.y0 = pt.y;
        rect.x0 = pt.x;
        if (pt.y > fb_var.yres)
            break;
        if (pt.x < 0)
            break;
    }

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is rectangle copied left and down with overlap multiple times?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

    clear_screen();

    rect.x0 = 0;
    rect.y0 = 410;
    rect.width = 605;
    rect.height = 70;
    pt.y = 73;
    pt.x = 0;
    SGALIBTEST_Copy(rect, pt);

    rect.x0 = 10;
    rect.y0 = 400;
    rect.width = 160;
    rect.height = 3;

    draw_rect_borders(rect, 0);

    pt.y = 73;
    pt.x = 10;
    SGALIBTEST_Copy(rect, pt);

    rect.x0 = 170;
    rect.y0 = 400;
    rect.width = 160;
    rect.height = 4;

    draw_rect_borders(rect, 0);

    pt.y = 73;
    pt.x = 170;
    SGALIBTEST_Copy(rect, pt);


    rect.x0 = 170;
    rect.y0 = 400;
    rect.width = 160;
    rect.height = 4;

    draw_rect_borders(rect, 0);

    pt.y = rect.y0;
    pt.x = rect.x0;
    SGALIBTEST_Copy(rect, pt);


    rect.x0 = 1;
    rect.y0 = 300;
    rect.width = 160;
    rect.height = 4;

    draw_rect_borders(rect, 0);

    pt.y = rect.y0 - rect.height - 1;
    pt.x = rect.x0;
    SGALIBTEST_Copy(rect, pt);

    *(unsigned short *)(fb_addr + pt.y * 640 * 2) = 0xffff;

	if(imode) {
		SGALIB_WaitMarker();
		printf("Is misc copying ok?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}
    clear_screen();

    SLEEP(1);

    rect.x0 = 0;
    rect.y0 = 200;
    rect.width = 120;
    rect.height = 40;

    pt.y = rect.y0;
    pt.x = rect.x0 + rect.width;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.y = rect.y0 + rect.height;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.x = rect.x0;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.y = rect.y0 - rect.height;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.x = rect.x0 + rect.width;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);


    rect.x0 = fb_var.xres - 120;
    rect.y0 = 200;
    rect.width = 120;
    rect.height = 40;

    pt.y = rect.y0;
    pt.x = rect.x0 - rect.width;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.y = rect.y0 + rect.height;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.x = rect.x0;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.y = rect.y0 - rect.height;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.x = rect.x0 - rect.width;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);


    rect.x0 = 320;
    rect.y0 = 0;
    rect.width = 120;
    rect.height = 40;

    pt.y = rect.y0;
    pt.x = rect.x0 - rect.width;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.y = rect.y0 + rect.height;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.x = rect.x0;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.x = rect.x0 + rect.width;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.y = rect.y0;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);


    rect.x0 = 320;
    rect.y0 = 440;
    rect.width = 120;
    rect.height = 40;

    pt.y = rect.y0;
    pt.x = rect.x0 - rect.width;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.y = rect.y0 - rect.height;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.x = rect.x0;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.x = rect.x0 + rect.width;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);
    pt.y = rect.y0;
    SGALIBTEST_Copy(rect, pt);
    SLEEP(1);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Are rectangles copied properly around the central rectagle at each of the 4 sides?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

#endif

	// test left to right copy well
		clear_screen();

    rect.x0 = 5;
    rect.y0 = 5;
    rect.width = fb_var.xres / 2;
    rect.height = 8;

    for(i = 0; ; i++) {
      draw_rect_borders(rect, 0);
    	pt.y = rect.y0 + 2;
  	  pt.x = rect.x0 + i * 5;
	    SGALIBTEST_Copy(rect, pt);
	    rect.y0 += rect.height  + 4;

    	if(rect.y0 + rect.height > fb_var.yres) break;
  	}
		SLEEP(3);

	if(imode) {
		SGALIB_WaitMarker();
		printf("Are rectangles copied properly without artefacts?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}
		clear_screen();

    rect.x0 = 5;
    rect.y0 = 5;
    rect.width = fb_var.xres / 2;
    rect.height = 8;

    for(i = 0; ; i++) {
      draw_rect_borders(rect, 0);
    	pt.y = rect.y0 - 2;
  	  pt.x = rect.x0 + i * 5;
	    SGALIBTEST_Copy(rect, pt);
	    rect.y0 += rect.height  + 4;

    	if(rect.y0 + rect.height > fb_var.yres) break;
  	}

		SLEEP(3);
	if(imode) {
		SGALIB_WaitMarker();
		printf("Are rectangles copied properly without artefacts?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

		clear_screen();

    rect.x0 = 5;
    rect.y0 = 5;
    rect.width = fb_var.xres / 2;
    rect.height = 8;

    for(i = 0; ; i++) {
      draw_rect_borders(rect, 0);
    	pt.y = rect.y0;
  	  pt.x = rect.x0 + i * 5;
	    SGALIBTEST_Copy(rect, pt);
	    rect.y0 += rect.height  + 2;

    	if(rect.y0 + rect.height > fb_var.yres) break;
  	}
	if(imode) {
		SGALIB_WaitMarker();
		printf("Are rectangles copied properly without artefacts?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

		clear_screen();

    rect.x0 = 5;
    rect.y0 = 5;
    rect.width = fb_var.xres / 2;
    rect.height = 8;

    for(i = 0; ; i++) {
      draw_rect_borders(rect, 0);
    	pt.y = rect.y0;
  	  pt.x = rect.x0 + i * 5;
	    SGALIBTEST_Copy(rect, pt);
	    rect.y0 += rect.height  + 2;

    	if(rect.y0 + rect.height > fb_var.yres) break;
  	}

		SLEEP(3);
	if(imode) {
		SGALIB_WaitMarker();
		printf("Are rectangles copied properly without artefacts?(y/n): %c\n"); ans = tolower(getchar());
		if(ans != 'y' && ans != 'Y') fail = 1; ans = tolower(getchar());
	}

}

void random_cursor_test(void)
{

	 unsigned int colour;
	int i, j, k, count, x0, y0;
	Sga_bitmap BMap;
	unsigned char *fbptr = fb_addr;
	int task_handle;


	BMap.addr = fbptr;
	BMap.line_jump = fb_var.xres * (fb_var.bits_per_pixel >> 3);
	BMap.width = fb_var.xres;
	BMap.height = fb_var.yres;
	BMap.bitspp = fb_var.bits_per_pixel;
	if (16 == fb_var.bits_per_pixel) {
		BMap.format = SGALIB_RGB16;
	} else if (24 == fb_var.bits_per_pixel) {
		BMap.format = SGALIB_ARGB24;
	} else {
		printf("Unsupported format !\n");
	}

	{
		colour = 0xffffff; // white

		for(i = 0; i < fb_var.yres; i += 2) {
			task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
			SGALIB_Solid(task_handle, 0, i, 800, i + 2);
			SGALIB_DoneSolid(task_handle);
		}



		colour = 0xff; // blue
		task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
		SGALIB_Solid(task_handle, 16, 27, 41, 30);
		SGALIB_Solid(task_handle, 27, 16, 30, 41);
		SGALIB_DoneSolid(task_handle);

		colour = 0xffffff; // white
		task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));
		SGALIB_Solid(task_handle, 27, 27, 30, 30);
SGALIB_DoneSolid(task_handle);
	}
	SGALIB_WaitMarker();


	{
		colour = 0xff0000; // white

			task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));

		for(i = 0; i < fb_var.yres; i += 2) {
			SGALIB_Solid(task_handle, 0, i, 800, i + 2);
		}
			SGALIB_DoneSolid(task_handle);
		colour = 0xff; // blue
		task_handle = SGALIB_PrepareSolid(&BMap, c_adj(colour));

		SGALIB_Solid(task_handle, 380, 224, 390, 226);//horiz
		SGALIB_Solid(task_handle, 384, 220, 386, 230);//vertical


		SGALIB_DoneSolid(task_handle);
	}


	{
		Sga_bitmap sBMap, dBMap;
		unsigned char *fbptr = fb_addr;
		int task_handle, val, sx1, sy1, dx1, dy1, sw, sh;
		unsigned int randval;

		sBMap.addr = fbptr;
		sBMap.line_jump = fb_var.xres * (fb_var.bits_per_pixel >> 3);
		sBMap.width = fb_var.xres;
		sBMap.height = fb_var.yres;
		if (16 == fb_var.bits_per_pixel) {
			sBMap.format = SGALIB_RGB16;
		} else if (24 == fb_var.bits_per_pixel) {
			sBMap.format = SGALIB_ARGB24;
		} else {
			printf("Unsupported format !\n");
		}
		sBMap.bitspp = fb_var.bits_per_pixel;

		dBMap.addr = fbptr;
		dBMap.line_jump = fb_var.xres * (fb_var.bits_per_pixel >> 3);
		dBMap.width = fb_var.xres;
		dBMap.height = fb_var.yres;
		if (16 == fb_var.bits_per_pixel) {
			dBMap.format = SGALIB_RGB16;
		} else if (24 == fb_var.bits_per_pixel) {
			dBMap.format = SGALIB_ARGB24;
		} else {
			printf("Unsupported format !\n");
		}
		dBMap.bitspp = fb_var.bits_per_pixel;

		task_handle = SGALIB_PrepareCopy(&sBMap, &dBMap);


		srand(time(0));

		sx1 = 380;
		sy1 = 220;
		dx1 = sx1;
		dy1 = sy1;
		sw = 10;
		sh = 10;
		for(j = 0; j < 1000; j++)
			for(i = 0; i < 10000; i++) {
				randval = rand();
				switch(randval % 8) {
					case 0:
						//printf("W\n");
						dx1 -= 10;
						break;
					case 1:
						//printf("NW\n");
						dx1 -= 10; dy1 -= 10;
						break;
					case 2:
						//printf("N\n");
						dy1 -= 10;
						break;
					case 3:
						//printf("NE\n");
						dx1 += 10; dy1 -= 10;
						break;
					case 4:
						//printf("E\n");
						dx1 += 10;
						break;
					case 5:
						//printf("SE\n");
						dx1 += 10; dy1 += 10;
						break;
					case 6:
						//printf("S\n");
						dy1 += 10;
						break;
					case 7:
						//printf("SW\n");
						dx1 -= 10; dy1 += 10;
						break;
				}

				if(dx1 < 0) dx1 = 0;
				if(dx1 > fb_var.xres - 10) dx1 = fb_var.xres - 10;
				if(dy1 < 0) dy1 = 0;
				if(dy1 > fb_var.yres - 10) dy1 = fb_var.yres - 10;

				SGALIB_Copy(task_handle, sx1, sy1, dx1, dy1, sw, sh);

				sx1 = dx1;
				sy1 = dy1;

			}
			SGALIB_DoneCopy(task_handle);
	}
	SGALIB_WaitMarker();
}

