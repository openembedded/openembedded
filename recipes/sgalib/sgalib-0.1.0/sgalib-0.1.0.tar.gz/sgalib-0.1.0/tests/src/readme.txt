Readme.txt
----------

This file gives an overview of the unit tests for testing SGA library. The unit tests comprise of a single executable file which can be run from the linux shell on NHK board.

./sgalib_test

or

./sgalib_test 1

In case no arguments are given to the test, all the tests are run without any interaction with the user. In case a cmd line argument is passed to the application, it goes into the interactive mode and checks with the user for the expected output for each of the tests. At the end of the all the tests, if the tests have passed, then the SGA library is working fine for the given setup.

Note that this has been tested on the NHK15 board with 24bpp WVGA display panel. The tests should also work on a different panel as the parameters are read from the FB driver on the device. In case some tests fail on a diff panel, some tweaking in the code may be necessary to cater to the different screen size.

The functionality tested is Solid Fill operations and Copy operations. It is important to note that before the ARM processor can access the FB memory directly, the SGALIB_WaitMarker needs to be called.

To clear the screen, a pattern is displayed on the FB. This is drawn on the FB directly from ARM processor. In case of rectangle borders as well, currently they are drawn in ARM. They could be shifted to SGA if needed.

It is important to note that the pixmaps used by the SGA are assumed to start on 32bit boundaries. If not, results will be undefined.